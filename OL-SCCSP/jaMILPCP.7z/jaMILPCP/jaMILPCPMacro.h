#ifndef _JA_LPCP_MACRO_H_
#define _JA_LPCP_MACRO_H_

#ifdef JAMILPCP_EXPORTS
#define JA_MILPCP_DLL __declspec(dllexport)
#else
#define JA_MILPCP_DLL __declspec(dllimport)
#endif

#include <ilcplex/ilocplex.h>
#include <ilcp/cp.h>
ILOSTLBEGIN

#include <jaSimulation\jaProblem.h>
//  ����
typedef IloArray<IloNumArray>            IloNumMatrix;
typedef IloArray<IloNumMatrix>           IloNumMatrix3;
typedef IloArray<IloNumMatrix3>          IloNumMatrix4;

typedef IloArray<IloIntArray>            IloIntMatrix;
typedef IloArray<IloIntMatrix>           IloIntMatrix3;
typedef IloArray<IloNumVarArray>         IloNumVarMatrix;
typedef IloArray<IloNumVarMatrix>        IloNumVarMatrix3;
typedef IloArray<IloNumVarMatrix3>       IloNumVarMatrix4;
typedef IloArray<IloNumVarMatrix4>       IloNumVarMatrix5;
typedef IloArray<IloIntVarArray>         IloIntVarMatrix;
typedef IloArray<IloIntVarMatrix>        IloIntVarMatrix3;
typedef IloArray<IloIntVarMatrix3>       IloIntVarMatrix4;
typedef IloArray<IloIntVarMatrix4>       IloIntVarMatrix5;

typedef IloArray<IloRangeArray>          RangeMatrix;
typedef IloArray<RangeMatrix>            RangeMatrix3;
typedef IloArray<RangeMatrix3>           RangeMatrix4;

struct jaTask
{
public:
	string ID;
	int i;  //�����
	int j;  //�����
	int k;  //������
	int u;  //״̬�� 0 δ��ʼ��1�ڼӹ���2 �����
	int P; //�ӹ�ʱ��
	int T; //����ʱ��
	int S; //�ƻ���ʼʱ��
	int C; //�ƻ����ʱ��	
	int EST; //���翪ʼʱ��
	int LCT; //�������ʱ��	
	int dd; //Ϊ���ι����ṩ����
	int b;
	jaTask(string id)
	{
		ID = id;
		i = -1; j = -1; k = -1;
		u = 0; P = 0; T = 0;
		S = 0; C = 0;		
		EST = 0; LCT = 0;
	}
	jaTask()
	{
		i = -1; j = -1; k = -1;
		u = 0; P = 0; T = 0;
		S = 0; C = 0;		
		EST = 0; LCT = 0;
	}
};

struct jaXTask
{
public:
	string ID;
	int b;  //�����
	int k;  //������
	int P0;  //��׼����ʱ�䣬
	int u;  //״̬�� 0 δ��ʼ��1�ڼӹ���2 �����		
	int S; //�ƻ���ʼʱ��
	int C; //�ƻ����ʱ��			
	int dd; //Ϊ���ι����ṩ����
	int sj;
	int ej;
	jaXTask(string id)
	{
		ID = id;
		b = -1; k = -1;
		u = 0; P0 = 0;
		S = 0; C = 0;
		dd = 0;
	}
	jaXTask()
	{
		b = -1; k = -1;
		u = 0; P0 = 0;
		S = 0; C = 0;
		dd = 0;
	}
};
//typedef vector<vector<tuple<int, int, int, int>>> TimeTable;  //O(i,j) = st,et,mk,status
//typedef vector<vector<vector<int>>>               Assignment; //M(i,k) = j1,j2,...,jn;

typedef vector<vector<vector<jaTask*>>> Solution; // M(i,k) =taks
typedef vector<vector<jaTask*>> Sequence; // G(j) = task;
typedef vector<jaXTask*> Casts;


#define Bi 1 // [0.1, 0.2, 0.3]
#define Ei 2 // 1:variation  2:breakdown
#define Fi 1 // 1:0.30 - 2:0.70
#define Eta1 2 // E1=[0.1,0.2,0.3] E2=[0.5, 1.0, 1.5]
#define Eta2 2 // E1=[0.1,0.2,0.3] E2=[0.5, 1.0, 1.5]
#define Rho 2 //
#define Phi 2 // 

#endif