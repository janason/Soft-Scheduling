#include "jaLRRS.h"
#include <jaSimulation/util/jaCommon.h>

jaLRRS::jaLRRS(string strAlgoName):jaAlogrithm(strAlgoName)
{

}

jaLRRS::~jaLRRS(void)
{

}
bool jaLRRS::initialize()
{	
	if (!this->m_pProblem)
		return false;
	m_pProblem->prepareMaps2Lists();
	for each(auto batch in m_pProblem->BatchList())
	{
		for each(auto var in batch->getOperMap())
		{
			batch->getOperSequence().push_back(var.second);
		}		
	}
	for each(auto var in m_pProblem->getMachineMap())
	{
		var.second->getProcessList().clear();
	}
	return true;
}

bool jaLRRS::run()
{
	double obj = this->run_MILP();
	if (obj>0)
	{
		this->BLS();
	}
	else
	{
		this->BLS(true);
	}
	
	this->timing();
	return true;
}

bool jaLRRS::reset()
{
	return true;
}

void jaLRRS::output()
{


}

double jaLRRS::run_MILP()
{
	// 0. ��ʼ������
	int m = m_pProblem->StageList().size();
	int n = m_pProblem->JobList().size();
	int N = m_pProblem->BatchList().size();
	int bigM = 1.0e6;
	vector<int> mn(m);
	for (int i = 0; i < m; i++)
	{
		mn[i] = m_pProblem->StageList(i)->getMachineMap().size();
	}
	vector<vector<int>> batches(N);
	for (int b = 0; b < N; b++)
	{
		for each(auto var in m_pProblem->BatchList(b)->getOperSequence())
		{
			int j = var->getJob()->getSerialNo() - 1;
			batches[b].push_back(j);
		}
	}
	vector<vector<int>> routes(n);
	vector<vector<int>> tasks(m);
	GRBEnv env = GRBEnv();
	GRBModel model = GRBModel(env);
	for (int j = 0; j < n; j++)
	{
		for (int i = 0; i < m ; i++)
		{
			if (m_pProblem->OperMatrix(i, j) == nullptr)
				continue;
			routes[j].push_back(i);
			tasks[i].push_back(j);
		}	
	}	
	//1.���߱���
	//1.1: ʱ�����,t(i,j)
	vector<vector<GRBVar>> tvar(m);
	for (int i = 0; i < m; i++)
	{
		tvar[i].resize(n);
		for (int j = 0; j < n; j++)
		{			
			tvar[i][j] = model.addVar(0.0, bigM, 1.0e4, GRB_CONTINUOUS, "t_" + itos(i) + "_" + itos(j)); //Ŀ��ϵ��Ϊ0			
		}
	}
	//1.2: �����������߱���
	vector<vector<vector<GRBVar>>> xvar(m - 1);
	vector<vector<vector<GRBVar>>> yvar(m - 1);	
	for (int i = 0; i < m - 1; i++)
	{
		xvar[i].resize(n);
		yvar[i].resize(n);
		for (int j = 0; j < n; j++)
		{
			xvar[i][j].resize(mn[i]);
			for (int k = 0; k < mn[i]; k++)
			{
				xvar[i][j][k] = model.addVar(0, 1, 0.0, GRB_BINARY, "x_" + itos(i) + "_" + itos(j) + "_" + itos(k)); //Ŀ��ϵ��Ϊ0
			}
			yvar[i][j].resize(n);
			for (int jj = 0; jj < n; jj++)
			{
				yvar[i][j][jj] = model.addVar(0, 1, 0.0, GRB_BINARY, "y_" + itos(i) + "_" + itos(j) + "_" + itos(jj)); //Ŀ��ϵ��Ϊ0
			}
		}
	}
	//2.����Լ������
	//2.1 �������Ψһ��Լ��
	for (int i = 0; i < m -1; i++)
	{		
		for (int r = 0; r < tasks[i].size(); r++)
		{
			int j = tasks[i][r];
			GRBLinExpr x_aloc = 0;
			for (int k = 0; k < mn[i]; k++)
			{
				x_aloc += xvar[i][j][k];
			}
			model.addConstr(x_aloc == 1, "aloc: " + itos(i) + "_" + itos(j)); //Ŀ��ϵ��Ϊ0
		}
	}
	//2.2 ��������Լ��
	for (int i = 0; i < m -1; i++)
	{
		for (int r1 = 0; r1 < tasks[i].size(); r1++)
		{
			int j1 = tasks[i][r1];
			for (int r2 = 0; r2 < tasks[i].size(); r2++)
			{
				int j2 = tasks[i][r2];
				if(j1==j2) continue;
				model.addConstr(yvar[i][j1][j2] + yvar[i][j2][j1] == 1, "seq: " + itos(i) + "_" + itos(j1) + "_" + itos(j2) ); 
			}			
		}
	}
	//2.3����˳��Լ��
	for (int j = 0; j < n; j++)
	{
		for (int r = 0; r < routes[j].size()-1; r++)
		{
			int i = routes[j][r];
			int ii = routes[j][r+1];
			jaOperation* pOper = m_pProblem->OperMatrix(i, j);
			model.addConstr(tvar[ii][j] - tvar[i][j] >= pOper->getProcessTime()+pOper->getTransTime(),
					"prec: " + itos(i) + "_" + itos(ii) + "_" + itos(j));
		}		
	}
	//2.4 ����Լ��
	for (int b = 0; b < N; b++)
	{
		for (int r = 0; r< batches[b].size() - 1; r++)
		{			
			int j1 = batches[b][r];
			int j2 = batches[b][r+1];
			jaOperation* pOper1 = m_pProblem->OperMatrix(m - 1, j1);
			model.addConstr(tvar[m - 1][j2] - tvar[m - 1][j1] == pOper1->getProcessTime(), "cont_" + itos(b) + "_" + itos(j1) + "_" + itos(j2));
		}
	}	
	//2.5 ����Լ������Ҫ�ɳڵı���
	for (int i = 0; i < m - 1; i++)
	{
		for (int k = 0; k < mn[i]; k++)
		{
			for (int r1 = 0; r1 < tasks[i].size(); r1++)
			{	
				int j1 = tasks[i][r1];
				jaOperation* pOper1 = m_pProblem->OperMatrix(i, j1);								
				for (int r2 = 0; r2 < tasks[i].size(); r2++)
				{					
					int j2 = tasks[i][r2];
					if (j1 == j2) continue;
					model.addConstr(tvar[i][j2] - tvar[i][j1] + bigM*(3 - xvar[i][j1][k] - xvar[i][j2][k] - yvar[i][j1][j2])
						>= pOper1->getProcessTime(), "capc_" + itos(i) + "_" + itos(k) + "_" + itos(j1) + "_" + itos(j2));
				}				
			}
		}
	}
	model.update();
	//3. Ŀ�꺯��
	GRBVar Cmax = model.addVar(0, 1.0e4, 1, GRB_CONTINUOUS, "Cmax");
	for (int b = 0; b < N; b++)
	{
		int j = batches[b].back();
		model.addConstr(Cmax >= tvar[m - 1][j], "Cmax");
	}	
	model.setObjective(Cmax*1.0);
	//4.���
	model.set(GRB_DoubleParam_TimeLimit, 60.0*60);
	model.optimize();
	double obj = 0.0;
	if (!debug_Gurobi(model, obj))
	{
		return obj;
	}
	for (int j = 0; j < n; j++)
	{
		for (int r = 0; r < routes[j].size(); r++)
		{
			int i = routes[j][r];
			jaOperation* pOper = m_pProblem->OperMatrix(i, j);
			jaMachine* pMach = nullptr;
			if (i < m-1)
			{
				int k = 0;
				for (; k < mn[i]; k++)
				{
					if ((int)xvar[i][j][k].get(GRB_DoubleAttr_X) == 1)
						break;
				}
				pMach = m_pProblem->MachMatrix(i, k);
			}
			else
			{
				pMach = pOper->getJob()->getBatch()->getAssignedMA();	
				pMach->getProcessList().push_back(pOper);
			}		
			int tval = (int)tvar[i][j].get(GRB_DoubleAttr_X);
			pOper->setStartTime(tval);
			pOper->setFinishTime(tval + pOper->getProcessTime());
			pOper->setArrivalTime(tval);
			pOper->setDepartureTime(pOper->getFinishTime());
			DbgPrint("t[%d][%d] = %d \n", i, j, tval);
		}
	}

	return obj;
}

bool jaLRRS::BLS(bool OptCast)
{
	int m = m_pProblem->OperMatrix().size();
	if (OptCast)
	{
		for each(auto batch in m_pProblem->BatchList())
		{
			jaMachine* pMach = batch->getAssignedMA();
			int ST = 0;
			jaOperation* pHead = batch->getOperSequence().front();
			while (pHead->getPrevOper() != nullptr)
			{
				jaOperation* pPrev = pHead->getPrevOper();
				ST += pPrev->getProcessTime() + pPrev->getTransTime();
				pHead = pPrev;
			}
			ST = std::max(ST, batch->getSetupTime());
			for each(auto pOper in batch->getOperSequence())
			{
				pOper->setStartTime(ST);
				pOper->setFinishTime(ST + pOper->getProcessTime());
				pOper->setMachine(pMach);
				pMach->getProcessList().push_front(pOper);
				ST = pOper->getFinishTime();
			}
		}
	}
	for (int i = m - 2; i >= 0; i--)
	{
		vector<jaOperation*> tasks;
		for (int j = 0; j < m_pProblem->JobList().size(); j++)
		{
			jaOperation* pOper = m_pProblem->OperMatrix(i, j);
			if (pOper == nullptr)
				continue;
			jaOperation* pNext = pOper->getNextOper();
			pOper->setLFinishTime(pNext->getStartTime() - pOper->getTransTime());
			tasks.push_back(pOper);
		}
		std::sort(tasks.begin(), tasks.end(), [](jaOperation* a, jaOperation*b)
		{return a->getLFinishTime() > b->getLFinishTime(); });
		for (int k = 0; k < m_pProblem->StageList(i)->getMachineMap().size(); k++)
		{
			m_pProblem->MachMatrix(i, k)->setReleaseTime(1.0e6);
		}		
		for (int r = 0; r < tasks.size(); r++)
		{
			int rlst = -1.0e3;
			jaMachine* pSelMach = nullptr;
			jaOperation* pSelOper = tasks[r];
			for (int k = 0; k < m_pProblem->StageList(i)->getMachineMap().size(); k++)
			{
				if (m_pProblem->MachMatrix(i, k)->getReleaseTime()>rlst)
				{
					rlst = m_pProblem->MachMatrix(i, k)->getReleaseTime();
					pSelMach = m_pProblem->MachMatrix(i, k);
				}				
			}
			int ft = std::min(rlst, pSelOper->getLFinishTime());
			pSelOper->setFinishTime(ft);
			pSelOper->setStartTime(ft - pSelOper->getProcessTime());
			pSelOper->setMachine(pSelMach);
			pSelMach->getProcessList().push_front(pSelOper);
			pSelMach->setReleaseTime(pSelOper->getStartTime());
		}

	}
	return 0.0;
}

double jaLRRS::timing()
{
	// 0. ��ʼ������
	int m = m_pProblem->StageList().size();
	int n = m_pProblem->JobList().size();
	int N = m_pProblem->BatchList().size();
	int bigM = 1.0e6;
	vector<int> mn(m);
	vector<vector<vector<int>>> solution(m);
	for (int i = 0; i < m; i++)
	{
		mn[i] = m_pProblem->StageList(i)->getMachineMap().size();
		solution[i].resize(mn[i]);
		for (int k = 0; k < mn[i]; k++)
		{
			jaMachine* pMach = m_pProblem->MachMatrix(i, k);			
			for each(auto pOper in pMach->getProcessList())
			{
				solution[i][k].push_back(pOper->getJob()->getSerialNo() - 1);
			}
		}
	}
	vector<vector<int>> batches(N);
	for (int b = 0; b < N; b++)
	{
		for each(auto var in m_pProblem->BatchList(b)->getOperSequence())
		{
			int j = var->getJob()->getSerialNo() - 1;
			batches[b].push_back(j);
		}
	}
	vector<vector<int>> routes(n);
	vector<vector<int>> tasks(m);
	GRBEnv env = GRBEnv();
	GRBModel model = GRBModel(env);
	for (int j = 0; j < n; j++)
	{
		for (int i = 0; i < m; i++)
		{
			if (m_pProblem->OperMatrix(i, j) == nullptr)
				continue;
			routes[j].push_back(i);
			tasks[i].push_back(j);
		}
	}
	//1.���߱���
	//1.1: ʱ�����,t(i,j)
	vector<vector<GRBVar>> tvar(m);
	for (int i = 0; i < m; i++)
	{
		tvar[i].resize(n);
		for (int j = 0; j < n; j++)
		{
			tvar[i][j] = model.addVar(0.0, bigM, 1.0e4, GRB_CONTINUOUS, "t_" + itos(i) + "_" + itos(j)); //Ŀ��ϵ��Ϊ0			
		}
	}	
	//2.����Լ������
	//2.3����˳��Լ��
	for (int j = 0; j < n; j++)
	{
		for (int r = 0; r < routes[j].size() - 1; r++)
		{
			int i = routes[j][r];
			int ii = routes[j][r + 1];
			jaOperation* pOper = m_pProblem->OperMatrix(i, j);
			model.addConstr(tvar[ii][j] - tvar[i][j] >= pOper->getProcessTime() + pOper->getTransTime(),
				"prec: " + itos(i) + "_" + itos(ii) + "_" + itos(j));
		}
	}
	//2.4 ����Լ��
	for (int b = 0; b < N; b++)
	{
		for (int r = 0; r < batches[b].size() - 1; r++)
		{
			int j1 = batches[b][r];
			int j2 = batches[b][r + 1];
			jaOperation* pOper1 = m_pProblem->OperMatrix(m - 1, j1);
			model.addConstr(tvar[m - 1][j2] - tvar[m - 1][j1] == pOper1->getProcessTime(), "cont_" + itos(b) + "_" + itos(j1) + "_" + itos(j2));
		}
	}
	//2.5 ����Լ������Ҫ�ɳڵı���
	for (int i = 0; i < m - 1; i++)
	{
		for (int k = 0; k < mn[i]; k++)
		{
			for (int r = 0; r < solution[i][k].size()-1; r++)
			{
				int j1 = solution[i][k][r];
				int j2 = solution[i][k][r+1];
				jaOperation* pOper1 = m_pProblem->OperMatrix(i, j1);
				jaOperation* pOper2 = m_pProblem->OperMatrix(i, j2);			
				model.addConstr(tvar[i][j2] - tvar[i][j1]>= pOper1->getProcessTime(),
					"capc_" + itos(i) + "_" + itos(k) + "_" + itos(j1) + "_" + itos(j2));	
			}
		}
	}
	model.update();
	//3. Ŀ�꺯��
	GRBLinExpr wt = 0;
	for (int j = 0; j < n; j++)
	{
		wt += 0.1*  tvar[routes[j][0]][j];
		for (int r = 0; r < routes[j].size() - 1; r++)
		{
			int i = routes[j][r];
			int ii = routes[j][r + 1];
			wt += 100.0*(tvar[ii][j] - tvar[i][j]
				- m_pProblem->OperMatrix(i, j)->getProcessTime() - m_pProblem->OperMatrix(i, j)->getTransTime());
		}
	}
	model.setObjective(wt);
	//4.���
	model.set(GRB_DoubleParam_TimeLimit, 60.0 * 10);
	model.optimize();
	double obj = 0.0;
	if (!debug_Gurobi(model, obj))
	{
		DbgPrint("no solution ...........\n");
		return obj;
	}
	for (int j = 0; j < n; j++)
	{
		for (int r = 0; r < routes[j].size(); r++)
		{
			int i = routes[j][r];
			jaOperation* pOper = m_pProblem->OperMatrix(i, j);				
			int tval = (int)tvar[i][j].get(GRB_DoubleAttr_X);
			pOper->setStartTime(tval);
			pOper->setFinishTime(tval + pOper->getProcessTime());
			pOper->setArrivalTime(tval);
			pOper->setDepartureTime(pOper->getFinishTime());
			DbgPrint("t[%d][%d] = %d \n", i, j, tval);
		}
	}

	return obj;
}

bool jaLRRS::debug_Gurobi(GRBModel& model, double& obj)
{
	bool isOK = false;
	try {
		int optimstatus = model.get(GRB_IntAttr_Status);
		if (optimstatus == GRB_OPTIMAL) {
			obj = model.get(GRB_DoubleAttr_ObjVal);
			isOK = true;
		}
		else if (optimstatus == GRB_INF_OR_UNBD) {
			DbgPrint("Model is infeasible or unbounded \n", obj);
		}
		else if (optimstatus == GRB_INFEASIBLE) {
			// do IIS
			DbgPrint("The model is infeasible; computing IIS \n");
			model.computeIIS();
			DbgPrint("The following constraint(s) cannot be satisfied:\n");
			GRBConstr* c = model.getConstrs();
			for (int i = 0; i < model.get(GRB_IntAttr_NumConstrs); ++i)
			{
				if (c[i].get(GRB_IntAttr_IISConstr) == 1)
				{
					cout << c[i].get(GRB_StringAttr_ConstrName) << endl;
					DbgPrint("%s \n", c[i].get(GRB_StringAttr_ConstrName).c_str());
				}
			}
		}
		else if (optimstatus == GRB_UNBOUNDED) {
			DbgPrint("Model is unbounded \n");
		}
		else {
			DbgPrint("Optimization was stopped with status = %d \n", optimstatus);
		}
	}
	catch (GRBException e) {
		DbgPrint("Error code = %d \n", e.getErrorCode());
		DbgPrint(e.getMessage().c_str());
	}
	catch (...) {
		cout << "Exception during optimization" << endl;
	}
	return isOK;
}

