﻿#include "jaLROA.h"

int **m_t = nullptr;
int ***m_x = nullptr;
int ***m_y = nullptr;
int ***m_jl = nullptr; //机器任务列表
int **m_jc = nullptr; //机器任务数量
double**** mu = nullptr;
double**** sg = nullptr;

int TB = 60;
int U = 0;
int UT = 0;
double C1 = 1.0, C2 = 10.0, C3 = 100.0;

jaLROA::jaLROA(string algo_name):jaAlogrithm(algo_name)
{

}

jaLROA::~jaLROA()
{

}

bool jaLROA::initialize()
{
	if (!this->m_pProblem)
		return false;
	m_pProblem->prepareMaps2Lists();	
	this->initParam();
	this->initVar();
	return true;
}

bool jaLROA::run()
{	
	this->optimize();
	return true;
}

bool jaLROA::reset()
{

	return true;
}

void jaLROA::output()
{
	for each(auto mach in m_pProblem->getMachineMap())
	{
		mach.second->getProcessList().clear();
	}
	for (int i = 0; i < g - 1; i++)
	{
		for (int k = 0; k < Mk[i]; k++)
		{
			string machID = jaCommon::format("%d%d", i + 1, k + 1);
			jaMachine* pMach = this->m_pProblem->getMachineMap()[machID];
			for (int j = 0; j < m_jc[i][k]; j++)//遍历 O(i,j)-O(i,j)
			{
				int jx = m_jl[i][k][j];
				string operID = jaCommon::format("O_%d_%03d", i + 1, jx + 1);
				map<string, jaOperation*>::iterator it = m_pProblem->getOperMap().find(operID);				
				if (it == m_pProblem->getOperMap().end())
					continue;
				jaOperation* pOper = it->second;
				pOper->setMachine(pMach);
				pOper->setStartTime(m_t[i][jx]);
				pOper->setFinishTime(m_t[i][jx] + P[i][jx]);
				pOper->setArrivalTime(pOper->getStartTime());
				pOper->setDepartureTime(pOper->getFinishTime());
				pMach->getProcessList().push_back(pOper);
				//DbgPrint("%s t[%d,%d] = %d \n", operID.c_str(), i + 1, j + 1, m_t[i][j]);
				//cout<<"("<<i+1<<","<<jx+1<<") : "<<pOper->getStartTime()<<"-"<<pOper->getFinishTime()<<endl;
			}
		}
	}
	m_Cmax = 0;
	for (int k = 0; k < Mk[g - 1]; k++)
	{
		string machID = jaCommon::format("%d%d", g, k + 1);
		jaMachine* pMach = this->m_pProblem->getMachineMap()[machID];
		for (int lk = 0; lk < hk[k]; lk++)
		{
			int l = Bk[k][lk];
			for (int j = 0; j < nl[l]; j++)
			{
				int jx = B[l][j];
				string operID = jaCommon::format("O_%d_%03d", g, jx + 1);
				map<string, jaOperation*>::iterator it = m_pProblem->getOperMap().find(operID);
				if (it == m_pProblem->getOperMap().end())
					continue;
				jaOperation* pOper = it->second;
				pOper->setMachine(pMach);
				pOper->setStartTime(m_t[g - 1][jx]);
				pOper->setFinishTime(m_t[g - 1][jx] + P[g - 1][jx]);
				pOper->setArrivalTime(pOper->getStartTime());
				pOper->setDepartureTime(pOper->getFinishTime());
				pMach->getProcessList().push_back(pOper);
				if (pOper->getFinishTime() > m_Cmax)
					m_Cmax = pOper->getFinishTime();
				//cout<<"("<<g<<","<<jx+1<<") : "<<pOper->getStartTime()<<"-"<<pOper->getFinishTime()<<endl;
			}
		}
	}	
}

int jaLROA::getCmax()
{
	return m_Cmax;
}

void jaLROA::initParam()
{
	if (!this->m_pProblem)
		return;
	cout << "initParam--- start: " << endl;
	g = m_pProblem->getStageMap().size();; //工序数量
	Mk = new int[g];
	Mk[0] = 0;
	int i = 0;
	for (const auto& kvp : m_pProblem->getStageMap())
	{
		jaStage* pStage = kvp.second;
		Mk[i] = pStage->getMachineMap().size();		
		i++;
	}
	n = m_pProblem->getJobMap().size(); //炉次总数
	J = new int[n]; //炉次集合 	
	UP = new int[n];
	for (int j = 0; j < n; j++)
	{
		J[j] = j;
		UP[j] = 0;
		string jobID = jaCommon::format("J_%03d", j + 1);
		jaJob* pJob = m_pProblem->getJobMap()[jobID];	
	}
	h = m_pProblem->getBatchMap().size();    //浇次数	
	B = new int*[h]; //浇次集合
	be = new int[h]; //浇次末尾序号		
	bs = new int[h];
	this->nl = new int[h];
	dl = new int[h];
	SU = new int[h];
	
	for (int l = 0; l < h; l++)
	{
		string bahID = jaCommon::format("H_%02d", l + 1);
		jaBatch* pBatch = this->m_pProblem->getBatchMap()[bahID];
		nl[l] = pBatch->getOperMap().size();   //浇次内炉次数
		B[l] = new int[nl[l]];
		int jx = 0; int j = 0;
		for (const auto& kvp : pBatch->getOperMap())
		{
			jaOperation* pOper = (jaOperation*)kvp.second;
			jaJob* pJob = pOper->getJob();
			B[l][j] = pJob->getSerialNo() - 1;
			jx = B[l][j];
			if (j == 0) { bs[l] = jx; }
			j++;

			int UPT = 0;
			jaOperation* pPrev = pOper->getPrevOper();
			while (pPrev!=nullptr)
			{
				UPT += pPrev->getNoise()->getStdValue()+5;
				pPrev = pPrev->getPrevOper();
			}
			pOper->setPrevLoad(UPT);
		}
		be[l] = jx; //浇次最后一个任务序号
		dl[l] = 0;
		SU[l] = pBatch->getSetupTime();
	}
		

	TF = new int[2];
	TF[0] = 5;
	TF[1] = 5;
	
	P = new int*[g];
	U = 0;
	UT = 0;
	for (int i = 0; i < g; i++) //操作时间
	{
		P[i] = new int[n];
		for (int j = 0; j < n; j++)
		{
			string operID = jaCommon::format("O_%d_%03d", i + 1, j + 1);
			map<string, jaOperation*>::iterator it = m_pProblem->getOperMap().find(operID);
			if (it == m_pProblem->getOperMap().end())
				continue;;
			P[i][j] = 0;
			jaOperation* pOper = it->second;
			map<jaMachine*, jaNosiedPT*>::iterator itx = pOper->getMachineTimeSet().begin();
			int nTPT = 0;			
			P[i][j] = pOper->getNoise()->getStdValue();
			U += P[i][j];
			if (i < g - 1)
				UT += P[i][j] + TF[i];
			else
				UT += P[i][j];
			if (i < g-1)
			{
				UP[j] += P[i][j] + TF[i];
			}
			//DbgPrint("P[%d,%d] = %d \n", i,j, P[i][j]);
		}
	}
	//this->init_batch_time();
	//分配连铸机和开浇时间,
	Bk = new int*[Mk[g - 1]];
	hk = new int[Mk[g - 1]];
	hx = new int[h];
	for (int k = 0; k < Mk[g - 1]; k++)
	{
		hk[k] = 0;
		Bk[k] = new int[h];
	}
	for (auto kvp : m_pProblem->getBatchMap())
	{
		jaBatch* pBatch = kvp.second;
		int ln = pBatch->getSerialNo();
		int kn = pBatch->getAssignedMA()->getSerialNo();
		Bk[kn - 1][hk[kn - 1]] = ln - 1;
		hk[kn - 1] = hk[kn - 1] + 1;
		hx[ln - 1] = kn - 1;
	}
}

void jaLROA::optimize()
{
	//1.求得初始解获取初始化次梯度，拉格朗日乘子 mu1
	double p_init = initAlgo();
	//write2txt(0.0,p_init);

	cout << "best obj=" << p_init << endl;
	///LHI();
	//ISLA();
	cout << "best obj=" << p_init << endl;
	
	//1. 初始化每个机器上的时间标记
	int** TM = new int*[g];
	for (int i = 0; i < g; i++)
	{
		TM[i] = new int[Mk[i]];
		for (int k = 0; k < Mk[i]; k++)
		{
			TM[i][k] = 0;
		}
	}
	//2. 按照计划时间倒排，计算各工序的开始时间	
	int** jc = new int*[g - 1];
	int*** ja = new int**[g - 1]; //每个机器上的任务排列
	for (int i = g - 2; i >= 0; i--)
	{
		//完成时间排序
		int* LCT = new int[n];	//当前工序的完成时间	
		for (int j = 0; j<n; j++)
		{
			if (i == g - 2)
			{
				LCT[j] = m_t[i + 1][j] - TF[i] - 5 * Rho;
			}
			else
			{
				LCT[j] = m_t[i + 1][j] - TF[i];
			}
		}
		int* Tj = sortByST(LCT, n);
		jc[i] = new int[Mk[i]];
		ja[i] = new int*[Mk[i]]; //每个机器上的任务排列
		for (int k = 0; k<Mk[i]; k++)
		{
			TM[i][k] = 1.0e5;
			jc[i][k] = 0;
			ja[i][k] = new int[n];
		}
		for (int j = n - 1; j >= 0; j--) //反向选择
		{
			//待排工序
			int kx = 0;
			int max_rlst = -1.0e6;
			int jx = Tj[j];
			for (int k = 0; k<Mk[i]; k++) //选择最晚开始的机器
			{
				if (TM[i][k] >= max_rlst)
				{
					if (TM[i][k] == max_rlst)
					{
						if (jc[i][k] < jc[i][kx])
						{
							kx = k;
						}
					}
					else
					{
						max_rlst = TM[i][k];
						kx = k;
					}

				}
				m_x[i][jx][k] = 0;
			}
			TM[i][kx] = std::min(TM[i][kx], LCT[j]) - P[i][jx]; //临时可用时间
			m_x[i][jx][kx] = 1;
			m_t[i][jx] = TM[i][kx];
			//可行化排序变量	
			ja[i][kx][jc[i][kx]++] = jx;
			//cout<<"j="<<jx<<" @"<< kx+1<<"  "<<m_t[i][jx]<<":"<<m_t[i][jx]+P[i][jx]<<endl;
		}

		for (int k = 0; k<Mk[i]; k++)
		{
			m_jc[i][k] = jc[i][k];
			for (int r = jc[i][k] - 1; r > 0; r--)
			{
				int jj = ja[i][k][r];
				int jy = ja[i][k][r - 1];
				m_jl[i][k][jc[i][k] - r - 1] = jj;
				for (int jx = 0; jx< n; jx++)
				{
					m_y[i][jx][jj] = 0;
					m_y[i][jj][jx] = 0;
				}
				for (int rx = r + 1; rx < jc[i][k]; rx++)
				{
					int jx = ja[i][k][rx];
					m_y[i][jx][jj] = 1;
				}
				m_y[i][jj][jy] = 1;
			}
			if (jc[i][k] > 0)
			{
				m_jl[i][k][jc[i][k] - 1] = ja[i][k][0];
			}
		}
	}

	/*for (int i = 0; i < g -1; i++)
	{
	for (int k = 0; k < Mk[i]; k++)
	{
	for (int r = 0; r < m_jc[i][k]; r++)
	{
	DbgPrint("%d-", m_jl[i][k][r]);
	}
	DbgPrint("\n");
	}
	DbgPrint("\n");
	}*/

	double obj = initialLP();

	
	return;
}

void jaLROA::ISLA()
{
	double f_new = 0.0;
	double p_new = 0.0;

	//1.set mu1
	double G2 = norm4Array(sg);
	double G1 = std::sqrt(G2);
	int NN = (int)std::floor(std::log10(G2 / U));
	for (int i = 0; i < g - 1; i++)
	{
		for (int j = 0; j < n; j++)
		{
			for (int r = 0; r < n; r++)
			{
				for (int k = 0; k < Mk[i]; k++) {
					if (j == r) { mu[i][j][r][k] = 0; }
					else { mu[i][j][r][k] = std::pow(10, NN)*sg[i][j][r][k] / G2; }

				}
			}
		}
	}
	//2.init parameters
	double epsilon1 = 1e-5;
	double epsilon2 = 1e-5;
	double epsilon3 = 1e-5;
	double beta = 0.8;
	double delta1 = (p_new + f_new) / 5;
	double tpara = 1.2;
	double sigma_max = (p_new + f_new) / G1;
	double W = 4;
	bool flag = true;
	double* sigma_rec = new double[200];
	double* delta_rec = new double[200];
	double* f_rec = new double[200];

	double pbest = std::numeric_limits<double>::max();
	f_rec[0] = pbest;
	sigma_rec[0] = 0;


	int m = 1;
	int r = 0; //weak
	int s = 0; //strong
	int l = 1; //fbest
	int* ml_rec = new int[200];
	ml_rec[l] = 1;
	delta_rec[l] = delta1;
	double**** dx = copyValue(sg);
	//3.iterative
	do
	{
		//1. Function evaluation
		std::cout << "obj value f=" << f_new << " p=" << p_new << endl;
		if (f_new < f_rec[m - 1])
		{
			f_rec[m] = f_new;
		}
		else
		{
			f_rec[m] = f_rec[m - 1];
		}
		if (p_new < pbest) { pbest = p_new; }
		if (pbest + f_new < delta_rec[l])
		{
			delta_rec[l] = pbest + f_new;
		}
		//2.Sufﬁcient descent
		if (f_new < f_rec[m] - 0.5 * delta_rec[l])
		{ // Sufficient descent dection
			ml_rec[l + 1] = m;
			sigma_rec[m] = 0;
			delta_rec[l + 1] = delta_rec[l];
			l = l + 1;
		}

		if (r >= W)
		{  // Weak osillation detection
			r = 0;
			double tempf = 0;
			for (int i = 1; i < W - 2; i = i + 2)
			{
				tempf += std::abs((f_rec[i + 2] - f_rec[i]) / f_rec[i]);
			}
			if (tempf * 2 / W < epsilon3)
			{
				sigma_rec[m] = sigma_max / (s + 1) + 1;
			}
		}
		// Strong osillation detection
		if (sigma_rec[m] > sigma_max / (s + 1))
		{
			ml_rec[l + 1] = m;
			sigma_rec[m] = 0;
			delta_rec[l + 1] = delta_rec[l] * beta;
			l = l + 1; s = s + 1;
		}
		//Projection of multipliers.
		double flev = f_rec[ml_rec[l]] - delta_rec[l];
		//Improved step size method of the subgradient algorithm
		for (int i = 0; i < g - 1; i++)
		{
			for (int j = 0; j < n; j++)
			{
				for (int r = 0; r < n; r++)
				{
					for (int k = 0; k < Mk[i]; k++)
					{
						if (sg[i][j][r][k] > 0 && std::abs(mu[i][j][r][k]) < 1e-8)
							sg[i][j][r][k] = 0;
					}
				}
			}
		}
		G2 = norm4Array(sg);
		G1 = std::sqrt(G2);
		double tempt = tpara * (f_new - flev) / (G2);
		for (int i = 0; i < g - 1; i++)
		{
			for (int j = 0; j < n; j++)
			{
				for (int r = 0; r < n; r++)
				{

					for (int k = 0; k < Mk[i]; k++)
					{
						dx[i][j][r][k] = tempt * sg[i][j][r][k];
						mu[i][j][r][k] = mu[i][j][r][k] - dx[i][j][r][k];
						if (mu[i][j][r][k] < 0)
							mu[i][j][r][k] = 0;
					}
				}
			}
		}
		//Path update
		fullScheduling1(f_new, p_new);
		//write2txt(f_new,p_new);
		DbgPrint("f = %.3f \n", p_new);

		double dnorm = norm4Array(dx);
		sigma_rec[m + 1] += dnorm;
		m++;
		if (m > 100)
		{
			break;
		}
		G2 = norm4Array(sg);
		G1 = std::sqrt(G2);
		double tmpv = std::abs(delta_rec[l] / f_rec[ml_rec[l]]);
		if (G1 < epsilon1 || tmpv < epsilon2)
		{
			flag = false;
		}
		
	} while (flag);
}

double jaLROA::calcSubgradient(double**** sg)
{
	double norm = 0.0;
	//计算次梯度
	for (int i = 0; i < g - 1; i++)
	{
		for (int j = 0; j < n - 1; j++)
		{
			for (int r = j + 1; r < n; r++)
			{
				for (int k = 0; k < Mk[i]; k++)
				{
					int temp = 3 - m_x[i][j][k] - m_x[i][r][k] - m_y[i][j][r];
					sg[i][j][r][k] = (m_t[i][r] - m_t[i][j] - P[i][j]) + temp*U;

					temp = 3 - m_x[i][j][k] - m_x[i][r][k] - m_y[i][r][j];
					sg[i][r][j][k] = (m_t[i][j] - m_t[i][r] - P[i][r]) + temp*U;
				}
			}
		}
	}
	return norm;
}

void jaLROA::feasiblize()
{
	for (int i = 0; i<g - 1; i++)
	{
		//开始时间排序
		int* Ti = new int[n];
		for (int j = 0; j<n; j++)
		{
			Ti[j] = (int)m_t[i][j];
		}
		int* Tj = sortByST(Ti, n);		
		//按照负载均衡选择加工机器		
		int* kt = new int[Mk[i]];   //机器释放时间							
		for (int k = 0; k<Mk[i]; k++)
		{
			m_jc[i][k] = 0; kt[k] = 0;
			for (int j = 0; j<n; j++) 
				m_jl[i][k][j] = -1;
		}
		for (int j = 0; j<n; j++)
		{
			int kx = 0; int KT = UT; int jx = Tj[j];
			for (int k = 0; k<Mk[i]; k++)
			{
				if (kt[k]<KT) //选择最小的开始加工
				{
					KT = kt[k]; kx = k; m_x[i][Tj[j]][k] = 0;
				}
			}
			m_x[i][jx][kx] = 1;
			kt[kx] = KT + P[i][jx];
			//可行化排序变量
			if (m_jc[i][kx]>0)
			{
				for (int r = 0; r<m_jc[i][kx]; r++)
				{
					m_y[i][m_jl[i][kx][r]][jx] = 1;
					m_y[i][jx][m_jl[i][kx][r]] = 0;
				}
			}
			m_jl[i][kx][m_jc[i][kx]++] = jx;
		}
		delete kt;
	}
	//output solution
	/*for (int i=0;i<g-1;i++)
	{
	for (int k=0;k<Mk[i];k++)
	{
	cout<<"M["<<i<<","<<k<<"]:"<<endl;
	for (int j=0;j<m_jc[i][k];j++)
	{
	cout<<m_jl[i][k][j]<<"-";
	}
	cout<<endl;
	}
	cout<<endl;
	}*/
}

void jaLROA::initVar()
{
	/*决策变量：开始时间，机器分派和排序 ******************************/
	m_x = new int**[g - 1];
	m_y = new int**[g - 1];
	for (int i = 0; i < g - 1; i++)
	{
		m_x[i] = new int*[n];
		m_y[i] = new int*[n];
		for (int j = 0; j < n; j++)
		{
			m_x[i][j] = new int[Mk[i]];
			for (int k = 0; k < Mk[i]; k++)
			{
				m_x[i][j][k] = 0;
			}
			m_y[i][j] = new int[n];
			for (int r = 0; r < n; r++)
			{
				m_y[i][j][r] = 0;
			}
		}
	}
	m_t = new int*[g];
	for (int i = 0; i < g; i++)
	{
		m_t[i] = new int[n];
		for (int j = 0; j < n; j++)
		{
			m_t[i][j] = 0;
		}
	}

	//调度解的表达
	m_jl = new int**[g - 1];
	m_jc = new int*[g - 1];
	for (int i = 0; i < g; i++)
	{
		m_jl[i] = new int*[Mk[i]];
		m_jc[i] = new int[Mk[i]];
		for (int k = 0; k < Mk[i]; k++)
		{
			m_jc[i][k] = 0;
			m_jl[i][k] = new int[n];
			for (int j = 0; j < n; j++) m_jl[i][k][j] = -1;
		}
	}
	/******************* 拉格朗日松弛参数初始化,0-梯度，0-乘子 ******************************/
	mu = new double***[g - 1];
	sg = new double***[g - 1];
	for (int i = 0; i < g - 1; i++)
	{
		mu[i] = new double**[n];
		sg[i] = new double**[n];
		for (int j = 0; j < n; j++)
		{
			mu[i][j] = new double*[n];
			sg[i][j] = new double*[n];
			for (int r = 0; r < n; r++)
			{
				mu[i][j][r] = new double[Mk[i]];
				sg[i][j][r] = new double[Mk[i]];
				for (int k = 0; k < Mk[i]; k++) {
					mu[i][j][r][k] = 0.0;
					sg[i][j][r][k] = 0.0;
				}
			}
		}
	}
}

double jaLROA::initAlgo()
{
	//1. 初始化每个机器上的时间标记
	int** TM = new int*[g];   
	for (int i = 0;  i < g; i++ )
	{
		TM[i] = new int[Mk[i]];   
		for (int k = 0; k < Mk[i]; k++)
		{
			TM[i][k] = 0;
		}
	}
	//2. 按照计划时间倒排，计算各工序的开始时间
	for (int l = 0; l <h; l++)// 每个连铸机的上浇次数
	{
		int j = bs[l];
		int k = hx[l];
		TM[g-1][k] = std::max(TM[g-1][k]+SU[l],UP[j]+5*Rho);		
		for (int lj = 0; lj<nl[l]; lj++)
		{
			int j = B[l][lj];
			if (lj == 0)
			{
				m_t[g - 1][j] = TM[g - 1][k];
			}
			else
			{
				int r = B[l][lj - 1];
				m_t[g - 1][j] = m_t[g - 1][r] + P[g - 1][r];
				TM[g - 1][k] = m_t[g - 1][j] + P[g - 1][j];
			}
		}
	}
	
	int** jc = new int*[g - 1];
	int*** ja = new int**[g - 1]; //每个机器上的任务排列
	for (int i = g - 2; i >= 0; i--)
	{
		//完成时间排序
		int* LCT = new int[n];	//当前工序的完成时间	
		for (int j = 0; j<n; j++)
		{
			if (i == g - 2)
			{
				LCT[j] = m_t[i + 1][j] - TF[i] - 5*Rho;
			}
			else
			{
				LCT[j] = m_t[i + 1][j] - TF[i];
			}			
		}
		int* Tj = sortByST(LCT, n);			
		jc[i] = new int[Mk[i]];
		ja[i] = new int*[Mk[i]]; //每个机器上的任务排列
		for (int k = 0; k<Mk[i]; k++)
		{
			TM[i][k] = 1.0e5;
			jc[i][k] = 0;
			ja[i][k] = new int[n];
		}
		for (int j = n - 1; j >= 0; j--) //反向选择
		{
			//待排工序
			int kx = 0;
			int max_rlst = -1.0e6;
			int jx = Tj[j];
			for (int k = 0; k<Mk[i]; k++) //选择最晚开始的机器
			{				
				if (TM[i][k] >= max_rlst)
				{
					if (TM[i][k] == max_rlst)
					{
						if (jc[i][k] < jc[i][kx])
						{
							kx = k;
						}
					}
					else
					{
						max_rlst = TM[i][k];
						kx = k;
					}
					
				}
				m_x[i][jx][k] = 0;
			}
			TM[i][kx] = std::min(TM[i][kx], LCT[j]) - P[i][jx]; //临时可用时间
			m_x[i][jx][kx] = 1;
			m_t[i][jx] = TM[i][kx];
			//可行化排序变量	
			ja[i][kx][jc[i][kx]++] = jx;
			//cout<<"j="<<jx<<" @"<< kx+1<<"  "<<m_t[i][jx]<<":"<<m_t[i][jx]+P[i][jx]<<endl;
		}

		for (int k = 0; k<Mk[i]; k++)
		{
			m_jc[i][k] = jc[i][k];
			for (int r = jc[i][k] -1 ; r > 0; r--)
			{
				int jj = ja[i][k][r];
				int jy = ja[i][k][r-1];
				m_jl[i][k][jc[i][k] - r -1 ] = jj;				
				for (int jx = 0; jx< n; jx++)
				{
					m_y[i][jx][jj] = 0;
					m_y[i][jj][jx] = 0;
				}
				for (int rx = r+1; rx < jc[i][k]; rx++)
				{
					int jx = ja[i][k][rx];
					m_y[i][jx][jj] = 1;
				}	
				m_y[i][jj][jy] = 1;
			}
			if (jc[i][k] > 0)
			{
				m_jl[i][k][jc[i][k]-1] = ja[i][k][0];
			}			
		}		
	}

	/*for (int i = 0; i < g -1; i++)
	{
		for (int k = 0; k < Mk[i]; k++)
		{
			for (int r = 0; r < m_jc[i][k]; r++)
			{
				DbgPrint("%d-", m_jl[i][k][r]);
			}
			DbgPrint("\n");
		}
		DbgPrint("\n");
	}*/

	double obj = initialLP();
	return 0.0;
}

double jaLROA::initialLP()
{
	GRBEnv env = GRBEnv();
	GRBModel model = GRBModel(env);
	model.getEnv().set(GRB_IntParam_LazyConstraints, 1);
	//1.决策变量
	//1.1 时间变量 t(i,j)
	GRBVar** tvar = new GRBVar*[g];	
	for (int i = 0; i < g; i++)
	{
		tvar[i] = new GRBVar[n];		
		for (int j = 0; j < n; j++)
		{
			tvar[i][j] = model.addVar(0.0, UT, 0.0, GRB_INTEGER, "t_" + itos(i) + "_" + itos(j)); //目标系数为0					
		}
	}	
	model.update();	
	//2.增加约束条件
	//2.1工序时间约束
	for (int j = 0; j < n; j++)
	{
		int upt = 0;
		for (int i = 0; i < g - 1; i++)
		{
			if (i < g - 2)
			{
				model.addConstr(tvar[i + 1][j] - tvar[i][j] - P[i][j] >= TF[i], "stage_" + itos(i) + "_" + itos(i + 1) + "_" + itos(j));
			}
			else
			{
				model.addConstr(tvar[i + 1][j] - tvar[i][j] - P[i][j] >= TF[i] + 5*Rho, "stage_" + itos(i) + "_" + itos(i + 1) + "_" + itos(j));
			}			
			upt += P[i][j] + TF[i];
		}
		/*int std_fl = (1 + 0.1*Lamda)*upt;
		model.addConstr(tvar[g - 1][j] - tvar[0][j] >= std_fl, "rlst_" + itos(j));*/
	}
	//2.2 连浇约束
	for (int l = 0; l < h; l++)
	{
		for (int j = 0; j < nl[l] - 1; j++)
		{
			int j1 = B[l][j];    //
			int j2 = B[l][j + 1];  //
			model.addConstr(tvar[g - 1][j1] + P[g - 1][j1] == tvar[g - 1][j2], "cast_" + itos(l) + "_" + itos(j1) + "_" + itos(j2));
		}
	}
	//2.3 准备时间约束
	for (int k = 0; k < Mk[g - 1]; k++)
	{
		for (int lk = 0; lk < hk[k] - 1; lk++)
		{			
			int jx = be[Bk[k][lk]]; //最后一个工件
			int jy = bs[Bk[k][lk + 1]];
			model.addConstr(tvar[g - 1][jy] - tvar[g - 1][jx] - P[g - 1][jx] >= SU[Bk[k][lk + 1]], "setup_" + itos(lk) + "_" + itos(jx) + "_" + itos(jy));
		}
	}
	//2.4 提前拖期约束
	/*for (int l = 0; l < h; l++) {
		model.addConstr(tt[l] - te[l] + dl[l] == t[g - 1][B[l][0]], "jit_" + itos(l));
	}*/
	//2.5 机器能力约束
	for (int i = 0; i < g - 1; i++)
	{
		for (int j = 0; j < n; j++)
		{
			for (int r = 0; r < n; r++)
			{
				for (int k = 0; k < Mk[i]; k++)
				{
					int tmp = 3 - m_x[i][j][k] - m_x[i][r][k] - m_y[i][j][r];
					if (tmp == 0)
					{
						model.addConstr(tvar[i][r] - tvar[i][j] - P[i][j] >= 0, "cap_" + itos(i + 1) + "_" + itos(j + 1) + "_" + itos(r + 1) + "_" + itos(k + 1));
					}
				}
			}
		}
	}
	model.update();

	//3. 不可用时间约束

	if (m_forbidens.size()>0)
	{
		GRBVar*** zvar = new GRBVar**[g - 1];
		for (int i = 0; i < g-1; i++)
		{
			zvar[i] = new GRBVar*[n];
			for (int j = 0; j < n; j++)
			{
				int K = m_forbidens.size();
				zvar[i][j] = new GRBVar[K];
				for (int k = 0; k < K; k++)
				{
					zvar[i][j][k] = model.addVar(0, 1, 0.0, GRB_BINARY, "z_" + itos(i) + "_" + itos(j)); //目标系数为0	
				}							
			}
		}
		for (int r = 0; r < m_forbidens.size(); r++)
		{
			int i = std::get<0>(m_forbidens[r]);
			int k = std::get<1>(m_forbidens[r]);
			int st = std::get<2>(m_forbidens[r]);
			int ts = std::get<3>(m_forbidens[r]);			
			for (int j = 0; j < n; j++)
			{
				int tmp = 1 - m_x[i][j][k];
				if (tmp == 0)
				{
					model.addConstr(tvar[i][j] + P[i][j] <= (1 - zvar[i][j][r])*UT +st, "brks_" + itos(i + 1) + "_" + itos(j + 1) + "_" + itos(k + 1) + "_" + itos(k + 1));
					model.addConstr(tvar[i][j] >=  st +ts  - zvar[i][j][r] * UT, "brke_" + itos(i + 1) + "_" + itos(j + 1) + "_" + itos(r + 1) + "_" + itos(k + 1));
				}
			}						
		}
	}	
	model.update();
	//4. 开始求解
	GRBVar Cmax = model.addVar(0, UT, 1, GRB_INTEGER, "cmax");
	GRBLinExpr wt = 0;
	
	for (int j = 0; j < n; j++)
	{
		model.addConstr(Cmax >= tvar[g - 1][j]);
		for (int i = 0; i < g - 1; i++)
		{
			wt += (tvar[i + 1][j] - tvar[i][j] - P[i][j] - TF[i]);
		}
		wt -= 5 * Rho;
	}
	model.setObjective(C1*Cmax + C2*wt);
	model.optimize();
	double objF = model.get(GRB_DoubleAttr_ObjVal);
	calcSubgradient(sg);
	for (int j = 0; j < n; j++)
	{
		for (int i = 0; i < g; i++)
		{
			m_t[i][j] = (int)tvar[i][j].get(GRB_DoubleAttr_X);
			//cout<<" t"<<i<<","<<j<<"="<<m_t[i][j];		
		}
		//cout<<endl;	
	}
	return objF;
}

void jaLROA::fullScheduling1(double& f_new, double& p_new)
{
	double f10 = optimizeX();  // Calculate the optimal value of the assign variable part.
	double f11 = optimizeY();  // Calculate the  optimal value of the order variable part
	double f2 = LagrangianLP1(); // Calculate the optimal value of the continuous part and subgradient .
	f_new = (3 * sum4Array(mu) - f10 - f11) * U - f2; //-L
	feasiblize(); //可行化
	p_new = primalLP();
	cout << "f=" << f_new << "   p=" << p_new << endl;
}

double jaLROA::LagrangianLP1()
{
	GRBEnv env = GRBEnv();
	GRBModel model = GRBModel(env);
	model.getEnv().set(GRB_IntParam_LazyConstraints, 1);
	//1.决策变量
	//1.1时间变量,t(i,j)
	GRBVar** tvar = new GRBVar*[g];
	for (int i = 0; i < g; i++)
	{
		tvar[i] = new GRBVar[n];
		for (int j = 0; j < n; j++)
		{
			if (i == 0)
			{
				tvar[i][j] = model.addVar(0.0, UT, 0.0, GRB_INTEGER, "t_" + itos(i) + "_" + itos(j)); //目标系数为-1
			}
			else if (i == g - 1)
			{
				tvar[i][j] = model.addVar(0.0, UT, 0.0, GRB_INTEGER, "t_" + itos(i) + "_" + itos(j)); //目标系数为1
			}
			else
			{
				tvar[i][j] = model.addVar(0.0, UT, 0.0, GRB_INTEGER, "t_" + itos(i) + "_" + itos(j)); //目标系数为0
			}
		}
	}
	model.update();
	
	//2.增加约束条件
	//2.1工序顺序约束
	for (int j = 0; j < n; j++)
	{
		for (int i = 0; i < g - 1; i++)
		{
			if (i < g - 2)
			{
				model.addConstr(tvar[i + 1][j] - tvar[i][j] - P[i][j] >= TF[i], "stage_" + itos(i) + "_" + itos(i + 1) + "_" + itos(j));
			}
			else
			{
				model.addConstr(tvar[i + 1][j] - tvar[i][j] - P[i][j] >= TF[i] + 5 * Rho, "stage_" + itos(i) + "_" + itos(i + 1) + "_" + itos(j));
			}
		}
		//model.addConstr(t[0][j] >= R[j], "rlst_" + itos(j));
	}
	//2.2 连浇约束
	for (int l = 0; l < h; l++)
	{
		for (int j = 0; j < nl[l] - 1; j++)
		{
			int j1 = B[l][j];    //
			int j2 = B[l][j + 1];  //
			model.addConstr(tvar[g - 1][j1] + P[g - 1][j1] == tvar[g - 1][j2], "cast_" + itos(l) + "_" + itos(j1) + "_" + itos(j2));
		}
	}
	//2.3 准备时间约束
	for (int k = 0; k < Mk[g - 1]; k++)
	{
		for (int lk = 0; lk < hk[k] - 1; lk++)
		{
			int jx = be[Bk[k][lk]]; //最后一个工件
			int jy = bs[Bk[k][lk + 1]];
			model.addConstr(tvar[g - 1][jy] - tvar[g - 1][jx] - P[g - 1][jx] >= SU[Bk[k][lk + 1]], "setup_" + itos(lk) + "_" + itos(jx) + "_" + itos(jy));
		}
	}
	model.update();
	
	//3.目标函数
	GRBVar cmax = model.addVar(0.0, UT, 0.0, GRB_INTEGER, "Cmax");
	GRBLinExpr wt = 0;
	for (int j = 0; j < n; j++)
	{
		model.addConstr(cmax >= tvar[g - 1][j]);
		for (int i = 0; i < g - 1; i++)
		{
			wt += (tvar[i + 1][j] - tvar[i][j] - P[i][j] - TF[i]);
		}
		//wt -= 5 * Rho;
	}
	//GRBLinExpr cb = 0;
	//for (int l = 0; l < h; l++)
	//{
	//	for (int j = 0; j < nl[l] - 1; j++)
	//	{
	//		int j1 = B[l][j];    //
	//		int j2 = B[l][j + 1];  //
	//		cb += tvar[g - 1][j2] - tvar[g - 1][j1] - P[g - 1][j1];
	//	}
	//}
	GRBLinExpr obj = C1*Cmax + C2*wt;
	//model.setObjective(obj+cmax);
	for (int i = 0; i < g - 1; i++)
	{
		for (int j = 0; j < n; j++)
		{
			for (int r = 0; r < n; r++)
			{
				if (j == r) continue;
				for (int k = 0; k < Mk[i]; k++)
				{
					obj += (tvar[i][r] - tvar[i][j] - P[i][j])*mu[i][j][r][k];
				}
			}
		}
	}
	model.setObjective(obj);
	model.update();

	//4.优化
	model.optimize();
	double objF = model.get(GRB_DoubleAttr_ObjVal);
	//cout<<"lr_obj1 value["<<0 <<"]="<<lr_obj1<<endl;

	calcSubgradient(sg);

	for (int j = 0; j < n; j++)
	{
		for (int i = 0; i < g; i++)
		{
			m_t[i][j] = (int)tvar[i][j].get(GRB_DoubleAttr_X);
		//	DbgPrint("t[%d,%d] = %d \n",i+1,j+1, m_t[i][j]);				
		}		
	}
	return objF;
}

double jaLROA::primalLP()
{
	GRBEnv env = GRBEnv();
	GRBModel model = GRBModel(env);
	model.getEnv().set(GRB_IntParam_LazyConstraints, 1);
	GRBVar** tvar = nullptr;
	//1.决策变量
	//1.1时间变量,t(i,j)
	tvar = new GRBVar*[g];
	for (int i = 0; i<g; i++)
	{
		tvar[i] = new GRBVar[n];
		for (int j = 0; j<n; j++)
		{
			if (i == 0)
			{
				tvar[i][j] = model.addVar(0.0, UT, -1.0*C1, GRB_INTEGER, "t_" + itos(i) + "_" + itos(j)); //目标系数为-1
			}
			else if (i == g - 1)
			{
				tvar[i][j] = model.addVar(0.0, UT, 1.0*C1, GRB_INTEGER, "t_" + itos(i) + "_" + itos(j)); //目标系数为1
			}
			else
			{
				tvar[i][j] = model.addVar(0.0, UT, 0.0, GRB_INTEGER, "t_" + itos(i) + "_" + itos(j)); //目标系数为0
			}
		}
	}
	model.update();


	//2.增加约束条件
	//2.1工序顺序约束
	for (int j = 0; j < n; j++)
	{
		int upt = 0;
		for (int i = 0; i<g - 1; i++)
		{
			upt += P[i][j]+TF[i];
			if (i < g - 2)
			{
				model.addConstr(tvar[i + 1][j] - tvar[i][j] - P[i][j] >= TF[i], "stage_" + itos(i) + "_" + itos(i + 1) + "_" + itos(j));
			}
			else
			{
				model.addConstr(tvar[i + 1][j] - tvar[i][j] - P[i][j] >= TF[i] + 5 * Rho, "stage_" + itos(i) + "_" + itos(i + 1) + "_" + itos(j));
			}			
		}
		//int std_fl = (1 + 0.1*Lamda)*upt;
		//model.addConstr(tvar[g-1][j]-tvar[0][j] >= std_fl, "rlst_" +  itos(j));
	}
	//2.2 连浇约束
	for (int l = 0; l < h; l++)
	{
		for (int j = 0; j<nl[l] - 1; j++)
		{
			int j1 = B[l][j];    //
			int j2 = B[l][j + 1];  //
			model.addConstr(tvar[g - 1][j1] + P[g - 1][j1] == tvar[g - 1][j2], "cast_" + itos(l) + "_" + itos(j1) + "_" + itos(j2));
		}
	}
	//2.3 准备时间约束
	for (int k = 0; k<Mk[g - 1]; k++)
	{
		for (int lk = 0; lk<hk[k] - 1; lk++)
		{
			int jx = be[Bk[k][lk]]; //最后一个工件
			int jy = bs[Bk[k][lk + 1]];
			model.addConstr(tvar[g - 1][jy] - tvar[g - 1][jx] - P[g - 1][jx] >= SU[Bk[k][lk + 1]], "setup_" + itos(lk) + "_" + itos(jx) + "_" + itos(jy));
		}
	}
	////2.6 能力约束，需要松弛的变量
	for (int i = 0; i<g - 1; i++)
	{		
		for (int k = 0; k<Mk[i]; k++)
		{
			for (int j = 0; j<m_jc[i][k] - 1; j++)
			{
				int j1 = m_jl[i][k][j];
				int j2 = m_jl[i][k][j + 1];
				model.addConstr(tvar[i][j2] - tvar[i][j1] - P[i][j1] >= 0);
			}
		}
	}
	model.update();
	//3. 目标函数
	GRBVar Cmax = model.addVar(0, UT, 1, GRB_INTEGER, "cmax");
	GRBLinExpr wt = 0;
	for (int j = 0; j<n; j++)
	{
		model.addConstr(Cmax >= tvar[g - 1][j]);
		for (int i = 0; i < g - 1; i++)
		{
			wt += (tvar[i+1][j] - tvar[i][j]- P[i][j] -TF[i]);
		}	
		wt -= 5 * Rho;
	}	

	//GRBLinExpr cb = 0;
	//for (int l = 0; l < h; l++)
	//{
	//	for (int j = 0; j < nl[l] - 1; j++)
	//	{
	//		int j1 = B[l][j];    //
	//		int j2 = B[l][j + 1];  //
	//		cb += tvar[g - 1][j2] - tvar[g - 1][j1] - P[g - 1][j1];
	//	}
	//}
	model.setObjective(C1*Cmax+C2*wt);
	//4.求解
	model.optimize();

	for (int j = 0; j<n; j++)
	{
		for (int i = 0; i<g; i++)
		{
			m_t[i][j] = (int)tvar[i][j].get(GRB_DoubleAttr_X);
			////cout<<" t"<<i<<","<<j<<"="<<m_t[i][j];		
			//DbgPrint("t[%d][%d] = %d \n", i, j, m_t[i][j]);
		}
		//cout<<endl;	
	}

	return model.get(GRB_DoubleAttr_ObjVal);
}

double jaLROA::optimizeX()
{
	//利用启发式算法求解 Xijk 
	double localF = 0.0;
	for (int i = 0; i < g - 1; i++)
	{
		double* mux = new double[Mk[i]];
		for (int j = 0; j < n; j++)
		{
			for (int k = 0; k < Mk[i]; k++)
			{
				mux[k] = 0.0;
			}
			for (int k = 0; k < Mk[i]; k++)
			{
				for (int r = 0; r < n; r++)
				{
					mux[k] += mu[i][j][r][k] + mu[i][r][j][k];
				}
			}
			//选择最小的,设置 Xijk
			int kx = 0; double min_mux = std::numeric_limits<double>::max();
			for (int k = 0; k < Mk[i]; k++)
			{
				m_x[i][j][k] = 0;
				if (min_mux > mux[k])
				{
					min_mux = mux[k];
					kx = k;
				}
			}
			m_x[i][j][kx] = 1;
			//cout<<"("<<i<<","<<j<<","<<kx<<")"<<"=1"<<endl;
			localF += min_mux;
		}
		delete mux;
	}
	//2.1 计算目标函数
	localF = localF;
	cout << "LR-X obj value =" << localF << endl;
	return localF;
}

double jaLROA::optimizeY()
{
	//利用启发式算法求解 Yijr	
	double localF = 0.0;
	double muy1 = 0.0;
	double muy2 = 0.0;
	for (int i = 0; i < g - 1; i++)
	{
		for (int j = 0; j < n - 1; j++)
		{
			for (int r = j; r < n; r++)
			{
				muy1 = 0.0;	muy2 = 0.0;
				for (int k = 0; k < Mk[i]; k++)
				{
					muy1 = muy1 + mu[i][j][r][k]; // Sum all related coefficients about y_ijr.
					muy2 = muy2 + mu[i][r][j][k]; // Sum all related coefficients about y_irj.
				}
				if (muy1 < muy2)
				{
					localF = localF + muy1;
					m_y[i][j][r] = 1;
					m_y[i][r][j] = 0;
				}
				else
				{
					localF = localF + muy2;
					m_y[i][j][r] = 0;
					m_y[i][r][j] = 1;
				}
			}
		}

	}
	//2.1 计算目标函数
	localF = localF;
	cout << "LR-Y obj value =" << localF << endl;
	return localF;
}

double**** jaLROA::copyValue(double**** old)
{
	double**** new_array = new double***[g - 1];
	for (int i = 0; i < g - 1; i++) {
		new_array[i] = new double**[n];
		for (int j = 0; j < n; j++) {
			new_array[i][j] = new double*[n];
			for (int r = 0; r < n; r++) {
				new_array[i][j][r] = new double[Mk[i]];
				for (int k = 0; k < Mk[i]; k++) {
					new_array[i][j][r][k] = old[i][j][r][k];
				}
			}
		}
	}
	return new_array;
}

int* jaLROA::sortByST(int* tt, int nt)
{
	int* Tj = new int[nt];
	for (int i = 0; i <nt; i++)
	{
		Tj[i] = i;
		//cout<<i<<"="<<tt[i]<<endl;
	}
	for (int i = 0; i <nt; i++)
	{
		for (int j = i; j < nt; j++)
		{
			if (tt[i] > tt[j])
			{
				int temp = tt[i];
				tt[i] = tt[j];
				tt[j] = temp;

				std::swap(Tj[i], Tj[j]);
			}
		}
	}
	/*cout<<"-----------------------SORT-------------------------"<<endl;
	for (int i = 0; i <nt; i++)
	{
	cout<<Tj[i]<<"---"<<tt[i]<<endl;
	}*/
	return Tj;
}

double jaLROA::norm4Array(double**** ary)
{
	double norm = 0.0;
	//计算向量范数
	for (int i = 0; i<g - 1; i++)
	{
		for (int j = 0; j<n; j++)
		{
			for (int r = 0; r<n; r++)
			{
				for (int k = 0; k<Mk[i]; k++)
				{
					if (j != r)
					{

						norm += ary[i][j][r][k] * ary[i][j][r][k];
					}
					/*else
					{
					cout<<ary[i][j][r][k]<<endl;
					}*/
				}
			}
		}
	}
	return norm;
}

double jaLROA::sum4Array(double**** ary)
{
	double sumx = 0.0;
	for (int i = 0; i < g - 1; i++)
	{
		for (int j = 0; j < n; j++)
		{
			for (int r = 0; r < n; r++)
			{
				for (int k = 0; k < Mk[i]; k++)
				{
					if (j != r)
					{
						sumx += ary[i][j][r][k];
					}
				}
			}
		}
	}
	return sumx;
}

bool jaLROA::init_batch_time()
{
	for each(auto mach in m_pProblem->getMachineMap())
	{
		mach.second->setReleaseTime(0);
	}

	for each(auto batch in m_pProblem->getBatchMap())
	{
		jaBatch* pBatch = batch.second;
		jaMachine* pTailMach = nullptr;
		int tail_rlst = 1.0e6;
		for (int k = 0; k < m_pProblem->MachMatrix()[g-1].size(); k++)
		{
			jaMachine* pMach = m_pProblem->MachMatrix(g - 1, k);
			if (pMach->getReleaseTime()<tail_rlst)
			{
				pTailMach = pMach; tail_rlst = pMach->getReleaseTime();
			}
		}			

		jaMachine* pHeadMach = nullptr;
		int head_rlst = 1.0e6;
		for (int k = 0; k < m_pProblem->MachMatrix()[0].size(); k++)
		{
			jaMachine* pMach = m_pProblem->MachMatrix(0, k);
			if (pMach->getReleaseTime() < head_rlst)
			{				
				pHeadMach = pMach; head_rlst = pMach->getReleaseTime();
			}
		}
		jaOperation* pTailOper = pBatch->getOperMap().begin()->second;
		int plan_dd = std::max(pTailMach->getReleaseTime() + pBatch->getSetupTime(),  pHeadMach->getReleaseTime() + pTailOper->getPrevLoad());

		int TAIL_PT = 0, HEAD_PT = 0;
		for (const auto& kvp : pBatch->getOperMap())
		{
			jaJob* pJob = ((jaOperation*)kvp.second)->getJob();
			HEAD_PT += pJob->getOperMap().begin()->second->getProcessTime();
			HEAD_PT += pJob->getOperMap().rbegin()->second->getProcessTime();
		}
		pHeadMach->setReleaseTime(head_rlst + HEAD_PT);
		pTailMach->setReleaseTime(plan_dd + TAIL_PT);

		int l = pBatch->getSerialNo() - 1;
		dl[l] = plan_dd;		
	}

	return false;
}

bool jaLROA::retrieve_solution(Sequence& seq)
{
	this->m_Cmax = 0;
	for (int i = 0; i < g; i++)
	{
		for (int k = 0; k < Mk[i]; k++)
		{
			string machID = jaCommon::format("%d%d", i + 1, k + 1);
			jaMachine* pMach = this->m_pProblem->getMachineMap()[machID];
			for (list<jaOperation*>::iterator it = pMach->getProcessList().begin();
				it!= pMach->getProcessList().end(); it++)//遍历 O(i,j)-O(i,j)
			{
				jaOperation* pOper= *it;
				int st = pOper->getStartTime();
				int et = pOper->getFinishTime();
				int j = pOper->getJob()->getSerialNo() - 1;
				seq[i][j]->S = st;
				seq[i][j]->C = et;
				seq[i][j]->S = st;
				seq[i][j]->C = et;
				seq[i][j]->k = k;	
				seq[i][j]->u = 0;
				if (et > m_Cmax) m_Cmax = et;
			}
		}
	}
	return true;
}

bool jaLROA::embed_slolution(Sequence& sequence, vector<tuple<int, int, int, int>>& forbidens)
{
	for (int  i = 0; i < g -1; i++)
	{
		for (int j = 0; j < n; j++)
		{
			this->P[i][j] = sequence[i][j]->P;
		}
	}
	this->m_forbidens = forbidens;
	return true; 
}
