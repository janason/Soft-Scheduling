#include "jaMILPCP.h"
#include <jaSimulation/util/jaCommon.h>
#include <jaSimulation/util/jaRandom.h>
#include <time.h>
#include <numeric>
#include "jaLRRS.h"

jaMILPCP::jaMILPCP(string algo_name) :jaAlogrithm(algo_name)
{

}

bool jaMILPCP::initialize()
{
	this->m_LB = 0 - 1.0e10;
	this->m_UB = 1.0e10;
	this->LVAL = 1000;
	this->m_evt_time = 0;
	this->create_inputvars();
	this->create_dcivars();	
	this->DD.resize(NJ);
	this->UPT.resize(NJ);
	for (int j = 0; j < NJ; j++)
	{
		this->DD[j] = 0;	
		this->UPT[j] = 0;
		for (int i = 0; i < NG - 1; i++)
		{
			this->UPT[j] += PT[i][j] + TR[i][i + 1];
		}
		this->DD[j] = UPT[j];
	}
	return true;
}
/************************************************************************/
/* �Ľ��㣺0 ������ʼ��������ʽ�㷨
/************************************************************************/
bool jaMILPCP::run()
{
	//read_scenarios(m_pProblem->getProblemID());	
	int mode = 2;
	m_output << jaCommon::format("--[%d,%d-%d,%d]----------baseline  mode= %d------------------\n",Eta1,Eta2,Rho, Phi, mode);
	this->init_baseline(true);
	//calc_objective(m_online_sequence);	
	return true;
	for (int i = 0; i < scenarios.size(); i++ )
	{
		int r = std::get<0>(scenarios[i]);
		double x1 = std::get<1>(scenarios[i]);
		double x2 = std::get<2>(scenarios[i]);
		if (x1 < 0.8)
		{		
			this->preprocessing_O(r*0.1, x2);				
		}
		else
		{
			this->preprocessing_M(r*0.1, x2);
		}
		m_output << jaCommon::format("#%d------------@ %d \n", r, m_evt_time);
		clock_t start = clock();			
		bool rtv = false;
		if (mode == 1) 
		{
			rtv = MILP_solver();
		}
		if (mode == 0)
		{
			rtv = Hybrid_slover();
		} 		
		clock_t end = clock();
		if (rtv)
		{				
			float tm = (float)(end - start) / CLOCKS_PER_SEC;
			DbgPrint("[T=%d] obj= %.2f,time=%.3f \n ", r, tm);
			calc_objective(m_online_sequence);
			m_output << jaCommon::format("spend %.3f s \n",tm) ;
		}	
	}
	if (mode==2)
	{
		clock_t start = clock();
		jaLROA LR("LR");
		LR.setProblem(m_pProblem);
		LR.embed_slolution(m_online_sequence, break_machs);
		LR.initialize();		
		LR.run();  
		LR.output();		
		LR.retrieve_solution(m_online_sequence);
		clock_t end = clock();		
		float tm = (float)(end - start) / CLOCKS_PER_SEC;
		DbgPrint("[T=%d] obj= %.2f,time=%.3f \n ", scenarios.size()+1, tm);
		calc_objective(m_online_sequence);
		m_output << jaCommon::format("spend %.3f s \n", tm);
	}		
	this->output(); 
	return true;
}

/************************************************************************/
/* ��ʼ����׼����
/************************************************************************/
void jaMILPCP::init_baseline(bool isOpt)
{
	jaLRRS LR("LR");
	LR.setProblem(m_pProblem);
	LR.initialize();
	if (isOpt)
	{
		LR.run();   ///��һ���м���
		LR.output();
	}	
	//LR.retrieve_solution(m_online_sequence);
	//this->m_Cmax = LR.getCmax();
	DbgPrint("baseline initialization is end.....\n");
}

/**************************************
0: �����ӳ٣��ҵ���ǰʱ��㣬Ȼ��ѡ���һ����ʼ�Ĳ����������ӳ١�
1���������ϣ��ҵ�ʱ��㣬�ҵ���һ�����еĻ���������������Ϣ��
***************************************/
void jaMILPCP::preprocessing(double fi, double di, int ei)
{
	//1.ѡ���ӳٲ���	
	m_evt_time = std::max(this->m_Cmax*fi, 0.0);
	vector<pair<int, int>> Oij_vec;	
	do {
		for (int i = 0; i < NG - 1; i++)
		{
			for (int j = 0; j < NJ; j++)
			{
				int st = m_online_sequence[i][j]->S;
				int ft = m_online_sequence[i][j]->C;
				if (st <= m_evt_time && ft >= m_evt_time)
				{
					Oij_vec.push_back(make_pair(i, j));
					DbgPrint("%d,%d \n", i, j);
				}
			}
		}
		m_evt_time++;
	} while (Oij_vec.size() == 0);
	
	pair<int, int> Oij;
	if (ei==1) 
	{
		Oij = Oij_vec.back();
		int maxC = m_online_sequence[Oij.first][Oij.second]->C;
		for (int r = 1; r < Oij_vec.size(); r++)
		{
			pair<int, int> ij = Oij_vec[r];
			if (m_online_sequence[ij.first][ij.second]->C > maxC)
			{
				Oij = ij;
				maxC = m_online_sequence[ij.first][ij.second]->C;
			}
		}		
	}
	else
	{
		Oij = Oij_vec.back();
		int minC = m_online_sequence[Oij.first][Oij.second]->C;
		for (int r = 1; r < Oij_vec.size(); r++)
		{
			pair<int, int> ij = Oij_vec[r];
			if (m_online_sequence[ij.first][ij.second]->C < minC)
			{
				Oij = ij;
				minC = m_online_sequence[ij.first][ij.second]->C;
			}
		}
	}	

	tuple<int, int, int> delay_oper;
	int in = Oij.first;
	int jn = Oij.second;
	if (ei == 1)
	{		
		delay_oper = make_tuple(in, jn, (m_online_sequence[in][jn]->C - m_online_sequence[in][jn]->S)*(1.0 + di));
	}
	else
	{
		delay_oper = make_tuple(in, jn, (m_online_sequence[in][jn]->C - m_online_sequence[in][jn]->S) + m_Cmax*(di));
	}	
	//2. ���²���״̬,�����ص���
	for (int i = 0; i < NG; i++)
	{
		for (int j = 0; j < NJ; j++)
		{
			if (m_online_sequence[i][j]->C < m_evt_time)
			{
				m_online_sequence[i][j]->u = 2; //�����
			}
			else if (m_online_sequence[i][j]->S > m_evt_time)
			{
				m_online_sequence[i][j]->u = 0; //δ��ʼ
			}
			else
			{
				m_online_sequence[i][j]->u = 1; //�ѿ�ʼ
			}			
		}		
	}	
	m_online_sequence[in][jn]->C = m_online_sequence[in][jn]->S + std::get<2>(delay_oper);
	m_online_sequence[in][jn]->P = std::get<2>(delay_oper);	

	for (int j = 0; j < NJ; j++)
	{
		int i = NG - 2;
		if (m_online_sequence[i][j]->u>0)
		{
			DD[j] = m_online_sequence[i][j]->C + m_online_sequence[i][j]->T;
		}
	}
	return;
}

void jaMILPCP::preprocessing_O(double fi, double di)
{
	//1.ѡ����������Ĳ���
	m_evt_time = std::max(this->m_Cmax*fi, 0.0);
	vector<pair<int, int>> Oij_vec;
	do {
		for (int i = 0; i < NG - 1; i++)
		{
			for (int j = 0; j < NJ; j++)
			{
				int st = m_online_sequence[i][j]->S;
				int ft = m_online_sequence[i][j]->C;
				if (st <= m_evt_time && ft >= m_evt_time)
				{
					Oij_vec.push_back(make_pair(i, j));
				}
			}
		}
		m_evt_time++;
	} while (Oij_vec.size() == 0);

	//2. ���ѡ���ӳٲ���
	pair<int, int> Oij = Oij_vec.back();
	int maxC = m_online_sequence[Oij.first][Oij.second]->C;

	int in = Oij.first;
	int jn = Oij.second;	
	int et = m_evt_time;
	int ts = di;
	/*this->delay_oper = make_tuple(in, jn,
		(m_online_sequence[in][jn]->C - m_online_sequence[in][jn]->S)*(1.0 + di));*/
		
	//3. ���²���״̬,�����ص���
	for (int i = 0; i < NG; i++)
	{
		for (int j = 0; j < NJ; j++)
		{
			if (m_online_sequence[i][j]->C <= m_evt_time)
			{
				m_online_sequence[i][j]->u = 2; //�����
			}
			else if (m_online_sequence[i][j]->S > m_evt_time)
			{
				m_online_sequence[i][j]->u = 0; //δ��ʼ
			}
			else
			{
				m_online_sequence[i][j]->u = 1; //�ѿ�ʼ
			}
			if (i == NG-1) // update cast
			{
				int b = m_online_sequence[i][j]->b;
				m_online_cast[b]->u = 0;
				if (j == m_online_cast[b]->sj && m_online_sequence[i][j]->u >0)
				{
					m_online_cast[b]->u = 1;
				}
				if (j == m_online_cast[b]->ej && m_online_sequence[i][j]->u > 1)
				{
					m_online_cast[b]->u = 2;
				}
			}			
		}
	}

	m_online_sequence[in][jn]->C = m_online_sequence[in][jn]->C + ts;
	m_online_sequence[in][jn]->P = m_online_sequence[in][jn]->C - m_online_sequence[in][jn]->S;
	this->delay_opers.push_back(make_tuple(in, jn, et, ts));

	//2. �����ͷ�ʱ��
	for (int j = 0; j < NJ; j++)
	{
		int i = NG - 1;		
		DD[j] = m_online_sequence[i][j]->S;		
	}	
	return;
}

void jaMILPCP::preprocessing_M(double fi, double di)
{
	//1.ѡ����������Ļ���	
	m_evt_time = std::max(this->m_Cmax*fi, 0.0);
	vector<pair<int, int>> Mik_vec;	
	do {
		for (int i = 0; i < NG - 1; i++)
		{
			vector<int> Kvec(Mn[i], 0);
			for (int j = 0; j < NJ; j++)
			{
				int st = m_online_sequence[i][j]->S;
				int ft = m_online_sequence[i][j]->C;
				int kx = m_online_sequence[i][j]->k;
				if (st <= m_evt_time && ft >= m_evt_time)
				{
					Kvec[kx]++;
					//DbgPrint("%d,%d \n", i, j);
				}
			}
			for (int k = 0; k < Mn[i]; k++)
			{
				if (Kvec[k] == 0) Mik_vec.push_back(make_pair(i, k));
			}
		}
		m_evt_time++;
	} while (Mik_vec.size() == 0);
	
	//2. ���ѡ��
	srand(time(NULL));
	pair<int,int> Mik= Mik_vec[rand() % Mik_vec.size()];
	int in = Mik.first;
	int kn = Mik.second;
	int et = m_evt_time;
	int ts = 20 + di;
	if (in > 0)
		ts = 30 + di;
	this->break_machs.push_back(make_tuple(in, kn, et, ts));
	//3.���²���״̬,�����ص���
	for (int i = 0; i < NG; i++)
	{
		for (int j = 0; j < NJ; j++)
		{
			if (m_online_sequence[i][j]->C <= m_evt_time)
			{
				m_online_sequence[i][j]->u = 2; //�����
			}
			else if (m_online_sequence[i][j]->S > m_evt_time)
			{
				m_online_sequence[i][j]->u = 0; //δ��ʼ
			}
			else
			{
				m_online_sequence[i][j]->u = 1; //�ѿ�ʼ
			}

			if (i == NG - 1) // update cast
			{
				int b = m_online_sequence[i][j]->b;
				m_online_cast[b]->u = 0;
				if (j == m_online_cast[b]->sj && m_online_sequence[i][j]->u >0)
				{
					m_online_cast[b]->u = 1;
				}
				if (j == m_online_cast[b]->ej && m_online_sequence[i][j]->u > 1)
				{
					m_online_cast[b]->u = 2;
				}
			}
			
		}		
	}
	
	//2. �����ͷ�ʱ��
	for (int j = 0; j < NJ; j++)
	{
		int i = NG - 1;
		//if (m_online_sequence[i][j]->u>0)
		{
			DD[j] = m_online_sequence[i][j]->S;
		}
	}
	return;
}

void jaMILPCP::retiming_with_CP()
{	
	char name[20];
	IloEnv env;
	IloModel model(env);
	IloArray<IloArray<IloIntervalVarArray>> ma_oplist(env, NG);
	IloArray<IloIntervalVarArray> op_matrix(env, NG);
	IloIntervalSequenceVarArray2 ma_opseq(env, NG);
	IloExprArray costs(env);
	IloExprArray stability(env);
	IloExprArray penalty(env);
	//1.�����������
	for (size_t i = 0; i < NG - 1; i++)
	{
		ma_oplist[i] = IloArray<IloIntervalVarArray>(env, Mn[i]);
		op_matrix[i] = IloIntervalVarArray(env, NJ);
		for (size_t k = 0; k < Mn[i]; k++)
		{
			ma_oplist[i][k] = IloIntervalVarArray(env);
		}

		for (int j = 0; j < NJ; j++)
		{
			sprintf(name, "O_%d,%d", i, j);
			int st = m_online_sequence[i][j]->S;
			int et = m_online_sequence[i][j]->C;
			int kx = m_online_sequence[i][j]->k;
			op_matrix[i][j] = IloIntervalVar(env, PT[i][j], name);
			/*IloIntervalVarArray members(env);
			for (unsigned k = 0; k < Mn[i]; k++)
			{
				IloIntervalVar member(env, PT[i][j]);
				member.setOptional();
				members.add(member);
				ma_oplist[i][k].add(member);
			}
			model.add(IloAlternative(env, op_matrix[i][j], members));*/
			ma_oplist[i][kx].add(op_matrix[i][j]);
			if (i > 0) //ǰ����
			{
				model.add(IloEndOf(op_matrix[i - 1][j]) <= IloStartOf(op_matrix[i][j]) - TR[i - 1][i]);
			}
		}
	}
	//2.�������غ�Լ��
	for (int i = 0; i < NG - 1; i++)
	{
		for (int k = 0; k < Mn[i]; k++)
		{
			model.add(IloNoOverlap(env, ma_oplist[i][k]));
		}
	}
	//3. ����Լ��
	op_matrix[NG - 1] = IloIntervalVarArray(env, NJ);
	for (int j = 0; j < NJ; j++)
	{
		sprintf(name, "O_%d,%d", NG - 1, j);
		int st = m_online_sequence[NG - 1][j]->S;
		int et = m_online_sequence[NG - 1][j]->C;
		int kx = m_online_sequence[NG - 1][j]->k;
		op_matrix[NG - 1][j] = IloIntervalVar(env, PT[NG - 1][j], name);
	}

	for (IloInt k = 0; k < Mn[NG - 1]; k++)
	{
		int jx = -1;
		for (IloInt l = 0; l < Ng[k]; l++)
		{
			int b = Bg[k][l];
			IloIntervalVar prev;
			for (IloInt r = 0; r < Nb[b]; r++)
			{
				int j = B[b][r];
				model.add(IloEndBeforeStart(env, op_matrix[NG - 2][j], op_matrix[NG - 1][j],
					TR[NG - 2][NG - 1])); //ǰ�����Լ��				
				if (jx < 0) //1,1
				{
					op_matrix[NG - 1][j].setStartMin(Su[l]);
				}
				else if (r == 0 && jx >-1)//n,1
				{
					model.add(IloEndBeforeStart(env, op_matrix[NG - 1][jx], op_matrix[NG - 1][j], Su[l]));
				}
				else//���ڲ���Լ��IloEndAtStart���ɳ�) IloEndBeforeStart�����ڣ�
				{
					model.add(IloEndBeforeStart(env, op_matrix[NG - 1][jx], op_matrix[NG - 1][j], 0));
					penalty.add(IloStartOf(op_matrix[NG - 1][j]) - IloEndOf(op_matrix[NG - 1][jx]));					
				}				
				//stability.add(IloAbs(IloStartOf(op_matrix[NG - 1][j]) - std::get<0>(m_base_timetable[NG - 1][j]))); //����ƫ�����	
				//stability.add(IloAbs(IloEndOf(op_matrix[NG - 1][j]) - std::get<1>(m_base_timetable[NG - 1][j]))); //����ƫ�����
				costs.add(IloStartOf(op_matrix[NG - 1][j])-IloEndOf(op_matrix[0][j]));
				jx = j;
			}
		}
	}//model.add(IloNoOverlap(env, ma_oplist[NG-1][k]));  //ͬһ�����ϲ������غ�
	IloNumExprArray objArray(env);
	objArray.add(IloSum(penalty));
	objArray.add(IloSum(costs));
	model.add(IloMinimize(env, IloSum(costs)+IloSum(penalty)));
	//model.add(IloMinimize(env, IloStaticLex(env, objArray)));
	IloCP cp(model);
	cp.setParameter(IloCP::TimeLimit, 600);
	if (cp.solve())
	{
		DbgPrint("cp obj = %.3f \n", cp.getObjValue());
		for (int i = 0; i < NG; i++)
		{
			for (int j = 0; j < NJ; j++)
			{
				m_online_sequence[i][j]->S = cp.getStart(op_matrix[i][j]);
				m_online_sequence[i][j]->C = cp.getEnd(op_matrix[i][j]);
			}
		}		
	}
	else
	{
		DbgPrint("No solution found. \n");		
	}	
	env.end();
	return;
}


bool jaMILPCP::reset()
{
	return true;
}

void jaMILPCP::test()
{

}

void jaMILPCP::create_dcivars()
{
	//2. �������߱�������ʼʱ��
	m_st = new int*[NG];
	m_et = new int*[NG];
	for (int i = 0; i < NG; i++)
	{
		m_st[i] = new int[NJ];
		m_et[i] = new int[NJ];
		for (int j = 0; j < NJ; j++)
		{
			m_st[i][j] = 0;
			m_et[i][j] = 0;
		}
	}
}

void jaMILPCP::init_arrival()
{
	map<jaMachine*, int> rlst_map;
	map<jaMachine*, vector<jaBatch*>> bah_map;
	jaStage* pLStage = m_pProblem->getStageMap().rbegin()->second;
	for (auto kvp : pLStage->getMachineMap())
	{
		jaMachine* pMach = kvp.second;
		rlst_map.insert(make_pair(pMach, 0));
	}
	vector<pair<jaJob*, int>> oper_atime;
	for (auto kvp : m_pProblem->getBatchMap())
	{
		jaBatch* pBatch = kvp.second;
		jaMachine* pMach = pBatch->getAssignedMA();
		int  rlst = rlst_map[pMach] + pBatch->getSetupTime();
		for (auto kvp : pBatch->getOperMap())
		{
			jaOperation* pOper = kvp.second;
			pOper->setStartTime(rlst);
			rlst = rlst + pOper->getNoise()->getStdValue();
			jaOperation* pPrev = pOper->getPrevOper();
			int at = rlst;
			oper_atime.push_back(make_pair(pOper->getJob(), at));
		}
	}
	std::sort(oper_atime.begin(), oper_atime.end(),
		[](pair<jaJob*, int> a, pair<jaJob*, int> b) { return a.second< b.second; });
	long seed = static_cast<long>(time(0));
	for (unsigned j = 0; j < oper_atime.size(); j++)
	{
		string RID = jaCommon::format("R_%03d", j + 1);
		jaJob* pJob = oper_atime[j].first;
		int jx = pJob->getSerialNo() - 1;
		jaResource* pResc = m_pProblem->getRescMap()[RID];
		this->AT[jx] = pResc->getStoAT();
		if (pJob->getBatch()->getSerialNo() >= 3)
			AT[jx] += 100;
		pJob->setReleaseTime(AT[jx]);
		//DbgPrint("arrival %d = %d \n", jx, AT[jx]);
	}
	return;
}
//* ����1��T-Base
void jaMILPCP::runMasterMILP0(bool isFirst)
{
	IloEnv milpEnv;
	IloModel milpModel = IloModel(milpEnv);
	IloCplex milpCplex = IloCplex(milpModel);
	//1 ����ÿ��¯�ε����翪��עʱ��	
	IloIntVarArray T = IloIntVarArray(milpEnv, NJ, 0, 3000);
	//1.1 Cmax Լ��
	IloIntVar Cmax(milpEnv, 0, 3000, "Cmax");
	for (IloInt j = 0; j < NJ; j++) //����ط�Ҫ��״̬
	{
		char name[20];
		sprintf(name, "t_%d_%d", NG - 1, j);
		T[j].setName(name);
		if (m_online_sequence[NG - 1][j]->u>0)
		{
			milpModel.add(T[j] == m_online_sequence[NG - 1][j]->S);
		}
	}
	//-- ���� R[j] 
	for (IloInt j = 0; j < NJ; j++)
	{
		milpModel.add(T[j] >= DD[j]);
	}	
	//1.2 ����Լ��
	for (IloInt k = 0; k < Mn[NG - 1]; k++)
	{
		int jx = -1;
		for (IloInt l = 0; l < Ng[k]; l++)
		{
			int b = Bg[k][l];
			for (IloInt r = 0; r < Nb[b]; r++)
			{
				int j = B[b][r];
				milpModel.add(Cmax >= T[j] + PT[NG-1][j]);
				if (m_online_sequence[NG - 1][j]->u>1)
				{
					jx = j;
					continue;
				}
				if (r == 0)//n,1
				{
					if (jx < 0)
						milpModel.add(T[j] >= Su[b]);
					else
					{
						int bx = Bg[k][l - 1];
						int rx = Nb[bx] - 1;
						milpModel.add(T[j] - T[jx] == Su[b] + PT[NG - 1][jx]); //???
					}
				}
				else
				{
					milpModel.add(T[j] - T[jx] == PT[NG - 1][jx]);
				}
				jx = j;
			}
		}
	}
	
	milpModel.add(IloMinimize(milpEnv, Cmax*1.0)); //����Ŀ��

	milpCplex.setOut(milpEnv.getNullStream());
	milpCplex.solve();

	if (milpCplex.getStatus() == IloAlgorithm::Infeasible)
	{
		DbgPrint("No Solution \n");
		return;
	}
	//1. ������ι���Ľ�����
	for (IloInt b = 0; b < NB; b++)
	{
		for (IloInt r = 0; r < Nb[b]; r++)
		{
			int j = B[b][r];			
			DD[j] = (int)milpCplex.getValue(T[j]);
			m_online_sequence[NG - 2][j]->dd = milpCplex.getValue(T[j]) - TR[NG - 2][NG - 1];
			m_online_sequence[NG - 1][j]->S = milpCplex.getValue(T[j]);
			m_online_sequence[NG - 1][j]->C = m_online_sequence[NG - 1][j]->S + m_online_sequence[NG - 1][j]->P;
		}
	}
	double f1 = milpCplex.getValue(Cmax)*1.0;
	double f = milpCplex.getObjValue();
	DbgPrint("\n MP0 f=%.2f \n\n", f);
}

/************************************************************************/
/* ��������������
/* ���ϸı��ͷ�ʱ��ƽ�棬������⣬�е���֮ǰ�ķ�������㷨
/* 1.�������ʽ�����ơ� 
/************************************************************************/
//���������⣬��ʼ��ʱ�ͷ�ʱ��=0��
void jaMILPCP::runMasterMILP2(vector<int>& deltas)
{	
	IloEnv milpEnv;
	IloModel milpModel = IloModel(milpEnv);
	IloCplex milpCplex = IloCplex(milpModel);	
	//1 ����ÿ��¯�ε����翪��עʱ��	
	IloIntVarArray T= IloIntVarArray(milpEnv, NJ, 0, 3000); //ʱ��
	IloIntVarArray X = IloIntVarArray(milpEnv, NJ,0, 100); //����
	//IloIntVarArray Z = IloIntVarArray(milpEnv, NJ, 0, 1);
	IloConstraintArray Cons(milpEnv);
	//1.1 Cmax Լ��
	IloIntVar Cmax(milpEnv,0,3000,"Cmax");
	for (IloInt j = 0; j < NJ; j++) //����ط�Ҫ��״̬
	{
		char name[20];
		sprintf(name, "t_%d", j);		
		T[j].setName(name);	
		if (m_online_sequence[NG - 1][j]->u>0)
		{
			Cons.add(T[j] == m_online_sequence[NG - 1][j]->S);
		}
	}	
	//-- ���� R[j] + dealt[j]
	for (IloInt j = 0; j < NJ; j++)
	{
		if (m_online_sequence[NG - 1][j]->u==0)
		{
			Cons.add(T[j] >= DD[j]);
		}
	}
	double delta = 0.1*Phi;
	for (IloInt b = 0; b < NB; b++)
	{		
		for (IloInt r = 0; r < Nb[b]; r++)
		{
			int j = B[b][r];
			int lb = (1 - 0.0)*PT[NG - 1][j];
			int ub = (1 + delta)*PT[NG - 1][j];
			char name[20];
			sprintf(name, "X_%d", j);
			X[j].setName(name);
			if (m_online_sequence[NG - 1][j]->u == 2)
			{
				Cons.add(X[j] == m_online_sequence[NG-1][j]->P); //����ԭ���ٲ���
			}
			else if (m_online_sequence[NG - 1][j]->u < 2)
			{
				Cons.add(X[j] >= lb);
				Cons.add(X[j] <= ub);
			}
		}
	}
	//1.2 ����Լ��
	IloExpr Cbreak(milpEnv);
	for (IloInt k = 0; k < Mn[NG - 1]; k++)
	{
		int jx = -1;
		for (IloInt l = 0; l < Ng[k]; l++)
		{
			int b = Bg[k][l];
			for (IloInt r = 0; r < Nb[b]; r++)
			{
				int j = B[b][r];	
				Cons.add(Cmax >= T[j] + X[j]);				
				if (r == 0 )//n,1
				{
					if(jx < 0)
						Cons.add(T[j] >= Su[b]);
					else
					{
						int bx = Bg[k][l - 1];
						int rx = Nb[bx] - 1;
						Cons.add(T[j] - T[jx] >= Su[b] + X[jx]); //???
					}						
				}
				else 
				{
					Cons.add(T[j] - T[jx] >= X[jx]);
					Cbreak += (T[j] - T[jx] - X[jx]);
				}
				jx = j;
			}
		}
	}	
	milpModel.add(IloMinimize(milpEnv, Cbreak*100.0 + Cmax*1.0)); //����Ŀ��
	milpModel.add(Cons);
	milpCplex.setOut(milpEnv.getNullStream());
	//milpCplex.exportModel("xxx.lp");
	milpCplex.solve();

	if ((milpCplex.getStatus() == IloAlgorithm::Infeasible) ||
		(milpCplex.getStatus() == IloAlgorithm::InfeasibleOrUnbounded))
	{
		DbgPrint("MILP No Solution \n");		
		return;
	}

	
	//1. ������ι���Ľ�����
	for (IloInt b = 0; b < NB; b++)
	{
		for (IloInt r = 0; r < Nb[b]; r++)
		{
			int j = B[b][r];			
			DD[j] = milpCplex.getValue(T[j]);			
			m_online_sequence[NG - 2][j]->dd = milpCplex.getValue(T[j]) - TR[NG - 2][NG - 1];
			m_online_sequence[NG - 1][j]->S = milpCplex.getValue(T[j]);
			m_online_sequence[NG - 1][j]->C = m_online_sequence[NG - 1][j]->S + milpCplex.getValue(X[j]);
			m_online_sequence[NG - 1][j]->P = m_online_sequence[NG - 1][j]->C - m_online_sequence[NG - 1][j]->S;
		}
	}	
	double f1 = milpCplex.getValue(Cmax)*1.0;
	//double f2 = milpCplex.getValue(Vstab)*10.0;
	double f3 = milpCplex.getValue(Cbreak)*100.0;
	double f = milpCplex.getObjValue();
	DbgPrint("\n MP f1=%.2f,f2=%.2f,f3=%.2f,f=%.2f \n\n", f1, 0.0, f3, f1 + f3 + 0.0);
}


//��������⣬Ϊ�������Ч�ʣ�����ʹ������ʽ����ȷ������Ȼ����CPȷ��ʱ�䣬
//Flexible flow shop scheduling with uniform parallel machines
pair<int, int> jaMILPCP::runSlaveCP2(vector<int>& delta, Sequence& seqs)
{
	reallocate_bls(); //���·������
	char name[20];
	IloEnv cpEnv;
	IloModel cpModel(cpEnv);
	IloArray<IloArray<IloIntervalVarArray>> ma_oplist(cpEnv, NG - 1);
	IloArray<IloIntervalVarArray> op_matrix(cpEnv, NG - 1);
	int id = -1;
	int jd = -1;
	int kd = -1;
	int et = -1;
	int ts = -1;
	if (break_machs.size() > 0)
	{
		id = std::get<0>(break_machs.back());
		kd = std::get<1>(break_machs.back());
		et = std::get<2>(break_machs.back());
		ts = std::get<3>(break_machs.back());
	}	
	//1.�����������
	for (int i = 0; i < NG - 1; i++)
	{
		ma_oplist[i] = IloArray<IloIntervalVarArray>(cpEnv, Mn[i]);
		op_matrix[i] = IloIntervalVarArray(cpEnv, NJ);
		for (IloInt k = 0; k < Mn[i]; k++)
		{
			ma_oplist[i][k] = IloIntervalVarArray(cpEnv);
			if (i== id && k == kd && et == m_evt_time)
			{
				sprintf(name, "M_%d,%d_%d", id,kd, et);
				IloIntervalVar ma_break(cpEnv, ts, name);
				cpModel.add(IloStartOf(ma_break) == m_evt_time);
				cpModel.add(IloEndOf(ma_break) == m_evt_time + ts);
				ma_oplist[i][k].add(ma_break);
			}			
		}
		for (int j = 0; j < NJ; j++)
		{
			sprintf(name, "O_%d,%d", i, j);
			int PTX = m_online_sequence[i][j]->P;
			int k = m_online_sequence[i][j]->k;
			op_matrix[i][j] = IloIntervalVar(cpEnv, PTX, name);
			ma_oplist[i][k].add(op_matrix[i][j]);
						
			if (m_online_sequence[i][j]->u>0)
				cpModel.add(IloStartOf(op_matrix[i][j]) == m_online_sequence[i][j]->S);			
			if (i > 0)
				cpModel.add(IloEndOf(op_matrix[i - 1][j]) <= IloStartOf(op_matrix[i][j]) - TR[i - 1][i]);			
		}
	}	
	//3. �������غ�Լ��	
	for (IloInt i = 0; i < NG - 1; i++)
	{
		for (int k = 0; k < Mn[i]; k++)
		{
			cpModel.add(IloNoOverlap(cpEnv, ma_oplist[i][k]));
		}
	}	
	//4.Ŀ�꺯��,���ڳͷ�
	IloNumExprArray TT(cpEnv);
	IloNumExprArray TE(cpEnv);
	for (IloInt j = 0; j < NJ; j++)
	{
		TT.add(IloMax(0, IloEndOf(op_matrix[NG - 2][j]) + m_online_sequence[NG-2][j]->T- DD[j]));
		TE.add(IloMax(0, DD[j] - IloStartOf(op_matrix[0][j])- UPT[j] - 5*Rho));
		/*TT.add(100 * IloMax(0, IloStartOf(op_matrix[0][j]) + MAX_FL - DD[j]));
		TE.add(1.0 * IloMax(0, DD[j]-IloStartOf(op_matrix[0][j]) + MAX_FL));*/
	}
	cpModel.add(IloMinimize(cpEnv, 100*IloSum(TT)+10*IloSum(TE)));

	IloCP cp(cpModel);
	cp.setParameter(IloCP::TimeLimit, 120);
	int rtn_slack = 1.0e6;
	int rtn_no = -1;
	if (cp.solve())
	{
		delta.resize(NJ, 0);
		for (int j = 0; j < NJ; j++)
		{
			for (int i = 0; i < NG - 1; i++)
			{				
				seqs[i][j]->S = (int)cp.getStart(op_matrix[i][j]);
				seqs[i][j]->C = (int)cp.getEnd(op_matrix[i][j]);
				if (i > 0)
				{
					seqs[i - 1][j]->dd = seqs[i][j]->S - seqs[i - 1][j]->T;
				}
				if (i == NG - 2)
				{
					if (m_evt_time == 719 && (j == 42 || j == 32))
					{
						DbgPrint("%d-%d\n", m_online_sequence[1][32]->C, m_online_sequence[1][42]->C);
					}				
					delta[j] = 0;
					if ( seqs[i + 1][j]->u == 0) //�����ͷ�ʱ��
					{
						delta[j] = (int)cp.getValue(TT[j]);						
						int deltax = seqs[i][j]->C + seqs[i][j]->T - DD[j];
						if (deltax >0 && deltax < rtn_slack )
						{
							rtn_slack = deltax; rtn_no = j;
						}
					}
				}
			}
		}
		DbgPrint("SP= %.2f\n", cp.getObjValue());
	}
	else
	{
		if (cp.refineConflict())
		{
			std::ostringstream os;
			cp.writeConflict(os);
			DbgPrint("%s", os.str().c_str());
		}
		DbgPrint("No solution found. \n");
	}
	cpEnv.end();
	return make_pair(rtn_slack, rtn_no);
}


//�����������
void jaMILPCP::create_inputvars()
{
	//1.��ʼ����ͻ�������
	NG = m_pProblem->getStageMap().size();; //��������
	Mn = new int[NG];
	Mn[0] = 0;
	int i = 0;
	for (const auto& kvp : m_pProblem->getStageMap())
	{
		jaStage* pStage = kvp.second;
		Mn[i] = pStage->getMachineMap().size();		
		i++;
	}
	//2.��ʼ��¯�μ��ϼ��䵽��ʱ��
	NJ = m_pProblem->getJobMap().size(); //¯������
	J = new int[NJ]; //¯�μ��� 
	AT = new int[NJ];
	for (int j = 0; j < NJ; j++)
	{
		J[j] = j; //�������
		string jobID = jaCommon::format("J_%03d", j + 1);
		jaJob* pJob = m_pProblem->getJobMap()[jobID];
		AT[j] = pJob->getReleaseTime();
	}
	//3.��ʼ��������Ϣ
	NB = m_pProblem->getBatchMap().size();    //������	
	B = new int*[NB]; //���μ���
	BE = new int[NB]; //����β¯�����		
	BS = new int[NB]; //������¯�����
	Su = new int[NB]; //����׼��ʱ��
	this->Nb = new int[NB];
	for (int b = 0; b < NB; b++)
	{
		string bahID = jaCommon::format("H_%02d", b + 1);
		jaBatch* pBatch = m_pProblem->getBatchMap()[bahID];
		Nb[b] = pBatch->getOperMap().size();
		B[b] = new int[Nb[b]];
		int r = 0;
		for (const auto& kvp : pBatch->getOperMap())
		{
			jaJob* pJob = ((jaOperation*)kvp.second)->getJob();
			B[b][r] = pJob->getSerialNo() - 1;
			if (r == 0) { BS[b] = B[b][r]; }
			r++;
		}
		BE[b] = B[b][r - 1]; //�������һ���������		
		Su[b] = pBatch->getSetupTime();
	}
	//4. ����ʱ�䣬��Ҫ���Ķ�ά����
	TR = new int*[NG];
	for (int i1 = 0; i1 < NG; i1++)
	{
		TR[i1] = new int[NG];
		for (int i2 = 0; i2 < NG; i2++)
		{
			TR[i1][i2] = std::max(i2-i1,0)*5;
		}
	}
	//5. ����·����Ϣ
	Gj = new int[NJ];
	GJ = new int*[NJ];
	Ji = new int[NG];
	JI = new int*[NG];
	PT = new int*[NG];
	for (int j = 0; j < NJ; j++)
	{
		string jobID = jaCommon::format("J_%03d", j + 1);
		jaJob* pJob = m_pProblem->getJobMap()[jobID];
		Gj[j] = pJob->getOperMap().size();
		GJ[j] = new int[Gj[j]];
		Gj[j] = 0;
	}
	//6.����ʱ��
	for (int i = 0; i < NG; i++)
	{
		PT[i] = new int[NJ];
		jaStage* pStage = m_pProblem->getStageMap()[jaCommon::format("%d", i + 1)];
		Ji[i] = pStage->getOperMap().size();
		JI[i] = new int[Ji[i]];
		for (int j = 0, r = 0; j < NJ; j++)
		{
			string operID = jaCommon::format("O_%d_%03d", i + 1, j + 1);
			PT[i][j] = 0;
			map<string, jaOperation*>::iterator it = m_pProblem->getOperMap().find(operID);
			if (it == m_pProblem->getOperMap().end())
			{
				map<string, jaMachine*>::iterator itx = pStage->getMachineMap().begin();
				for (; itx != pStage->getMachineMap().end(); itx++)
				{
					int k = itx->second->getSerialNo() - 1;
					PT[i][j] = 0;
				}
			}
			else
			{
				jaOperation* pOper = it->second;
				map<jaMachine*, jaNosiedPT*>::iterator itx = pOper->getMachineTimeSet().begin();
				int xpt = 0;
				for (; itx != pOper->getMachineTimeSet().end(); itx++)
				{
					int k = itx->first->getSerialNo() - 1;
					xpt += itx->second->m_nStdPT;
				}
				PT[i][j] = xpt / pOper->getMachineTimeSet().size();
				JI[i][r++] = j;
				GJ[j][Gj[j]++] = i;
				pOper->setProcessTime(PT[i][j]);
				jaOperation* pPrev = pOper->getPrevOper();
				if (pPrev != nullptr)
				{
					if (pOper->getSerialNo() - pPrev->getSerialNo() > 1)
					{
						pOper->setTransTime(10);
					}
					else {
						pOper->setTransTime(5);
					}
				}
			}
		}
	}
	//7. �����������Ϳ���ʱ��	
	Bg = new int*[Mn[NG - 1]];
	Ng = new int[Mn[NG - 1]];
	for (int k = 0; k < Mn[NG - 1]; k++)
	{
		Ng[k] = 0;
		Bg[k] = new int[NB];
	}
	for (auto kvp : m_pProblem->getBatchMap())
	{
		jaBatch* pBatch = kvp.second;
		int ln = pBatch->getSerialNo();
		int kn = pBatch->getAssignedMA()->getSerialNo();
		Bg[kn - 1][Ng[kn - 1]] = ln - 1;
		Ng[kn - 1] = Ng[kn - 1] + 1;
	}
	//8.��ʼ����������
	m_online_sequence.resize(NG);
	for (int i = 0; i < NG; i++)
	{
		jaStage* pStage = m_pProblem->getStageMap()[jaCommon::format("%d", i + 1)];
		m_online_sequence[i].resize(NJ);
		for (int j = 0, r = 0; j < NJ; j++)
		{
			string operID = jaCommon::format("O_%d_%03d", i + 1, j + 1);
			map<string, jaOperation*>::iterator it = m_pProblem->getOperMap().find(operID);
			if (it != m_pProblem->getOperMap().end())
			{
				jaOperation* pOper = it->second;
				jaTask* task = new jaTask(operID);
				task->i = i; 
				task->j = j; 
				task->P = PT[i][j];
				task->b = pOper->getJob()->getBatch()->getSerialNo() - 1;
				if(i<NG-1)
					task->T = TR[i][i + 1];
				m_online_sequence[i][j] =  task;
			}
		}
	}

	m_online_cast.resize(NB);
	for (auto kvp : m_pProblem->getBatchMap())
	{
		jaBatch* pBatch = kvp.second;
		int k = pBatch->getAssignedMA()->getSerialNo() -1;
		for (auto item : pBatch->getOperMap())
		{
			int j = item.second->getJob()->getSerialNo() - 1;
			m_online_sequence[NG - 1][j]->k = k;
		}

		int b = pBatch->getSerialNo() - 1;
		jaXTask* pCast = new jaXTask(pBatch->getHandleID());
		pCast->b = b;
		pCast->k = k;
		pCast->u = 0;
		pCast->sj = BS[b];
		pCast->ej = BE[b];
		m_online_cast[b] = pCast;
	}
	return;
}

//**��ǰ��,�ٵ���
void jaMILPCP::init_soln_by_rule(int rule)
{
	//int*** jl = new int**[NG - 1]; //ÿ�������ϵ���������

	//1. ���ռƻ�ʱ�䵹�ţ�������������Ŀ�ʼʱ��	
	int UT = LVAL;
	vector<int> MRLTs(Mn[NG - 1], 0);
	for (int k = 0; k <Mn[NG - 1]; k++)// ÿ�����������Ͻ�����
	{
		for (int i = 0; i<Ng[k]; i++)
		{
			int b = Bg[k][i];
			MRLTs[k] += Su[b]; //׼��ʱ��
			for (int r = 0; r < Nb[b]; r++)
			{
				int j = B[b][r];
				m_st[NG - 1][j] = MRLTs[k];
				MRLTs[k] = m_st[NG - 1][j] + PT[NG - 1][j];
			}
		}
	}
	//2. ������� with dispatching rules. 	
	for (int i = NG - 2; i >= 0; i--)
	{
		//2.1 ���񻺳���г�ʼ��
		vector<pair<int, int>> buff_list(Ji[i]); //id,at
		for (int r = 0; r < Ji[i]; r++)
		{
			int j = JI[i][r];
			int q = 0;
			for (; q < Gj[j]; q++)
			{
				if (GJ[j][q] == i) break;
			}
			int ix = GJ[j][q + 1];
			buff_list[r] = make_pair(j, m_st[ix][j] - TR[i][ix]);
		}
		//2.2 ����ѡ��
		std::sort(begin(buff_list), end(buff_list), [](pair<int, int>& a, pair<int, int>b)
		{return a.second > b.second; }); //��������
		vector<tuple<int, int, int>> job_list;
		MRLTs.resize(Mn[i]);
		for (int k = 0; k < Mn[i]; k++)
		{
			MRLTs[k] = buff_list.front().second;
		}
		while (!buff_list.empty())
		{
			int rls_ma = 0;
			int rls_tt = -1.0e3;
			int rls_jb = -1;
			//a. ����ָ��
			for (int k = 0; k < Mn[i]; k++) //����ָ�������ͷŵĻ���
			{
				if (MRLTs[k] >= rls_tt)
				{
					rls_ma = k; rls_tt = MRLTs[k];
				}
			}
			if (rule == RULE_BW_EAM) // ����ѡ�������ͷŵĹ���
			{
				if (buff_list.front().second >= rls_tt)
				{
					rls_jb = buff_list.front().first;
					rls_tt = buff_list.front().second;
					buff_list.erase(buff_list.begin());

					MRLTs[rls_ma] = rls_tt - PT[i][rls_jb];
					m_st[i][rls_jb] = rls_tt - PT[i][rls_jb];
					job_list.push_back(make_tuple(rls_jb, rls_ma, m_st[i][rls_jb]));
				}
				else
				{
					MRLTs[rls_ma] = MRLTs[rls_ma] - 1;
				}
			}
			if (rule == RULE_BW_SRM)
			{
				vector<int> idx_pool;
				for (int r = 0; r < buff_list.size(); r++)
				{
					if (buff_list[r].second >= rls_tt)
					{
						idx_pool.push_back(r);
					}
				}
				if (!idx_pool.empty())
				{
					double idx = idx_pool[0];
					double priority = buff_list[idx].second - AT[buff_list[idx].first];
					for (int id = 1; id < idx_pool.size(); id++)
					{
						double xi = idx_pool[id];
						double xp = buff_list[xi].second - AT[buff_list[xi].first];
						if (xp < priority)
						{
							priority = xp; idx = xi;
						}
					}
					rls_jb = buff_list[idx].first;
					rls_tt = buff_list[idx].second;
					buff_list.erase(buff_list.begin() + idx);
					MRLTs[rls_ma] = rls_tt - PT[i][rls_jb];
					m_st[i][rls_jb] = rls_tt - PT[i][rls_jb];
					job_list.push_back(make_tuple(rls_jb, rls_ma, m_st[i][rls_jb]));
				}
				else
				{
					MRLTs[rls_ma] = MRLTs[rls_ma] - 1;
				}
			}
		}
		//2.4 update binary variable
		std::sort(begin(job_list), end(job_list), [](tuple<int, int, int>& a, tuple<int, int, int>& b) {return std::get<2>(a) < std::get<2>(b); });
		vector<vector<int>> job_mlist(Mn[i]);
		for (int r = 0; r < job_list.size(); r++)
		{
			int j = std::get<0>(job_list[r]);
			for (int k = 0; k < Mn[i]; k++)
			{
				if (k == std::get<1>(job_list[r]))
				{
					job_mlist[k].push_back(j);
				}
			}
		}
		for (int k = 0; k < Mn[i]; k++)
		{
			for (int r1 = 0; r1 < job_mlist[i].size() - 1; r1++)
			{
				int j1 = job_mlist[i][r1];
				for (int r2 = 0; r2 < job_mlist[i].size(); r2++)
				{
					int j2 = job_mlist[i][r2];
				}
				int j2 = job_mlist[i][r1 + 1];
			}
		}
	}
	DbgPrint("initialize solution end.... \n ");
	return;
}


void jaMILPCP::reallocate_bls()
{
	//1. ���򣬰����ɳ�ʱ���������
	vector<jaTask*> dispatch_list;
	for (int j = 0; j < NJ; j++)
	{
		int TPT = 0;
		for (int i = 0; i < NG-1; i++)
		{
			TPT += m_online_sequence[i][j]->P + m_online_sequence[i][j]->T;			
		}
		if (m_online_sequence[0][j]->u==0)
		{
			m_online_sequence[0][j]->EST = DD[j] - TPT;
		}
		else
		{
			m_online_sequence[0][j]->EST = m_online_sequence[0][j]->S;
		}		
		dispatch_list.push_back(m_online_sequence[0][j]);
	}
	std::sort(begin(dispatch_list), end(dispatch_list), [](jaTask* a, jaTask* b) {
		if (a->u == b->u)
		{
			return a->EST < b->EST;
		}
		else
		{
			return a->u > b->u;
		}
	});

	//2. �豸����ʱ��
	int id = -1; int kd = -1; int rt = -1;
	if (break_machs.size() > 0)
	{
		id = std::get<0>(break_machs.back());
		kd = std::get<1>(break_machs.back());
		rt = std::get<2>(break_machs.back()) + std::get<3>(break_machs.back());
	}

	//3. first come first out (FCFO) rule 	
	for (int i = 0; i < NG - 1; i++)
	{
		vector<int> Rm(Mn[i], m_evt_time);
		if (i == id && rt > m_evt_time)
		{
			Rm[kd] = rt;
		}
		vector<jaTask*> tmp_list;
		for (int r = 0; r < dispatch_list.size(); r++)
		{
			int j = dispatch_list[r]->j;
			// ���չ���ѡ��rule
			int kx = 0;
			if (m_online_sequence[i][j]->u > 0)
			{
				kx = m_online_sequence[i][j]->k;
				m_online_sequence[i][j]->LCT = m_online_sequence[i][j]->C;
				m_online_sequence[i][j]->EST = m_online_sequence[i][j]->S;
				if (m_online_sequence[i][j]->C > m_evt_time)
					Rm[kx] = m_online_sequence[i][j]->C;
			}
			else
			{
				int minT = 1.0e5;
				for (int k = 0; k < Mn[i]; k++)
				{
					if (Rm[k] < minT) { kx = k; minT = Rm[k];}
				}
				m_online_sequence[i][j]->k = kx;
				m_online_sequence[i][j]->EST = Rm[kx];
				Rm[kx] = Rm[kx] + m_online_sequence[i][j]->P;
			}			
			//next stage
			m_online_sequence[i+1][j]->EST = Rm[kx] + m_online_sequence[i][j]->T;
			tmp_list.push_back(m_online_sequence[i+1][j]);
		}
		dispatch_list.clear();
		dispatch_list = tmp_list;
		std::sort(begin(dispatch_list), end(dispatch_list), [](jaTask* a, jaTask* b) {
			if (a->u == b->u)
			{
				return a->EST < b->EST;
			}
			else
			{
				return a->u > b->u;
			}
		});
	}
	return;
}

//2. �����·ֽ⡢����
vector<vector<vector<jaTask*>>> jaMILPCP::reallocate_dec()
{
	//1. �������س�ʼ��
	vector<vector<int>> Mload(NG-1);
	Solution rtn_soln(NG -1);
	for (int i = 0; i < NG - 1; i++)
	{
		Mload[i].resize(Mn[i],0);
		rtn_soln[i].resize(Mn[i]);
	}
	for each (auto var in break_machs)
	{
		int id = std::get<0>(var);
		int kd = std::get<1>(var);
		int et = std::get<2>(var);
		int ts = std::get<3>(var);
		Mload[id][kd] += ts;
	}
	for (int j = 0; j < NJ; j++)
	{
		m_online_sequence[NG - 2][j]->LCT = DD[j];
	}
	//2. �����ηֽ�
	for (int b = 0; b < NB; b++)
	{
		for (int r = 0; r < Nb[b]; r++)
		{
			int j = B[b][r];
			for (int i = NG - 2; i >= 0; i--)
			{
				int kx = 0; int min_load = 1.0e5;
				if (m_online_sequence[i][j]->u > 0)
				{
					kx = m_online_sequence[i][j]->k; m_online_sequence[i][j]->EST = m_online_sequence[i][j]->S;
				}
				else
				{
					for (int k = 0; k < Mn[i]; k++)
					{
						if (Mload[i][k] < min_load) {
							kx = k; min_load = Mload[i][k];
						}
					}
					m_online_sequence[i][j]->EST = m_online_sequence[i][j]->LCT - m_online_sequence[i][j]->P;
				}
				m_online_sequence[i][j]->k = kx;
				Mload[i][kx] += m_online_sequence[i][j]->P;
				if (i > 0)
					m_online_sequence[i - 1][j]->LCT = m_online_sequence[i][j]->EST - m_online_sequence[i-1][j]->T;
				rtn_soln[i][kx].push_back(m_online_sequence[i][j]);
			}
		}
	}
	//3. ��������
	for (int i = 0; i < NG - 1; i++)
	{
		for (int k = 0; k < Mn[i]; k++)
		{
			std::sort(begin(rtn_soln[i][k]), end(rtn_soln[i][k]), [](jaTask* a, jaTask* b) {
				return a->EST < b->EST;				
			});
		}
	}
	return rtn_soln;
}

//����Ŀ�꺯��
double jaMILPCP::calc_objective(Sequence& timetable)
{
	int intrup = 0;
	int makespan = 0;
	int compr = 0;
	for (IloInt k = 0; k < Mn[NG - 1]; k++)
	{
		for (IloInt l = 0; l < Ng[k]; l++)
		{
			int b = Bg[k][l];
			IloIntervalVar prev;
			for (IloInt r = 0; r < Nb[b]; r++)
			{
				int j = B[b][r];
				if (timetable[NG - 1][j]->C >= makespan)
					makespan = timetable[NG - 1][j]->C;
				int wt = 0;
				for (int i = 0; i < NG - 1; i++)
				{
					wt += timetable[i + 1][j]->S - timetable[i][j]->S - timetable[i][j]->P - timetable[i][j]->T;
				}				
				compr += std::max(5 * Rho - wt,0);				
				if (r > 0) //1,1
				{
					int jx = B[b][r] - 1;
					intrup += timetable[NG-1][j]->S - timetable[NG - 1][jx]->C;					
				}
			}
		}
	}	
	double f = 1.0*makespan + 10.0*compr+ 100.0*intrup;
	DbgPrint("#objective f=%.2f, f1=%.2f, f2=%.2f, f3=%.2f \n", f, 1.0*makespan, 10.0*compr, 100.0*intrup);
	m_output << jaCommon::format("%.2f %.2f %.2f %.2f \n", f, 1.0*makespan, 10.0*compr, 100.0*intrup);
	return f;
}

void jaMILPCP::output()
{
	for (auto pair : m_pProblem->getMachineMap())
	{
		jaMachine* pMach = pair.second;
		pMach->getProcessList().clear();
	}
	int cmax = 0;
	int cbrk = 0;
	int vsta = 0;
	for (int i = 0; i < NG; i++)
	{
		for (int j = 0; j <NJ; j++)
		{
			string machID = jaCommon::format("%d%d", i + 1, m_online_sequence[i][j]->k + 1);
			jaMachine* pMach = this->m_pProblem->getMachineMap()[machID];
			string operID = jaCommon::format("O_%d_%03d", i + 1, j + 1);
			map<string, jaOperation*>::iterator it = m_pProblem->getOperMap().find(operID);
			if (it == m_pProblem->getOperMap().end())
				continue;
			jaOperation* pOper = it->second;
			pOper->setMachine(pMach);
			pOper->setStartTime(m_online_sequence[i][j]->S);
			pOper->setFinishTime(m_online_sequence[i][j]->C);
			pOper->setArrivalTime(pOper->getStartTime());
			pOper->setDepartureTime(pOper->getFinishTime());
			if (m_online_sequence[i][j]->u == 0) //�д���
			{
				pOper->setStatus(OPERATION_STATUS::NEW);
			}
			else if (m_online_sequence[i][j]->u == 1)
			{
				pOper->setStatus(OPERATION_STATUS::RUNNING);
			}
			else if (m_online_sequence[i][j]->u == 2)
			{
				pOper->setStatus(OPERATION_STATUS::TERMINAL);
			}
			pMach->getProcessList().push_back(pOper);			
			
			if (m_online_sequence[i][j]->C > cmax) cmax = m_online_sequence[i][j]->C;					
		}		
	}
	for (IloInt b = 0; b < NB; b++)
	{
		for (IloInt r = 0; r < Nb[b]; r++)
		{
			int j = B[b][r];
			vsta += std::abs(m_online_sequence[NG - 1][j]->C - m_online_sequence[NG - 1][j]->S-PT[NG-1][j]);			
			if (r > 0)
			{
				int j0 = B[b][r - 1];
				cbrk = cbrk + m_online_sequence[NG - 1][j]->S - m_online_sequence[NG-1][j0]->C;
			}
		}
	}
	for (IloInt r = 0; r < break_machs.size(); r++)
	{
		int ix = std::get<0>(break_machs[r]);
		int kx = std::get<1>(break_machs[r]);
		int et = std::get<2>(break_machs[r]);
		int ts = std::get<3>(break_machs[r]);
		string machID = jaCommon::format("%d%d", ix + 1, kx + 1);
		jaMachine* pMach = m_pProblem->getMachineMap()[machID];
		string name = jaCommon::format("%d%d:%d-%d", ix + 1, kx + 1, et,et+ts);
		jaBreakdown* intv = new jaBreakdown(name);
		intv->setMachine(pMach);
		intv->setStartTime(et);
		intv->setBreakTime(ts);
		m_pProblem->addBreak(intv);
	}

	for (IloInt r = 0; r < delay_opers.size(); r++)
	{
		int ix = std::get<0>(delay_opers[r]);
		int jx = std::get<1>(delay_opers[r]);		
		string operID = jaCommon::format("O_%d_%03d", ix + 1, jx + 1);
		jaOperation* pOper = m_pProblem->getOperMap()[operID];
		pOper->setFlag(true);
	}
	
}


int* jaMILPCP::sortByTime(int* tt, int nt)
{
	int* Tj = new int[nt];
	for (int i = 0; i < nt; i++)
	{
		Tj[i] = i;
		//DbgPrint("%d=%d\n",i,tt[i]);		
	}
	for (int i = 0; i < nt; i++)
	{
		for (int j = i + 1; j < nt; j++)
		{
			if (tt[i] > tt[j])
			{
				int temp = tt[i];
				tt[i] = tt[j];
				tt[j] = temp;
				std::swap(Tj[i], Tj[j]);
			}
		}
	}
	return Tj;
}

bool jaMILPCP::MILP_solver()
{
	//1.��ǰ������߱���
	Solution xsoln = this->reallocate_dec();
	int id = -1;
	int kd = -1;
	int et = -1;
	int ts = -1;
	if (break_machs.size() > 0)
	{
		id = std::get<0>(break_machs.back());
		kd = std::get<1>(break_machs.back());
		et = std::get<2>(break_machs.back());
		ts = std::get<3>(break_machs.back());
	}
	vector<vector<int>> RM(NG);
	for (int i = 0; i < NG; i++)
	{
		RM[i].resize(Mn[i],m_evt_time);
		for (int k = 0; k < Mn[i]; k++)
		{
			if (i==id && k==kd )
			{
				RM[i][k] = std::max(m_evt_time, et + ts);
			}
		}
	}
	//2.���߱���
	IloEnv milpEnv;
	IloModel milpModel = IloModel(milpEnv);
	IloCplex milpCplex = IloCplex(milpModel);	
	IloIntVarMatrix T = IloIntVarMatrix(milpEnv, NG);	
	IloIntVarArray Q = IloIntVarArray(milpEnv, NJ, 0, 100);
	IloConstraintArray Cons(milpEnv);
	char name[20];
	for (IloInt i = 0; i < NG; i++)
	{
		T[i] = IloIntVarArray(milpEnv, NJ, 0, 3000);
		for (IloInt j = 0; j < NJ; j++)
		{
			sprintf(name, "T_%d,%d",i, j);
			T[i][j].setName(name);
		}
	}	
	//3. ʱ�����Լ��Լ��
	IloIntVar Cmax(milpEnv, 0, 3000, "Cmax");
	for (IloInt i = 0; i < NG; i++)
	{
		for (IloInt j = 0; j < NJ; j++) //����ط�Ҫ��״̬
		{
			if (m_online_sequence[i][j]->u>0)
			{
				Cons.add(T[i][j] == m_online_sequence[i][j]->S);
			}
			else
			{
				int k = m_online_sequence[i][j]->k;
				Cons.add(T[i][j] >= RM[i][k]);
			}
		}
	}

	for (IloInt j = 0; j < NJ; j++)
	{		
		for (IloInt i= 0; i < NG-1; i++) //����ط�Ҫ��״̬
		{
			if (m_online_sequence[i + 1][j]->u == 0 )
			{
				if(i<NG-2)
					Cons.add(T[i + 1][j] - T[i][j] >= m_online_sequence[i][j]->P + m_online_sequence[i][j]->T);
				else
				{					
					Cons.add(T[i + 1][j] - T[i][j] >= m_online_sequence[i][j]->P + m_online_sequence[i][j]->T);
				}
					
			}
		}
	}	
	//4. ���䡢�������Լ��
	for (int i = 0; i < NG - 1; i++)
	{		
		for (int k = 0; k < Mn[i]; k++)
		{			
			for (int r = 1; r < xsoln[i][k].size(); r++)
			{
				int j = xsoln[i][k][r - 1]->j;
				int l = xsoln[i][k][r]->j;
				Cons.add(T[i][l] - T[i][j] - m_online_sequence[i][j]->P >= 0);
			}
		}
	}	
	//5. ���Ʊ���
	double delta = 0.1*Phi;
	for (IloInt b = 0; b < NB; b++)
	{
		for (IloInt r = 0; r < Nb[b]; r++)
		{
			int j = B[b][r];
			int lb = (1 - 0)*PT[NG - 1][j];
			int ub = (1 + delta)*PT[NG - 1][j];
			char name[20];
			sprintf(name, "X_%d", j);
			Q[j].setName(name);
			if (m_online_sequence[NG - 1][j]->u > 1)
			{
				Cons.add(Q[j] == m_online_sequence[NG - 1][j]->P); //����ʱ�䲻��
			}
			else 
			{
				Cons.add(Q[j] >= lb);
				Cons.add(Q[j] <= ub);
			}
		}
	}
	//6. ����Լ��
	IloExpr Cbreak(milpEnv);
	for (IloInt k = 0; k < Mn[NG - 1]; k++)
	{
		int jx = -1;
		for (IloInt l = 0; l < Ng[k]; l++)
		{
			int b = Bg[k][l];
			for (IloInt r = 0; r < Nb[b]; r++)
			{
				int j = B[b][r];
				Cons.add(Cmax >= T[NG-1][j] + Q[j]);
					
				if (m_online_sequence[NG - 1][j]->u>1)
				{
					jx = j;
					continue;
				}
				if (r == 0)//n,1
				{
					if (jx < 0)
						Cons.add(T[NG - 1][j] >= Su[b]);
					else
					{
						int bx = Bg[k][l - 1];
						int rx = Nb[bx] - 1;
						Cons.add(T[NG - 1][j] - T[NG - 1][jx] >= Su[b] + Q[jx]); //???
					}
				}
				else
				{
					Cons.add(T[NG - 1][j] - T[NG - 1][jx] >= Q[jx]);
					Cbreak += (T[NG - 1][j] - T[NG - 1][jx] - Q[jx]);
				}
				jx = j;
			}
		}
	}
	//6. Ŀ�꺯��
	IloExpr Fdev(milpEnv);
	for (IloInt j = 0; j < NJ; j++)
	{
		int max_fl = UPT[j] + 5*Rho;
		for (int i = 0; i < NG - 2; i++)
		{
			Fdev += (T[i+1][j] - T[i][j]-m_online_sequence[i][j]->P - m_online_sequence[i][j]->T);
		}
		Fdev += IloAbs(5 * Rho - T[2][j] + T[1][j] + m_online_sequence[1][j]->P + m_online_sequence[1][j]->T);
	}
	milpModel.add(IloMinimize(milpEnv, Cbreak*100.0 + Fdev*10.0 + Cmax*1.0)); //����Ŀ��
	milpModel.add(Cons);
	milpCplex.setOut(milpEnv.getNullStream());	
	milpCplex.solve();	
	if ((milpCplex.getStatus() == IloAlgorithm::Infeasible) ||
		(milpCplex.getStatus() == IloAlgorithm::InfeasibleOrUnbounded))
	{
		DbgPrint("MILP No Solution \n");
		return false;
	}

	for (int j = 0; j < NJ ; j++)
	{
		for (int i = 0; i < NG - 1; i++)
		{
			m_online_sequence[i][j]->S = milpCplex.getValue(T[i][j]);
			m_online_sequence[i][j]->C= milpCplex.getValue(T[i][j]) + m_online_sequence[i][j]->P;			
		}
		m_online_sequence[NG - 1][j]->S = milpCplex.getValue(T[NG-1][j]);
		int qt = milpCplex.getValue(Q[j])- PT[NG-1][j];
		m_online_sequence[NG - 1][j]->C = milpCplex.getValue(T[NG - 1][j]) + milpCplex.getValue(Q[j]);
		m_online_sequence[NG - 1][j]->P = m_online_sequence[NG - 1][j]->C - m_online_sequence[NG - 1][j]->S;
	}
	
	double f1 = milpCplex.getValue(Cmax)*1.0;
	double f2 = milpCplex.getValue(Fdev)*10.0;
	double f3 = milpCplex.getValue(Cbreak)*100.0;
	double f = milpCplex.getObjValue();
	DbgPrint("\n MP f1=%.2f,f2=%.2f,f3=%.2f,f=%.2f \n", f1, f2, f3, f1 + f3 + f2);
	return true;
}

bool jaMILPCP::CP_solver()
{
	char name[20];
	IloEnv cpEnv;
	IloModel cpModel(cpEnv);
	IloArray<IloArray<IloIntervalVarArray>> ma_oplist(cpEnv, NG - 1);
	IloArray<IloIntervalVarArray> op_matrix(cpEnv, NG);
	//1.�������α�������
	for (IloInt i = 0; i < NG - 1; i++)
	{
		ma_oplist[i] = IloArray<IloIntervalVarArray>(cpEnv, Mn[i]);
		op_matrix[i] = IloIntervalVarArray(cpEnv, NJ);
		for (size_t k = 0; k < Mn[i]; k++)
		{
			ma_oplist[i][k] = IloIntervalVarArray(cpEnv);
		}

		for (int j = 0; j < NJ; j++)
		{
			sprintf(name, "O_%d,%d", i, j);
			int PTX = m_online_sequence[i][j]->P;
			op_matrix[i][j] = IloIntervalVar(cpEnv, PTX, name);
			IloIntervalVarArray members(cpEnv);
			for (int k = 0; k < Mn[i]; k++) //����ѡ��
			{
				IloIntervalVar member(cpEnv, PTX);
				sprintf(name, "x_%d,%d,%d", i, k, j);
				member.setName(name);
				member.setOptional();
				members.add(member);
				if (m_online_sequence[i][j]->u>0 && m_online_sequence[i][j]->k == k)
					member.setPresent();
				ma_oplist[i][k].add(member);
			}
			if (m_online_sequence[i][j]->u>0)
				cpModel.add(IloStartOf(op_matrix[i][j]) == m_online_sequence[i][j]->S);
			cpModel.add(IloAlternative(cpEnv, op_matrix[i][j], members));
			if (i > 0)
				cpModel.add(IloEndOf(op_matrix[i - 1][j]) <= IloStartOf(op_matrix[i][j]) - TR[i - 1][i]);
		}
	}
	for (IloInt j = 0; j < NJ; j++)
	{
		cpModel.add(IloStartOf(op_matrix[0][j]) >= m_online_sequence[0][j]->S);
	}
	//2.�������غ�Լ��	
	for (IloInt i = 0; i < NG - 1; i++)
	{
		for (int k = 0; k < Mn[i]; k++)
		{
			cpModel.add(IloNoOverlap(cpEnv, ma_oplist[i][k]));
		}
	}
	//3.����Լ��
	op_matrix[NG - 1] = IloIntervalVarArray(cpEnv, NJ);
	for (int j = 0; j < NJ; j++)
	{
		sprintf(name, "O_%d,%d", NG - 1, j);
		if (m_online_sequence[NG-1][j]->u>1)
		{
			op_matrix[NG - 1][j] = IloIntervalVar(cpEnv, PT[NG - 1][j], name);
		}
		else
		{
			int lb = (1 - 0.1*Phi)*PT[NG - 1][j];
			int ub = (1 + 0.1*Phi)*PT[NG - 1][j];
			op_matrix[NG - 1][j] = IloIntervalVar(cpEnv, lb,ub, IloTrue);
			op_matrix[NG - 1][j].setName(name);	
			op_matrix[NG - 1][j].setPresent();
			/*op_matrix[NG - 1][j] = IloIntervalVar(cpEnv, PT[NG - 1][j], name);*/
		}		
	}
	IloExprArray stability(cpEnv);
	IloExprArray penalty(cpEnv);
	IloExprArray ends(cpEnv);
	for (IloInt k = 0; k < Mn[NG - 1]; k++)
	{
		int jx = -1;
		for (IloInt l = 0; l < Ng[k]; l++)
		{
			int b = Bg[k][l];
			IloIntervalVar prev;
			for (IloInt r = 0; r < Nb[b]; r++)
			{
				int j = B[b][r];
				if (m_online_sequence[NG-1][j]->u>0)
					cpModel.add(IloStartOf(op_matrix[NG-1][j]) == m_online_sequence[NG-1][j]->S);
				cpModel.add(IloEndBeforeStart(cpEnv, op_matrix[NG - 2][j], op_matrix[NG - 1][j],
					TR[NG - 2][NG - 1])); //ǰ�����Լ��				
				if (jx < 0) //1,1
				{
					op_matrix[NG - 1][j].setStartMin(Su[l]);
				}
				else if (r == 0 && jx >-1)//n,1
				{
					cpModel.add(IloEndBeforeStart(cpEnv, op_matrix[NG - 1][jx], op_matrix[NG - 1][j], Su[l]));
				}
				else//���ڲ���Լ��IloEndAtStart���ɳ�) IloEndBeforeStart�����ڣ�
				{
					cpModel.add(IloEndBeforeStart(cpEnv, op_matrix[NG - 1][jx], op_matrix[NG - 1][j], 0));
					penalty.add(IloStartOf(op_matrix[NG - 1][j]) - IloEndOf(op_matrix[NG - 1][jx]));
				}
				DbgPrint("%d,%d: %d\n", NG, j, m_online_sequence[NG - 1][j]->S);
				stability.add(IloAbs(IloSizeOf(op_matrix[NG - 1][j]) - PT[NG-1][j])); //����ƫ�����	
				ends.add(IloEndOf(op_matrix[NG - 1][j]));
				jx = j;
			}
		}
	}//model.add(IloNoOverlap(env, ma_oplist[NG-1][k]));  //ͬһ�����ϲ������غ�
	//4.Ŀ�꺯��
	
	cpModel.add(IloMinimize(cpEnv, 100*IloSum(penalty)));

	IloCP cp(cpModel);
	cp.setParameter(IloCP::TimeLimit, 120);
	int rtn_slack = std::numeric_limits<int>::min();
	int rtn_no = -1;
	if (cp.solve())
	{
		for (int j = 0; j < NJ; j++)
		{
			for (int i = 0; i < NG-1 ; i++)
			{
				for (int k = 0; k < Mn[i]; k++)
				{
					if (cp.isPresent(ma_oplist[i][k][j]))
					{
						m_online_sequence[i][j]->k = k;
					}
				}
				m_online_sequence[i][j]->S = (int)cp.getStart(op_matrix[i][j]);
				m_online_sequence[i][j]->C = (int)cp.getEnd(op_matrix[i][j]);				
			}
			m_online_sequence[NG-1][j]->S = (int)cp.getStart(op_matrix[NG-1][j]);
			m_online_sequence[NG-1][j]->C = (int)cp.getEnd(op_matrix[NG-1][j]);
		}
		DbgPrint("SP= %.2f\n", cp.getObjValue());
	}
	else
	{
		if (cp.refineConflict())
		{
			std::ostringstream os;
			cp.writeConflict(os);
			DbgPrint("%s", os.str().c_str());
		}
		DbgPrint("No solution found. \n");
	}
	cpEnv.end();
	return true;
}

bool jaMILPCP::Hybrid_slover()
{
	pair<int, int> slkj = make_pair(0, 0);
	vector<int> delta(NJ, 0); // R �� d �ɳڱ���
	slkj = runSlaveCP2(delta, m_online_sequence);

	do
	{
		if (slkj.second < 0)
			break;
		DbgPrint("slack = %d,%d \n", slkj.first, slkj.second);
		DD[slkj.second] += slkj.first;
		DbgPrint("DD[%d] = %d \n", slkj.second, DD[slkj.second]);
		runMasterMILP2(delta);
		DbgPrint("DD[%d] = %d \n", slkj.second, DD[slkj.second]);		
		slkj = runSlaveCP2(delta, m_online_sequence);
	} while (1);
	return true;
}

bool jaMILPCP::read_scenarios(string instance)
{	
	replace(instance.begin(), instance.end(), '*', 'x');
	string name = jaCommon::format("d:/scenarios/%s.txt", instance.c_str());
	ifstream in(name);
	if (!in.is_open())
	{		
		m_output.open(name);
		if (!m_output.is_open())
			return false;
		jaNoiser noise;
		for (int r = 1; r < 9; r++)
		{
			double x1 = rand() % 100 / 100.0;
			vector<double> x2(3,0.0);
			if (x1 < 0.8)
			{
				x2[0] = noise.uniform_double(1.0, 1 * 10);
				x2[1] = noise.uniform_double(2.0, 2 * 10);
				x2[2] = noise.uniform_double(3.0, 3 * 10);
				this->scenarios.push_back(make_tuple(r, x1, x2[Eta1]));
			}
			else
			{
				x2[0] = noise.uniform_double(1.0, 1 * 15);
				x2[1] = noise.uniform_double(4.0, 2 * 15);
				x2[2] = noise.uniform_double(6.0, 3 * 15);
				this->scenarios.push_back(make_tuple(r, x1, x2[Eta2]));
			}
			string info = jaCommon::format("%d %.2f %.2f %.2f %.2f \n", r, x1, x2[0], x2[1], x2[2]);
			m_output << info;			
		}
		//m_output.close();
	}
	else
	{
		char buffer[256];
		while (!in.eof())
		{
			in.getline(buffer, 256, '\n');//getline(char *,int,char) ��ʾ�����ַ��ﵽ256�����������оͽ���
			if (buffer[0]=='-')
				break;
			string info(buffer);		
			vector<string> xx;
			string d = " ";				
			jaCommon::split(info, d, &xx);	
			if (atof(xx[1].c_str())<0.8)
			{				
				this->scenarios.push_back(make_tuple(atoi(xx[0].c_str()), atof(xx[1].c_str()), atof(xx[1 + Eta1].c_str())));
			}
			else
			{				
				this->scenarios.push_back(make_tuple(atoi(xx[0].c_str()), atof(xx[1].c_str()), atof(xx[1 + Eta2].c_str())));
			}
		}
		in.close();
		m_output.open(name,ios::app);
		if (!m_output.is_open())
			return false;
	}	
	return true;
}



jaMILPCP::~jaMILPCP()
{
	//1.decsion variables	
	for (int i = 0; i < NG; i++)
	{
		delete[] m_st[i];
	}
	delete[] m_st;

	for (int k = 0; k < Mn[NG - 1]; k++)
	{
		delete[] Bg[k];
	}
	for (int b = 0; b < NB; b++)
	{
		delete[] B[b];
	}
	delete[] Bg;
	delete[] B;
	delete[] Nb;
	delete[] BE;
	delete[] BS;
	delete[] Su;

	for (int i = 0; i < NG; i++)
	{
		delete[] JI[i];
		delete[] PT[i];
		delete[] TR[i];
	}
	delete[] JI;
	delete[] PT;
	delete[] Mn;
	delete[] Ji;
	delete[] Ng;
	delete[] TR;

	for (int j = 0; j < NJ; j++)
	{
		delete[] GJ[j];
	}
	delete[] Gj;
	delete[] GJ;
	delete[] J;
	delete[] AT;


}


