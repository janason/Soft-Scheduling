#ifndef _JA_LRRS_H_
#define _JA_LRRS_H_

#include <jaSimulation/entity/jaAlogrithm.h>
#include "jaMILPCPMacro.h"
#include <jaSimulation/util/jaCommon.h>
#include "gurobi_c++.h"
#include <sstream>

/************************************************************************/
/* �õ����㷨û��ָ���ӹ�����,ֻȷ����ʼʱ�伴��
/************************************************************************/
class jaLRRS :public jaAlogrithm
{
public:
	jaLRRS(string strAlgoName);
	~jaLRRS(void);

	bool initialize();
	bool run();
	bool reset();
	void output();

private:	
	double run_MILP();
	bool BLS(bool OptCast=false);
	double timing();
	double best_objective;
	bool debug_Gurobi(GRBModel& model, double& obj);
	
};

#endif
