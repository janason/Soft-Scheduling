import importlib
import itertools
import os

import numpy as np
import pandas as pd

from DyHRS.parameters import *
from algorithm.MPMOAS import *
from algorithm.PMMAS import *
from algorithm.mACOOL import *
from model import const
from model.utils import read_from_file, generate_to_file


def create_instance(iid):
    # file_num = len([lists for lists in os.listdir('../data//')
    #                 if os.path.isfile(os.path.join('../data//', lists))])  # 获取文件数量
    file_name = 'data_' + str(iid + 1)
    problem = generate_to_file(file_name)


# randomly generate new instance
def run(prob_id, algo_cls, params):
    file_name = f'data_' + str(prob_id)
    problem = read_from_file(file_name)
    # --------------------------2. run optimization individual------------------------
    data = {}
    problem.update(0)
    algo = algo_cls(problem, params)
    algo.initialize()
    algo.execute()
    algo.output(is_show_fig=False)
    pf = np.array(algo.frontier)
    tm = np.array([problem.t] * len(algo.frontier))
    PF = np.insert(pf, 0, values=tm, axis=1)
    data[0] = algo.ideal_distance
    while len(problem.T) > 0:
        t = problem.T[0]
        problem.update(problem.T[0])
        algo.initialize()
        algo.execute()
        algo.output(is_show_fig=False)
        pf = np.array(algo.frontier)
        tm = np.array([problem.t] * len(algo.frontier))
        pft = np.insert(pf, 0, values=tm, axis=1)
        PF = np.append(PF, pft, axis=0)
        data[t] = algo.ideal_distance

    df_PF = pd.DataFrame(PF)
    xls_name = './result/' + file_name + '.xlsx'
    if os.path.exists(xls_name):
        df_sheet = pd.read_excel(xls_name, sheet_name=None)
        sheet = algo.name()
        if not mACOOL.has_UCB1:
            sheet = sheet + '-NU'
        if not mACOOL.has_transfer:
            sheet = sheet + '-NT'

        if sheet in df_sheet.keys():
            df_existing = pd.read_excel(xls_name, sheet_name=sheet)
            df_new = pd.concat([df_existing, df_PF])
        else:
            df_new = df_PF
        writer = pd.ExcelWriter(xls_name, mode="a", engine="openpyxl", if_sheet_exists='replace')
        df_new.to_excel(writer, sheet_name=sheet, index=False)
        writer.close()
    else:
        df_PF.to_excel(xls_name, sheet_name=algo.name(), index=False)

    # ax = sns.lineplot(data=pd.DataFrame(data))
    # plt.show()

    return sum(algo.hyper_volume) / len(algo.hyper_volume)


def algo_comparison():
    algo_list = ['mACOOL', 'MPMOAS', 'PMMAS', 'DPLS', 'MOPSO', 'NSGA2']
    for ins, _ in itertools.product(range(24, 27), range(5)):
        for name in algo_list:
            print('algorithm: ---------' + name + '---------------')
            mod1 = importlib.import_module('algorithm.' + name)
            cls = getattr(mod1, name)
            mod2 = importlib.import_module('DyHRS.parameters')
            params = getattr(mod2, name + '_params')
            run(ins, cls, params)


def comp__comparison():
    comp_list = [[True, True], [True, False], [False, True]]
    for ins, _ in itertools.product(range(1, 31), range(5)):
        for comp in comp_list:
            mACOOL.has_UCB1 = comp[0]
            mACOOL.has_transfer = comp[1]
            run(ins, mACOOL, mACOOL_params)


if __name__ == '__main__':

    comp__comparison()
