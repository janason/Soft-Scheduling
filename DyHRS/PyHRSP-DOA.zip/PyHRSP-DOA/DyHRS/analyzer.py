import random

import pandas as pd
import seaborn as sns
import statsmodels.api as sm
from statsmodels.formula.api import ols
import numpy as np
import matplotlib.pyplot as plt

from algorithm.utils.indicators import hv_indicator, sp_indicator, get_pareto_front, sr_indicator

algo_list = ['mACOOL', 'MPMOAS', 'PMMAS', 'DPLS', 'MOPSO', 'NSGA2']

ACO_list = ['mACOOL', 'mACOOL-NT', 'mACOOL-NU']


def ANOVA(df, key, x_tick=[]):
    # mpl.rcParams['font.sans-serif'] = ['SimHei']
    sns.set(font_scale=0.8)
    plt.figure(figsize=(4.8, 6.0))
    sns.set(style='white')

    df_melt = pd.melt(df.reset_index(), id_vars=['index'])
    df_melt.columns = ['index', 'Algorithms', key]

    model = ols(key + ' ~ C(Algorithms)', data=df_melt).fit()
    anova_table = sm.stats.anova_lm(model, typ=1)
    print(anova_table)

    # mc = MultiComparison(df_melt[key], df_melt['Levels'])
    # tukey_result = mc.tukeyhsd(alpha=0.05)
    # print(tukey_result)

    sns.boxplot(x='Algorithms', y=key, data=df_melt, width=0.40,
                fliersize=2, linewidth=1)
    sns.swarmplot(x='Algorithms', y=key, data=df_melt, size=4)
    plt.xticks(range(len(x_tick)), x_tick, fontsize=10)
    # plt.set_xlabel('(' + chr(97 + i) + ')', y=-0.28, fontsize=12)
    # plt.set_ylabel(key, fontsize=12)
    plt.tick_params(labelsize=10)
    plt.show()


def plot_data_curve(df):
    plt.figure(figsize=(6, 3.2))
    # sns.set_theme(style="darkgrid")
    sns.lineplot(data=df, x="iter", y="hv1", marker="o", markersize=6, dashes=False, label='I-greedy', lw=1)
    sns.lineplot(data=df, x="iter", y="hv2", marker="o", linestyle='--', markersize=6, dashes=True, label='I-random',
                 lw=1)
    sns.lineplot(data=df, x="iter", y="hv3", marker="s", markersize=6, dashes=False, label='II-greedy', lw=1)
    sns.lineplot(data=df, x="iter", y="hv4", marker="s", linestyle='--', markersize=6, dashes=True, label='II-random',
                 lw=1)
    plt.legend(prop={'size': 10.5})
    # plt.tick_params(labelsize=10.5)
    plt.tick_params(axis='both', which='major', labelsize=10.5, pad=0)
    plt.xlabel("iteration", fontsize=11, labelpad=0)
    plt.ylabel("hypervolume", fontsize=11, labelpad=0)
    plt.show()


def cal_mo_metric(algos, data):
    T = data['mACOOL']['t'].unique()
    hv_list = {a: [] for a in algos}
    sp_list = {a: [] for a in algos}
    sr_list = {a: [] for a in algos}
    for t in T:
        z_max = [1e0, 1e0]
        z_min = [1e4, 1e4]
        Z_obj = []
        for algo, dfx in data.items():
            df_filter = dfx[dfx['t'] == t]  # 过滤
            df = df_filter[['f1', 'f2']]
            f_min = df.min().tolist()
            f_max = df.max().tolist()

            for i in range(2):
                if f_max[i] > z_max[i]:
                    z_max[i] = f_max[i]
                if f_min[i] < z_min[i]:
                    z_min[i] = f_min[i]

            z_obj = df[['f1', 'f2']].values.tolist()
            Z_obj.extend(z_obj)
        pf_all = get_pareto_front(Z_obj)
        for algo, dfy in data.items():
            df = dfy[dfy['t'] == t]
            z_obj = df[['f1', 'f2']].to_numpy()
            _range = np.array(z_max) - np.array(z_min)
            z_norm = (z_obj - z_min) / _range
            hv = hv_indicator(z_obj=z_obj, n_obj=2, max_pt=z_max, min_pt=z_min, ref_pt=[1.0, 1.0])
            hv_list[algo].append(hv)
            sp = sp_indicator(pareto_front=z_norm)
            sp_list[algo].append(sp)
            sr = sr_indicator(z_obj, pf_all)
            sr_list[algo].append(sr)

    df_hv = pd.DataFrame(hv_list)
    df_sp = pd.DataFrame(sp_list)
    df_sr = pd.DataFrame(sr_list)

    mhv = df_hv.mean().to_dict()
    msp = df_sp.mean().to_dict()
    msr = df_sr.mean().to_dict()

    return mhv, msp, msr


def plot_real_case():
    df = pd.read_excel(io='real_case.xlsx', sheet_name='mACOq2')
    sns.set_theme(style="white")
    sns.relplot(x="f1", y="f2", hue="t", style="t", s=100, sizes=(60, 60), palette="muted",
                height=5, data=df)
    plt.show()
    max_f = [1e0, 1e0]
    min_f = [1e4, 1e4]

    for i in range(4):
        dfi = pd.read_excel(io='real_case_log.xlsx', sheet_name='log-' + str(i))
        min_f1 = dfi[['f1']].min().values[0]
        max_f1 = dfi[['f1']].max().values[0]
        min_f2 = dfi[['f2']].min().values[0]
        max_f2 = dfi[['f2']].max().values[0]
        if min_f1 < min_f[0]:
            min_f[0] = min_f1
        if min_f2 < min_f[1]:
            min_f[1] = min_f2
        if max_f1 > max_f[0]:
            max_f[0] = max_f1
        if max_f2 > max_f[1]:
            max_f[1] = max_f2
        print(max_f, min_f)
    dist_over_time = []
    for i in range(4):
        dfi = pd.read_excel(io='real_case_log.xlsx', sheet_name='log-' + str(i))
        f_val = dfi[['f1', 'f2']].to_numpy()
        p_val = dfi[['p']].to_numpy().tolist()
        _range = np.array(max_f) - np.array(min_f)
        f_norm = (f_val - min_f) / _range
        np_dist = np.sum(f_norm, axis=1).T

        np_array = np.vstack((np.array([p[0] for p in p_val]), np_dist))
        df_dist = pd.DataFrame(np_array.T, columns=['p', 'd'])
        means = df_dist.groupby('p').min()
        dist_over_time.append(means)
        print(means)

    fig, ax1 = plt.subplots()
    sns.lineplot(data=dist_over_time[0], x='p', y='d', marker="o", markersize=5, color='k', label='t=0', lw=0.8, ax=ax1)
    ax1.legend(loc=2)
    ax2 = ax1.twinx()
    sns.lineplot(data=dist_over_time[1], x='p', y='d', marker="s", markersize=5, label='t=1', lw=0.8, ax=ax2)
    sns.lineplot(data=dist_over_time[2], x='p', y='d', marker="v", markersize=5, label='t=2', lw=0.8, ax=ax2)
    sns.lineplot(data=dist_over_time[3], x='p', y='d', marker="d", markersize=5, label='t=3', lw=0.8,
                 ax=ax2)
    ax2.legend(loc=0)
    ax1.set_xlabel("Iterations")
    ax1.set_ylabel("Minimum distance (t=0)")
    ax2.set_ylabel("Minimum distance (t>0)")
    plt.show()


def preprocessing():
    for k in range(1, 31):
        dname = ('data_' + str(k))
        # df_PLS = pd.read_excel(io='result1/' + dname + '.xlsx', sheet_name='DPLS')
        # writer = pd.ExcelWriter('result2/' + dname + '.xlsx', mode="a", engine="openpyxl", if_sheet_exists='replace')
        # df_PLS.to_excel(writer, sheet_name='DPLS', index=False)
        # writer.close()

        writer = pd.ExcelWriter('../results/component/' + dname + '.xlsx', engine="openpyxl")
        for sheet in ACO_list:
            print(dname, f'---------------------{sheet}----------------------')
            df = pd.read_excel(io='../results/temp/' + dname + '.xlsx', sheet_name=sheet)
            f_dict = {}
            for i, row in df.iterrows():
                if row[0] not in f_dict.keys():
                    f_dict[row[0]] = []
                f_dict[row[0]].append([row[1], row[2]])

            for k, f_list in f_dict.items():
                f_list = [list(x) for x in set(tuple(x) for x in f_list)]
                f_dict[k] = f_list
            new_list = []
            for k, f_list in f_dict.items():
                f_list.sort(key=lambda x: (x[0], -x[1]))
                for f in f_list:
                    new_list.append([k] + f)
            df_new = pd.DataFrame(new_list, columns=['t', 'f1', 'f2'])
            df_new.to_excel(writer, sheet_name=sheet, index=False)
        writer.close()


def comparison():
    MHV_list = []
    MSP_list = []
    MSR_list = []
    for i in range(1, 31):
        file_name = '../results/comparison/' + 'data_' + str(i)
        print('---------------' + file_name + '-------------------')
        data = {}
        for algo in algo_list:
            df = pd.read_excel(io=file_name + '.xlsx', sheet_name=algo)
            data[algo] = df
        MHV, MSP, MSR = cal_mo_metric(algo_list, data)
        MHV_list.append(MHV)
        MSP_list.append(MSP)
        MSR_list.append(MSR)

    writer = pd.ExcelWriter('../results/comparison/indicator.xlsx', mode="a", engine="openpyxl",
                            if_sheet_exists='replace')
    df = pd.DataFrame(MHV_list)
    df.to_excel(writer, sheet_name='mhv', index=False)
    df = pd.DataFrame(MSP_list)
    df.to_excel(writer, sheet_name='msp', index=False)
    df = pd.DataFrame(MSR_list)
    df.to_excel(writer, sheet_name='msr', index=False)
    writer.close()


def component():
    MHV_list = []
    MSP_list = []
    MSR_list = []
    com_list = ['mACOOL', 'mACOOL-NT', 'mACOOL-NU']
    for i in range(1, 31):
        file_name = '../results/component/' + 'data_' + str(i)
        print('---------------' + file_name + '-------------------')
        data = {}
        for algo in com_list:
            df = pd.read_excel(io=file_name + '.xlsx', sheet_name=algo)
            data[algo] = df
        MHV, MSP, MSR = cal_mo_metric(com_list, data)
        MHV_list.append(MHV)
        MSP_list.append(MSP)
        MSR_list.append(MSR)

    writer = pd.ExcelWriter('../results/component/indicator.xlsx', mode="a", engine="openpyxl",
                            if_sheet_exists='replace')
    df = pd.DataFrame(MHV_list)
    df.to_excel(writer, sheet_name='mhv', index=False)
    df = pd.DataFrame(MSP_list)
    df.to_excel(writer, sheet_name='msp', index=False)
    df = pd.DataFrame(MSR_list)
    df.to_excel(writer, sheet_name='msr', index=False)
    writer.close()


if __name__ == "__main__":
    # preprocessing()
    # comparison()
    # component()

    df = pd.read_excel(io='../results/component/indicator.xlsx', sheet_name='mhv')
    ANOVA(df, 'MHV', x_tick=['mACO/OL', 'PMMAS', 'MOPSO', 'NSGA-II', 'PLS','MOACS/MP'])
    df = pd.read_excel(io='../results/component/indicator.xlsx', sheet_name='msp')
    ANOVA(df, 'MSP', x_tick=['mACO/OL', 'PMMAS', 'MOPSO', 'NSGA-II', 'PLS','MOACS/MP'])
    df = pd.read_excel(io='../results/component/indicator.xlsx', sheet_name='msr')
    ANOVA(df, 'MSR', x_tick=['mACO/OL', 'PMMAS', 'MOPSO', 'NSGA-II', 'PLS','MOACS/MP'])

    # plot_real_case()
