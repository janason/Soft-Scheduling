import itertools
import time

import pyomo.environ as pyo
import seaborn as sns
from pyomo.opt import TerminationCondition

from model.utils import *


def build_model(problem, Qmin, Qmax, distances):
    # 模型
    N = len(problem.released_slabs) + 1
    depot = 0  # 配送中心的索引
    model = pyo.ConcreteModel()
    model.V0 = pyo.Set(initialize=range(N))
    model.V1 = pyo.Set(initialize=range(1, N))
    model.A = pyo.Set(initialize=[(i, j) for i in model.V0 for j in model.V0 if i != j])
    model.K = pyo.Set(initialize=range(problem.round_number))

    # 变量
    model.x = pyo.Var(model.K, model.A, within=pyo.Binary)
    model.u = pyo.Var(model.K, model.V0, within=pyo.NonNegativeIntegers, bounds=(1, N - 1))
    model.y = pyo.Var(model.K, model.V1, within=pyo.Binary)

    # 约束条件
    model.constraints = pyo.ConstraintList()

    # 每一个节点只能被一辆所访问
    for i in model.V1:
        model.constraints.add(sum(model.y[k, i] for k in model.K) <= 1)

    # 确保每辆车从配送中心出发并回到配送中心
    for k in model.K:
        model.constraints.add(sum([model.x[k, depot, j] for j in model.V1]) == 1)
        model.constraints.add(sum([model.x[k, i, depot] for i in model.V1]) == 1)

    # 容量约束
    for k in model.K:
        model.constraints.add(sum([model.y[k, i] * problem.dmd_dict[i] for i in model.V1]) <= Qmax)
        model.constraints.add(sum([model.y[k, i] * problem.dmd_dict[i] for i in model.V1]) >= Qmin)

    for k, i in itertools.product(model.K, model.V1):
        model.constraints.add(sum(model.x[k, i, j] for j in model.V0 if i != j) == model.y[k, i])
        model.constraints.add(sum(model.x[k, j, i] for j in model.V0 if i != j) == model.y[k, i])

    # 防止子环约束
    for k in model.K:
        for i, j in itertools.product(model.V1, model.V1):
            if i != j:
                model.constraints.add(model.u[k, i] - model.u[k, j] + N * model.x[k, i, j] <= N - 1)
    if problem.t > 0:
        visited = [0]
        for s in problem.fixed_slabs:
            j = s.idx
            # model.constraints.add(model.y[0, j] == 1)
            visited.append(j)
        for i in range(1, len(visited)):
            j1 = visited[i - 1]
            j2 = visited[i]
            model.constraints.add(model.x[0, j1, j2] == 1)
    return model


def find_tours(model, prob, visualize=False):
    tours = []
    for k in model.K:
        node = 0
        tours.append([0])
        while True:
            for j in model.V0:
                if (node, j) in model.A:
                    if np.isclose(model.x[k, node, j].value, 1):
                        node = j
                        tours[-1].append(node)
                        break
            if node == 0:
                break
    if visualize:
        x = []
        y = []
        c = []
        s = []
        for k, tour in enumerate(tours):
            for nd in tour:
                if nd != 0:
                    slab = prob.get_slab(nd)
                    x.append(len(x) + 1)
                    y.append(slab.width)
                    s.append(str(slab.idx))
                    if k == 0:
                        c.append('red')
                    else:
                        c.append('blue')
        # 绘制柱状图
        plt.figure(figsize=(6, 3.6))
        sns.set_style('ticks')
        # fig, ax = plt.subplots()
        plt.bar(x, y, width=1, color=c, edgecolor="white", linewidth=0.7)
        for i in range(len(x)):
            plt.text(x[i] - 0.5, y[i], s[i])
        plt.xlabel('No. in rounds')
        plt.ylabel('Width')
        plt.show()

    return tours[0] + tours[1]


def solve_PCCVRP(problem, distances):
    # 求解模型
    f1 = []
    f2 = []
    for step in range(1, 21):
        alpha = 0 + 0.05 * step
        # 目标函数
        model = build_model(problem, 200, 400, distances)
        dist_expr = sum(distances[i, j] * model.x[k, i, j] for k in model.K for i, j in model.A)
        loss_expr = sum((1 - model.y[k, i]) * problem.get_slab(i).price for k in model.K for i in model.V1)
        model.obj = pyo.Objective(
            expr=alpha * dist_expr + (1 - alpha) * loss_expr,
            sense=pyo.minimize)
        solver = pyo.SolverFactory('gurobi')
        result = solver.solve(model)
        if result.solver.termination_condition != TerminationCondition.optimal:
            continue
        print(model.obj())
        f1.append(pyo.value(dist_expr))
        f2.append(pyo.value(loss_expr))
        if alpha == 0.5:
            tours = find_tours(model, problem, visualize=True)
            for s in tours:
                if 0 != s:
                    problem.fixed_slabs.append(problem.get_slab(s))
    return f1, f2


def main():
    file_name = 'data_0'
    problem = read_from_file(file_name)

    distances = {}
    for i, j in problem.dist_matrix.keys():
        distances[i, j] = problem.dist_matrix[i, j]
        if i == 0:
            distances[0, j] = 0
            distances[j, 0] = 0

    problem.update(0)
    sns.set_style('ticks')
    f01, f02 = solve_PCCVRP(problem, distances)
    print(f01, f02)
    problem.update(problem.T[0])
    f11, f12 = solve_PCCVRP(problem, distances)
    print(f11, f12)

    max_f1 = max(max(f01), max(f11))
    min_f1 = min(min(f01), min(f11))
    max_f2 = max(max(f02), max(f12))
    min_f2 = min(min(f02), min(f12))
    new_f01 = [(f - min_f1) / (max_f1 - min_f1) for f in f01]
    new_f02 = [(f - min_f2) / (max_f2 - min_f2) for f in f02]
    new_f11 = [(f - min_f1) / (max_f1 - min_f1) for f in f11]
    new_f12 = [(f - min_f2) / (max_f2 - min_f2) for f in f12]
    plt.figure(figsize=(6, 4))
    plt.scatter(new_f01, new_f02, marker='o', color='r', label='t=0')
    plt.scatter(new_f11, new_f12, marker='s', color='b', label='t=6')
    plt.legend()
    plt.xlabel("$f_1$", fontsize=12)
    plt.ylabel("$f_2$", fontsize=12)
    plt.show()

    # 输出结果
    # for k in vehicles:
    #     print(f"Vehicle {k}:")
    #     for i in nodes:
    #         for j in nodes:
    #             if i != j and model.x[k, i, j].value == 1:
    #                 print(f"  从节点 {i} 到节点 {j}")
    #         # if model.y[k, i].value == 1:
    #         #     print(f'  从节点 {i} ')
    # for k in vehicles:
    #     print(f"Vehicle {k}:")
    #     for i in clients:
    #         if model.y[k, i].value == 1:
    #             print(f'  从节点 {i} ')
    #
    # for k in vehicles:
    #     print(f"Vehicle {k}:")
    #     for i in clients:
    #         if model.y[k, i].value == 1:
    #             print(f'节点 {i} @ {model.u[k, i].value} ')


if __name__ == "__main__":
    start_time = time.time()
    main()
    # 记录结束时间
    end_time = time.time()

    # 计算运行时间
    execution_time = end_time - start_time
    print(f"程序运行时间: {execution_time} 秒")