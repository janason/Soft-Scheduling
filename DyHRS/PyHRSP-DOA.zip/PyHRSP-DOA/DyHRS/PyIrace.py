import itertools

import numpy as np
from irace import irace

from DyHRS.main import *


# alpha_list = [1, 2, 3]
# beta_list = [2, 3, 4]
# rho_list = [0.05, 0.10, 0.15, 0.20]
# Gval_list = [3, 5, 7, 9]
# Psize_list = [5, 10, 15]
# Cval_list = [3, 4, 5]


# This target_runner is over-complicated on purpose to show what is possible.
def target_runner(experiment, scenario):
    if scenario['debugLevel'] > 0:
        # Some configurations produced a warning, but the values are within the limits. That seems a bug in scipy.
        # TODO: Report the bug to scipy.
        print(f'{experiment["configuration"]}')
    id = experiment['instance']
    cfg = experiment['configuration']
    mACOOL_params['alpha'] = int(cfg['alpha'])
    mACOOL_params['beta'] = int(cfg['beta'])
    mACOOL_params['rho'] = float(cfg['rho'])
    mACOOL_params['Gval'] = int(cfg['G_val'])
    mACOOL_params['Cval'] = int(cfg['C_val'])
    mACOOL_params['Psize'] = int(cfg['P_size'])

    MHV = run(id * 5 + 1, mACOOL, mACOOL_params)
    file = open('irace0.txt', 'a')
    file.write(f'inst={id*5+1}' + '\n')
    file.write(str(mACOOL_params) + '\n')
    file.write(f'ahv={MHV} \n')
    file.write('--------------------------------------------\n')
    file.close()

    return dict(cost=1 / MHV)


parameters_table = '''
alpha "" c (1, 2, 3)
beta "" c (2, 3, 4)
rho "" c (0.05, 0.10, 0.15)
P_size "" c (5, 10, 15)
G_val "" c (3, 5, 7, 9)
C_val "" c (3, 4, 5)
'''

print(parameters_table)

default_values = '''
alpha    beta   rho P_size  G_val   C_val
1   2   0.10    10  5   5   
'''

print(default_values)

# These are dummy "instances", we are tuning only on a single function.
instances = np.arange(6)

# See https://mlopez-ibanez.github.io/irace/reference/defaultScenario.html
scenario = dict(
    instances=instances,
    maxExperiments=200,
    debugLevel=3,
    digits=1,
    parallel=1,  # It can run in parallel !
    logFile="")

tuner = irace(scenario, parameters_table, target_runner)
tuner.set_initial_from_str(default_values)
best_confs = tuner.run()
print(best_confs)

file = open('irace0.txt', 'a')
file.write(best_confs.to_string())
file.close()
