from model import const

const.K = 2
const.M = 15
const.N = const.K * const.M
const.C = 360
const.U = 10  # 跳变次数
const.E = const.K - 1  # 动态事件次数
const.min_width = 6
const.max_width = 15
const.min_gauge = 1
const.max_gauge = 5
const.min_hardn = 1
const.max_hardn = 5
const.min_leng = 20
const.max_leng = 40

mACOOL_params = dict(
    alpha=3,
    beta=2,
    Gval=7,
    Cval=4,
    rho=0.15,
    Psize=5
)

PMMAS_params = dict(
    alpha=1,
    beta=2,
    rho=0.1,
    Psize=40,
    Cval=3
)

MPMOAS_params = dict(
    alpha=1,
    beta=3,
    rho=0.15,
    Psize=40,
    Cval=3
)

DPLS_params = dict(
    Psize=100,
    Qmax=200,
    Cval=3
)

NSGA2_params = dict(
    pc=1.0,
    pm=0.05,
    Psize=50,
    Cval=3
)

MOPSO_params = dict(
    Psize=50,
    Cval=3
)
