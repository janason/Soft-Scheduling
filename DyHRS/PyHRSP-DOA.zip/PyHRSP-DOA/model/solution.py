import copy
import math
import random

from model.entities import Problem, Slab
from ortools.constraint_solver import pywrapcp
from ortools.constraint_solver import routing_enums_pb2

OBJ_CNT = 2


# 不考虑烫辊材料的部分

class Solution:

    def __init__(self, problem: Problem, to_visit_idx=[], visited_idx=[]):
        self._init_tour = visited_idx + to_visit_idx
        self._fixed_idx = [i for i in visited_idx]
        self._problem = problem

        self._capacity = [rod.capacity for rod in problem.round_list]
        self._subtours = [[] for rod in problem.round_list]
        # self._loading = [0 for rod in problem.round_list]
        self._objectives = [float('inf') for i in range(OBJ_CNT)]

        self._collected_list = []
        self._uncollected_list = []
        self._final_tour = []
        self._is_feasible = True
        self.explored = False
        return

    @property
    def objectives(self):
        return self._objectives

    @property
    def capacity(self):
        return self._capacity

    @property
    def is_feasible(self):
        return self._is_feasible

    @property
    def init_tour(self):
        return self._init_tour

    @property
    def subtours(self):
        return self._subtours

    @property
    def collected(self):
        return self._collected_list

    @property
    def uncollected(self):
        return self._uncollected_list

    @property
    def final_tour(self):
        return self._final_tour

    def is_exist_path(self, from_node, to_node):
        for tour in self._subtours:
            if tour.count(from_node) > 0:
                i = tour.index(from_node)
                if i < len(tour) - 1:
                    if tour[i + 1] == to_node:
                        return True
        return False

    def reset(self):
        self._capacity = [rod.capacity for rod in self._problem.round_list]
        self._subtours = [[] for rod in self._problem.round_list]
        self._loading = [0 for rod in self._problem.round_list]
        self._objectives = [float('inf') for i in range(OBJ_CNT)]

        self._collected_list = []
        self._uncollected_list = []
        self._final_tour = []
        self._is_feasible = True
        self.explored = False
        return

    def evaluate_x(self):
        self.reset()
        if len(self._init_tour) == 0:
            return math.inf
        seqs = copy.copy(self._init_tour)
        travel_dist = 0.0
        is_feasible = True
        for k in range(len(self._subtours)):
            tour = self._subtours[k]
            remain = self._capacity[k]
            prev_node = 0
            len_same_width = 0
            current_width = 0
            prev_slab: Slab = None
            while remain >= 0:
                curr_node = seqs[0]
                curr_slab: Slab = self._problem.get_slab(curr_node)
                if prev_slab is not None:
                    if curr_slab.width != prev_slab.width and curr_slab.hardness != prev_slab.hardness \
                            and curr_slab.gauge != prev_slab.gauge:
                        is_feasible = False
                    if curr_slab.width == prev_slab.width:
                        is_feasible = False
                if remain - self._problem.dmd_dict[curr_node] < 0:
                    break
                travel_dist += self._problem.dist_matrix[(prev_node, curr_node)]
                remain = remain - self._problem.dmd_dict[curr_node]
                tour.append(curr_node)
                prev_node = curr_node
                seqs.pop(0)
        loss = 0
        for node in seqs:
            loss += self._problem.prize_dict[node]
        if is_feasible:
            self._objectives = [travel_dist, loss]
        else:
            self._objectives = [travel_dist * 100, loss * 100]

    def evaluate_aco(self, select_first_node, select_next_node, tau=None, eta=None):
        self.reset()
        self._uncollected_list = [node for node in self._init_tour]
        travel_cost = 0.0
        n = 0
        for r, tour in enumerate(self._subtours):
            remain = self._capacity[r]
            LW_limit = self._capacity[r] * self._problem.max_ratio_same_width
            lw_cumul = 0
            prev_node = 0
            prev_width = -1
            tour_len = 0
            while remain > 0:
                if n < len(self._fixed_idx):  # 选择已固定的板坯
                    node = self._fixed_idx[n]
                    slab: Slab = self._problem.get_slab(node)
                    if lw_cumul + slab.length > LW_limit:
                        node = -1
                else:
                    if prev_node > 0:
                        dyn_constr = [(lw_cumul, LW_limit), (remain, 0)]
                        node = select_next_node(prev_node, self._uncollected_list, dyn_constr, tau, eta)  # next slab
                    else:
                        node = select_first_node(self._uncollected_list)
                if node < 0:  # 没有选到
                    break
                slab: Slab = self._problem.get_slab(node)
                if remain - slab.length < 0:  # 选中的不符合条件
                    break
                remain = remain - slab.length
                tour.append(node)
                self._uncollected_list.remove(node)
                self._collected_list.append(node)
                # print(remain)
                # 计算目标函数
                travel_cost += self._problem.dist_matrix[(prev_node, node)]
                if prev_width == slab.width:
                    lw_cumul += slab.length
                else:
                    lw_cumul = slab.length
                tour_len += slab.length
                prev_width = slab.width
                prev_node = node
                n = n + 1

            self._loading[r] = tour_len
            if tour_len < self._problem.min_ratio_capacity * self._capacity[r]:
                self._is_feasible = False

        prize_loss = 0.0
        self._final_tour = self._collected_list + self._uncollected_list
        for node in self._uncollected_list:
            prize_loss += self._problem.prize_dict[node]

        if self._is_feasible:
            self._objectives = travel_cost, prize_loss
        else:
            self._objectives = travel_cost * 10, prize_loss * 10
        return

    def evaluate_rui(self):
        self.reset()
        self._uncollected_list = [node for node in self._init_tour]
        travel_dist = 0.0
        for k in range(len(self._subtours)):
            tour = self._subtours[k]
            remain = self._capacity[k]
            LW_limit = self._capacity[k] * self._problem.max_ratio_same_width
            Min_len = self._capacity[k] * self._problem.min_ratio_capacity
            lw_dict = {}
            fixed_len = 0
            while remain >= 0:
                node = self._uncollected_list[0]
                slab: Slab = self._problem.get_slab(node)
                if remain - slab.length < 0:  # 同宽限制
                    break
                if slab.width in lw_dict.keys():  # 同宽长度限制
                    if lw_dict[slab.width] + slab.length > LW_limit:
                        break
                if node in self._fixed_idx:  # 如果是已锁定的板坯，那就直接放入
                    tour.append(node)
                    fixed_len += 1
                else:
                    t_pos = -1
                    for i in range(len(tour) - 1, -1, -1):
                        t_node = tour[i]
                        t_slab: Slab = self._problem.get_slab(t_node)
                        if t_node in self._fixed_idx:
                            t_pos = len(tour) - 1
                            break
                        else:
                            if t_slab.width >= slab.width:
                                t_pos = i
                                break
                    tour.insert(max(t_pos + 1, fixed_len), node)
                if slab.width in lw_dict.keys():
                    lw_dict[slab.width] += slab.length
                else:
                    lw_dict[slab.width] = slab.length
                remain = remain - slab.length
                self._uncollected_list.pop(0)

            # 计算累计距离
            self._collected_list.extend(tour)
            tot_len = 0
            for i, node in enumerate(tour):
                u_slab: Slab = self._problem.get_slab(node)
                tot_len += u_slab.length
                if i > 0:
                    p_slab: Slab = self._problem.get_slab(tour[i - 1])
                    travel_dist += self._problem.dist_matrix[tour[i - 1], node]
                    self._is_feasible = p_slab.is_legal_next(u_slab)

            if tot_len < Min_len:
                self._is_feasible = False
        # 计算损失
        prize_loss = 0
        for node in self._uncollected_list:
            prize_loss += self._problem.prize_dict[node]
        # 重构排列
        self._final_tour = self._collected_list + self._uncollected_list
        if self._is_feasible:
            self._objectives = travel_dist, prize_loss
        else:
            self._objectives = travel_dist * 10, travel_dist * 10

    def evaluate_X(self, X):
        self._is_feasible = True
        self._collected_list = []
        self._uncollected_list = [s.idx for s in self._problem.released_slabs]
        travel_cost = 0
        for r in range(1, len(X)):
            remain = self._capacity[r - 1]
            LW_limit = remain * self._problem.max_ratio_same_width
            lw_cumul = 0
            prev_nod = 0
            prev_wid = -1
            prev_slab: Slab = None
            for nod in X[r]:
                slab: Slab = self._problem.get_slab(nod)
                remain -= slab.length
                if slab.width == prev_wid:
                    lw_cumul += slab.length
                else:
                    lw_cumul = slab.length
                if prev_nod > 0:
                    travel_cost += self._problem.dist_matrix[prev_nod, nod]
                    if prev_slab.width != slab.width and slab.gauge != prev_slab.gauge and slab.hardness != prev_slab.hardness:
                        self._is_feasible = False
                prev_nod = nod
                prev_slab = slab
                self._uncollected_list.remove(nod)
                self._collected_list.append(nod)
            if remain < 0 or lw_cumul > LW_limit:
                self._is_feasible = False

        prize_loss = 0.0
        self._final_tour = self._collected_list + self._uncollected_list
        for node in self._uncollected_list:
            prize_loss += self._problem.prize_dict[node]

        if self._is_feasible:
            self._objectives = travel_cost, prize_loss
        else:
            self._objectives = travel_cost * 10, prize_loss * 10

    def dominate(self, other):
        n = len(self._objectives)
        for i in range(n):
            if self._objectives[i] > other.objectives[i]:
                return False
        rtn = any(self._objectives[i] < other.objectives[i] for i in range(n))
        return rtn

    def __lt__(self, other):
        nlt = 0
        for i, obj in enumerate(self.objectives):
            if obj < other.objectives[i]:
                nlt = nlt + 1
            if obj > other.objectives[i]:
                return False
        if nlt != 0:
            return True

        return False

    def _replace_node(self, _node, _prev, _next):
        if _node in self._fixed_idx:
            return -1

        old_dist = self._problem.dist_matrix[_prev, _node] + self._problem.dist_matrix[_node, _next]
        old_slab: Slab = self._problem.get_slab(_node)
        for new_node in self._uncollected_list:
            new_slab: Slab = self._problem.get_slab(new_node)
            new_dist = self._problem.dist_matrix[_prev, new_node] + self._problem.dist_matrix[new_node, _next]
            if new_dist <= old_dist and new_slab.price > old_slab.price:
                return new_node
        return -1

    def _fast_sorting(self, _tour):
        sorted_tour = []
        for i, s in enumerate(_tour):
            slab = self._problem.get_slab(s)
            if s in self._fixed_idx:
                sorted_tour.append((i, 0, s))
            else:
                sorted_tour.append((i, 1 / slab.width, s))
        sorted_tour.sort(key=lambda x: (x[1], x[0]))

        new_tour = [i[2] for i in sorted_tour]
        return new_tour


    def improve_quality(self, resort=True, swap=True):
        # 1. 快速排序排序及替换
        for k, tour in enumerate(self._subtours):
            new_tour = tour
            if resort:
                new_tour = self._fast_sorting(tour)
            max_len = self._capacity[k]
            min_len = self._problem.min_ratio_capacity * max_len
            cur_len = sum([self._problem.get_slab(nod).length for nod in tour])
            if cur_len < min_len:  # insert
                uncol_list = [s for s in self._uncollected_list]
                random.shuffle(uncol_list)
                for s in uncol_list:
                    slab: Slab = self._problem.get_slab(s)
                    if cur_len+slab.length < max_len:
                        new_tour.append(s)
                        cur_len += cur_len+slab.length
                        self._uncollected_list.remove(s)
                    else:
                        break
                tmp_list = [(s, self._problem.get_slab(s).width) for s in new_tour]
                tmp_list.sort(key=lambda x: x[1], reverse=True)
                new_tour = [x[0] for x in tmp_list]
            if swap:
                for j, old_n in enumerate(new_tour):
                    if j == 0:
                        prev_n = 0
                        next_n = new_tour[j + 1]
                    elif j == len(new_tour) - 1:
                        prev_n = new_tour[j - 1]
                        next_n = 0
                    else:
                        prev_n = new_tour[j - 1]
                        next_n = new_tour[j + 1]
                    new_n = self._replace_node(old_n, prev_n, next_n)
                    if new_n < 0:
                        continue
                    old_slab: Slab = self._problem.get_slab(old_n)
                    new_slab: Slab = self._problem.get_slab(new_n)
                    tmp_len = cur_len - old_slab.length + new_slab.length
                    if min_len <= tmp_len <= max_len:
                        new_tour[j] = new_n
                        self._uncollected_list.remove(new_n)
                        cur_len = tmp_len
            self.subtours[k] = new_tour
        # 3. 重新计算目标函数
        travel_cost = 0.0
        prize_loss = 0.0
        self._is_feasible = True
        self._collected_list = []
        self._uncollected_list = [n for n in self._init_tour]
        for k, tour in enumerate(self._subtours):
            Max_len = self._capacity[k]
            LW_limit = self._problem.max_ratio_same_width * Max_len
            len_tot = 0
            len_sw = 0
            prev_wid = -1
            for i, nod in enumerate(tour):
                self._collected_list.append(nod)
                self._uncollected_list.remove(nod)
                if i > 0:
                    travel_cost += self._problem.dist_matrix[tour[i - 1], nod]
                slab: Slab = self._problem.get_slab(nod)
                if slab.width == prev_wid:
                    len_sw += slab.length
                else:
                    len_sw = slab.length
                len_tot += slab.length
                if len_sw > LW_limit or len_tot > Max_len:
                    self._is_feasible = False
        self._final_tour = self._collected_list + self._uncollected_list
        for node in self._uncollected_list:
            prize_loss += self._problem.prize_dict[node]
        rtn = False
        if travel_cost < self.objectives[0] or prize_loss < self.objectives[1]:
            rtn = True
        self._objectives = (travel_cost, prize_loss)
        return rtn
