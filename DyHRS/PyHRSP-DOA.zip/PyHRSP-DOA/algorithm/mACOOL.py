import copy
import time
import random
import numpy as np

from algorithm.utils.transfer import Transfer
from model.solution import *
from algorithm.gMOO import gMOO
from model.entities import *
import itertools


# Chiang T C, Hsu W H. A knowledge-based evolutionary algorithm for the multiobjective vehicle routing problem with
# time windows[J]. Computers & Operations Research, 2014, 45: 25-37.

class mACOOL(gMOO):
    has_transfer = True
    has_UCB1 = True

    def __init__(self, problem, param_dict):
        super().__init__(problem, param_dict)
        self.alpha = param_dict['alpha']
        self.beta = param_dict['beta']
        self.rho = param_dict['rho']
        self.G = param_dict['Gval']
        self.C = param_dict['Cval'] * problem.round_number
        self.P_size = param_dict['Psize'] * problem.round_number

        self.Tau = {}
        self.Eta = [{} for i in range(self.G)]
        self.Tau_max = 1 / self.rho
        self.Tau_min = self.Tau_max / (2 * self.P_size)
        self.omega = [(g / (self.G - 1), 1 - g / (self.G - 1)) for g in range(self.G)]

        self.trails = [[0, 0] for g in range(self.G)]  # trails & score
        self.prev_visit_list = []

    def name(self):
        return "mACOOL"

    def initialize(self):
        super().initialize()
        visiting_list = self.visited_idx + self.to_visit_idx
        # initialize eta
        for g in range(self.G):
            eta = {}
            for i1, i2 in itertools.product(visiting_list, visiting_list):
                if i1 != i2:
                    eta[i1, i2] = self.problem.prize_dict[i2] ** self.omega[g][0] / \
                                  (self.problem.dist_matrix[i1, i2] + 1) ** self.omega[g][1]
            self.Eta[g] = eta

        if self.problem.t > 0 and mACOOL.has_transfer:
            trans = Transfer(self.problem, self.Tau, self.C)
            trans.node_learning(self.prev_visit_list)
            trans.update_tau(self.to_visit_idx + self.visited_idx, self.Tau, self.Tau_min, self.Tau_max)
        else:
            for i1 in [0] + visiting_list:
                for i2 in visiting_list:
                    if i1 != i2:
                        self.Tau[i1, i2] = 1.0
        self.prev_visit_list = self.visited_idx + self.to_visit_idx
        return

    def searchFirstNode(self, SE_List):
        candidates = []
        for i, node_no in enumerate(SE_List):
            slab: Slab = self.problem.get_slab(node_no)
            candidates.append((node_no, slab.width, slab.price))
        candidates.sort(key=lambda x: (x[1], x[2]), reverse=True)
        rnd = random.randint(0, int(len(candidates) * 0.1))
        next_node_no = candidates[rnd][0]
        return next_node_no

    def searchNextNode(self, current_node_no, SE_List, dyn_constr, tau, eta):
        # 获得可选列表
        allows = self.allow_list[current_node_no]
        candidates = list(set(allows).intersection(set(SE_List)))
        sel_list = []
        # 同宽约束
        for id in candidates:
            salb: Slab = self.problem.get_slab(id)
            if dyn_constr[0][0] + salb.length <= dyn_constr[0][1] \
                    and dyn_constr[1][0] - salb.length > dyn_constr[1][1]:
                sel_list.append(id)
        if len(sel_list) == 0:
            return -1

        prob = np.zeros(len(sel_list))
        for i, node_no in enumerate(sel_list):
            _eta = eta[current_node_no, node_no]
            _tau = tau[current_node_no, node_no]
            prob[i] = ((_eta ** self.alpha) * (_tau ** self.beta))

        # 使用轮盘赌选择
        cumsumprob = (prob / sum(prob)).cumsum()
        cumsumprob -= np.random.rand()
        next_node_no = sel_list[list(cumsumprob > 0).index(True)]
        return next_node_no

    # 更新信息素矩阵
    def update_Tau(self, ants):
        sorted_list = sorted(ants, key=lambda x: (x.objectives[0], -x.objectives[1]))
        OHI = []
        # calculate ohcv
        for i, s in enumerate(sorted_list):
            if i == 0:
                s_sup = None
            else:
                s_sup = sorted_list[i - 1]
            if i == len(sorted_list) - 1:
                s_inf = None
            else:
                s_inf = sorted_list[i + 1]
            if s_inf is None and s_sup is None:
                ohvc = 1.0
            elif s_inf is None:
                ohvc = 2 * (s.objectives[0] - s_sup.objectives[0]) * (s_sup.objectives[1] - s.objectives[1])
            elif s_sup is None:
                ohvc = 2 * (s_inf.objectives[0] - s.objectives[0]) * (s.objectives[1] - s_inf.objectives[1])
            else:
                ohvc_sup = (s.objectives[0] - s_sup.objectives[0]) * (s_sup.objectives[1] - s.objectives[1])
                ohvc_inf = (s_inf.objectives[0] - s.objectives[0]) * (s.objectives[1] - s_inf.objectives[1])
                ohvc = ohvc_inf + ohvc_sup
            OHI.append(ohvc)

        sum_ohi = sum(OHI)
        ratios = [v / sum_ohi for v in OHI]
        rho = self.rho
        for k in self.Tau.keys():
            self.Tau[k] = max((1 - rho) * self.Tau[k], self.Tau_min)
        # update Tau according to sol.nodes_seq(solution of TSP)
        for s, sol in enumerate(sorted_list):
            from_node = 0
            for tour in sol.subtours:
                for node in tour:
                    to_node = node
                    self.Tau[from_node, to_node] = min(self.Tau[from_node, to_node] + 1.0 * ratios[s], self.Tau_max)
                    from_node = to_node

    # -- 基于UCB1算法的向量选取
    def select_Eta(self, ep, k):
        N = ep * self.P_size + k + 1
        trails = [self.trails[g][0] for g in range(self.G)]
        if mACOOL.has_UCB1 and min(trails) >= 5:
            if random.random() < 0.2:
                g = random.randint(0, self.G - 1)
            else:
                ucb = []
                for g in range(self.G):
                    mean = self.trails[g][1] / self.trails[g][0]
                    ucb.append(mean + np.sqrt(2 * np.log(N) / self.trails[g][0]))
                g = np.argmax(ucb)
        else:
            g = random.randint(0, self.G - 1)
        return g, self.Eta[g]

    def update_scores(self, ants, survivals):

        for i, g in ants:
            self.trails[g][0] += 1  # one more trail
            if i in survivals:
                self.trails[g][1] += 1  # get more scores

    def execute(self):
        t1 = time.perf_counter()
        self.iter = 1
        while True:
            colony = []
            for k in range(self.P_size):
                sol = Solution(self.problem, visited_idx=self.visited_idx, to_visit_idx=self.to_visit_idx)
                g, _eta = self.select_Eta(self.iter, k)
                sol.evaluate_aco(self.searchFirstNode, self.searchNextNode, self.Tau, _eta)
                colony.append((k, g, sol))
            # update population
            self.sol_list = [_[2] for _ in colony]
            for sol in self.sol_list:
                new_sol = copy.copy(sol)
                if new_sol.improve_quality():
                    self.sol_list.append(new_sol)

            # update external archive
            survivals = self.update_archive(self.sol_list)
            self.update_ideal_distance()
            # update Pheromone matrices
            self.update_scores([(_[0], _[1]) for _ in colony], survivals)
            self.update_Tau(self.EAP)
            print("%s/%s， size of EAP: %s" % (self.iter, self.M_iter, len(self.EAP)))
            with open('log.txt', "a") as file:  # 只需要将之前的”w"改为“a"即可，代表追加内容
                for s in self.EAP:
                    str = f'{self.problem.t}' + '\t' + f'{self.iter}' + '\t' \
                          + f'{s.objectives[0]:.1f}' + '\t' + f'{s.objectives[1]:.1f}'
                    file.write(str + '\n')

            self.iter = self.iter + 1
            t2 = time.perf_counter()
            if t2 - t1 > self.tm_budget:
                break

        t2 = time.perf_counter()
        print(f'cost= {t2 - t1:.8f}s')
        with open('log.txt', "a") as file:  # 只需要将之前的”w"改为“a"即可，代表追加内容
            file.write(f'cost= {t2 - t1:.4f}s' + '\n')
