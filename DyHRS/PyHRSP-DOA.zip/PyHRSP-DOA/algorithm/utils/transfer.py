import random

from sklearn.cluster import KMeans

from model.entities import *
from sklearn.metrics import pairwise_distances_argmin_min


class Transfer:

    def __init__(self, problem: Problem, old_tau, cluster_cnt):
        self._problem = problem
        self._model = None
        self._cluster = []
        self._labels = {}
        self._old_tau = old_tau
        self._old_nodes = []
        self._closest = []
        self._cluster_cnt = cluster_cnt
        self._sample_cnt = 2 * self._problem.round_number
        return

    def node_learning(self, nodes):
        X = []
        y = []
        self._sample_cnt = int(len(nodes) / self._cluster_cnt / 5)
        self._labels = dict()
        for idx in nodes:
            s = self._problem.get_slab(idx)
            x = [s.width, s.gauge, s.hardness, s.price]
            X.append(x)
            y.append(s.idx)
            self._labels[s.idx] = []

        self._model = KMeans(n_clusters=self._cluster_cnt)
        z = self._model.fit(X).labels_.tolist()
        self._cluster = [[] for i in range(self._cluster_cnt)]
        for i in range(len(z)):
            idx = y[i]
            c = int(z[i])
            self._cluster[c].append(idx)
        for i in range(len(z)):
            idx = y[i]
            self._labels[idx] = int(z[i])
        # print(self._model.cluster_centers_)
        # 获取质心
        centers = self._model.cluster_centers_
        # 找到每个质心最近的点
        closest, _ = pairwise_distances_argmin_min(centers, X)
        self._closest = [int(i + 1) for i in closest]
        self._old_nodes = nodes
        return self._labels

    def update_tau(self, all_nodes, new_Tau, tau_min, tau_max):
        for i1 in [0] + all_nodes:
            for i2 in all_nodes:
                if i1 == i2:
                    continue
                if i2 in self._labels.keys():
                    c2 = self._labels[i2]
                else:
                    s2: Slab = self._problem.get_slab(i2)
                    X = [[s2.width, s2.gauge, s2.hardness, s2.price]]
                    c2 = self._model.predict(X)[0]
                neighbor = self._cluster[c2]
                if len(neighbor) > self._sample_cnt:
                    neighbor = random.sample(neighbor, self._sample_cnt)
                if len(neighbor) <= 1:
                    xtau = 1.0
                else:
                    if i1 in self._old_nodes + [0]:
                        xtau = sum([self._old_tau[i1, i] for i in neighbor if i != i1]) / len(neighbor)
                    else:
                        s1: Slab = self._problem.get_slab(i1)
                        X = [[s1.width, s1.gauge, s1.hardness, s1.price]]
                        c1 = self._model.predict(X)[0]
                        ii = self._closest[c1]
                        xtau = sum([self._old_tau[ii, i] for i in neighbor if i != ii]) / len(neighbor)
                    xtau = max(min(xtau, tau_max), tau_min)
                new_Tau[i1, i2] = xtau
        return

    def arc_learning(self):
        X = []
        y = []
        for k, v in self._old_tau:
            if k[0] == 0:
                s2: Slab = self._problem.get_slab(k[1])
                x = [s2.width, s2.gauge, s2.hardness, 0, s2.price]
            else:
                s1: Slab = self._problem.get_slab(k[0])
                s2: Slab = self._problem.get_slab(k[1])
                x = [s2.width - s1.width, s2.gauge - s1.gauge, s2.hardness - s1.hardness, s1.price, s2.price]
            X.append(x)
            y.append(v)

        self._model = KMeans(n_clusters=30)
        # y = self._model.fit(X)
        z = self._model.fit(X).labels_.tolist()
        self._labels = list(zip(z, y))

        return self._model, self._labels

    def predict(self, x):
        if self._model is None:
            return None
        lbl = self._model.predict(x)
        tau0 = [y for z, y in self._labels if z == lbl[0]]
        if len(tau0) > 10:
            n = 10
        else:
            n = len(tau0)
        tau1 = random.sample(tau0, n)
        return sum(tau1) / n
