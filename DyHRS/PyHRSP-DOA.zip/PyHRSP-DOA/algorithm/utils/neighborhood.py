from matplotlib import cm as mplcm


# reverse a[i...j]
def two_opt(a, i, j):
    if i == 0:
        return [a[i]] + a[j:i:-1] + a[j + 1:]
    return a[:i] + a[j:i - 1:-1] + a[j + 1:]


def one_opt(a, i):
    return a[:i] + a[-1: i - 1:-1]


# cross a[i...m] and b[j...n]
def cross(a, b, i, j):
    ax = a[i:len(a)]
    bx = b[j:len(b)]
    ar = a[:i] + bx
    br = b[:j] + ax
    return ar, br


# insert a[i] into b[j]
def insertion(a, b, i, j):
    # print(a, b, i, j)
    if len(a) <= 1 or len(b) <= 1:
        return a, b
    if i <= 0 or j <= 0:
        return a, b
    if i >= len(a):
        i = i - len(a) + 1
    if j >= len(b):
        j = j - len(b) + 1

    return a[:i] + a[i + 1:], b[:j] + [a[i]] + b[j:]


# swap a[i] and b[j]
def swap(a, b, i, j):
    # print(a, b, i, j)
    if i >= len(a) or i <= 0:
        return a, b
    if i >= len(a) or i <= 0:
        return a, b
    tmp = a[i]
    a[i] = b[j]
    b[j] = tmp
    return a, b


# exchange-p-q for packing problems
def exchange(a, b, p, q):
    if p > 0:
        ax = a[p]
        a.pop(p)
    else:
        ax = None
    if q > 0:
        bx = b[q]
        b.pop(q)
    else:
        bx = None
    if ax is not None:
        b.append(ax)
    if bx is not None:
        a.append(bx)


def generate_color_list(n, name):
    cm = mplcm.get_cmap(name)
    step = int(cm.N / n)
    color_list = []
    for i in range(0, cm.N, step):
        color_list.append(cm(i))
    return color_list
