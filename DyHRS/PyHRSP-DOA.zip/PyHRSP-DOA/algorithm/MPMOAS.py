import random
import time
import numpy as np

from algorithm.utils.transfer import Transfer
from model.solution import *
from algorithm.gMOO import gMOO
from model.entities import *
import itertools

from model.solution import Solution


# Li J Y, Deng X Y, Zhan Z H, et al. A multipopulation multiobjective ant colony system considering travel and
# prevention costs for vehicle routing in COVID-19-like epidemics[J]. IEEE Transactions on Intelligent Transportation
# Systems, 2022, 23(12): 25062-25076.
#

class MPMOAS(gMOO):

    def __init__(self, problem, param_dict):
        super().__init__(problem, param_dict)
        self.colony_T = []
        self.colony_P = []
        self.prev_visit_list = []
        self.tau_T = {}
        self.tau_P = {}
        self.eta = {}

        self.alpha = 1
        self.beta = 3
        self.rho = 0.15
        self.P_size = 100
        self.tau0_T = 1.0
        self.tau0_P = 1.0
        self.ant_T = None
        self.ant_P = None
        self.allow_list = {}  # tabu list for node

    def name(self):
        return "MPMOAS"

    def initialize(self):
        super().initialize()
        visiting_list = self.visited_idx + self.to_visit_idx
        for i1 in [0] + visiting_list:
            for i2 in visiting_list:
                if i1 != i2:
                    self.eta[i1, i2] = 1 / (self.problem.dist_matrix[i1, i2] + 1)
        # initialize eta and tau
        if self.problem.t > 0:
            trans1 = Transfer(self.problem, self.tau_T, self.C)
            trans1.node_learning(self.prev_visit_list)
            trans1.update_tau(self.to_visit_idx + self.visited_idx, self.tau_T, 0, 10000)

            trans2 = Transfer(self.problem, self.tau_P, self.C)
            trans2.node_learning(self.prev_visit_list)
            trans2.update_tau(self.to_visit_idx + self.visited_idx, self.tau_P, 0, 10000)
        else:
            for i1 in [0] + visiting_list:
                for i2 in visiting_list:
                    if i1 != i2:
                        self.tau_T[i1, i2] = 1.0
                        self.tau_P[i1, i2] = 1.0
        self.prev_visit_list = self.visited_idx + self.to_visit_idx

        # initialize Tau
        self.ant_T = self.greedy_construct_solution('T')
        self.ant_P = self.greedy_construct_solution('P')
        self.tau0_T = 1.0 / self.ant_T.objectives[0]
        self.tau0_P = 1.0 / self.ant_P.objectives[1]

        self.colony_T.append(self.ant_T)
        self.colony_P.append(self.ant_P)
        return

    # TODO 选择最宽的和价值最高的
    def selectFirstNode(self, SE_List):
        to_select = []
        for i, node_no in enumerate(SE_List):
            slab: Slab = self.problem.get_slab(node_no)
            to_select.append((node_no, slab.width, slab.price))

        to_select.sort(key=lambda x: (x[2], x[1]), reverse=True)
        next_node_no = to_select[0][0]
        return next_node_no

    def selectNextNodeGreedyT(self, current_node_no, SE_List, dyn_constr, Tau,
                              Eta):  # lw, LW, current_node_no, SE_List):
        # 获得可选列表
        candidates = list(set(self.allow_list[current_node_no]).intersection(set(SE_List)))
        sel_list = []
        # 同宽约束
        for id in candidates:
            salb: Slab = self.problem.get_slab(id)
            if dyn_constr[0][0] + salb.length <= dyn_constr[0][1] \
                    and dyn_constr[1][0] - salb.length > dyn_constr[1][1]:
                sel_list.append(id)
        if len(sel_list) == 0:
            return -1

        min_dist = 1.0e10
        selc_node_no = -1
        for i, next_node_no in enumerate(sel_list):
            dist = self.problem.dist_matrix[current_node_no, next_node_no]
            if dist < min_dist:
                min_dist = dist
                selc_node_no = next_node_no

        return selc_node_no

    def selectNextNodeGreedyP(self, current_node_no, SE_List, dyn_constr, Tau,
                              Eta):  # lw, LW, current_node_no, SE_List):
        # 获得可选列表
        candidates = list(set(self.allow_list[current_node_no]).intersection(set(SE_List)))
        sel_list = []
        # 同宽约束
        for id in candidates:
            salb: Slab = self.problem.get_slab(id)
            if dyn_constr[0][0] + salb.length <= dyn_constr[0][1] \
                    and dyn_constr[1][0] - salb.length > dyn_constr[1][1]:
                sel_list.append(id)
        if len(sel_list) == 0:
            return -1

        max_prize = -1.0e10
        selc_node_no = -1
        for i, next_node_no in enumerate(sel_list):
            prize = self.problem.prize_dict[next_node_no]
            if prize > max_prize:
                max_prize = prize
                selc_node_no = next_node_no

        return selc_node_no

    def selectNextNode(self, current_node_no, SE_List, dyn_constr, Tau, Eta):  # lw, LW, current_node_no, SE_List):
        # 获得可选列表
        candidates = list(set(self.allow_list[current_node_no]).intersection(set(SE_List)))
        sel_list = []
        # 同宽约束
        for id in candidates:
            salb: Slab = self.problem.get_slab(id)
            if dyn_constr[0][0] + salb.length <= dyn_constr[0][1] \
                    and dyn_constr[1][0] - salb.length > dyn_constr[1][1]:
                sel_list.append(id)
        if len(sel_list) == 0:
            return -1

        prob = np.zeros(len(sel_list))
        for i, next_node_no in enumerate(sel_list):
            eta = Eta[current_node_no, next_node_no]
            tau = Tau[current_node_no, next_node_no]
            prob[i] = ((tau ** self.alpha) * (eta ** self.beta))
        # use Roulette to determine the next node
        cumsumprob = (prob / sum(prob)).cumsum()
        cumsumprob -= np.random.rand()
        next_node_no = sel_list[list(cumsumprob > 0).index(True)]
        return next_node_no

    # 使用贪心法构造初始解, T or P
    def greedy_construct_solution(self, greedy='T'):
        sol = Solution(self.problem, visited_idx=self.visited_idx, to_visit_idx=self.to_visit_idx)
        if greedy == 'T':
            sol.evaluate_aco(select_first_node=self.selectFirstNode, select_next_node=self.selectNextNodeGreedyT,
                             tau=self.tau_T, eta=self.eta)

        if greedy == 'P':
            sol.evaluate_aco(select_first_node=self.selectFirstNode, select_next_node=self.selectNextNodeGreedyP,
                             tau=self.tau_P, eta=self.eta)
        return sol

    def updateTau(self, tau, sol, dtau):
        for i, j in tau.keys():
            if sol.is_exist_path(i, j):
                tau[i, j] = tau[i, j] * (1 - self.rho) + dtau * self.rho

    def calcTauTP(self):
        tau_TP = {}
        lamda = random.random()
        visiting_list = self.visited_idx + self.to_visit_idx
        for i in visiting_list:
            tau_sum_T = sum([self.tau_T[i, z] for z in visiting_list if i != z])
            tau_sum_P = sum([self.tau_P[i, z] for z in visiting_list if i != z])
            for j in visiting_list:
                if i != j:
                    sigma_T = self.tau_T[i, j] / tau_sum_T
                    sigma_P = self.tau_P[i, j] / tau_sum_P
                    tau_TP[i, j] = sigma_T * lamda + sigma_P * (1 - lamda)
        return tau_TP

    def execute(self):
        t1 = time.perf_counter()
        self.iter = 1
        while True:
            # solution construction and update external archive population
            while len(self.colony_T) < int(self.P_size / 2):
                sol = Solution(self.problem, visited_idx=self.visited_idx, to_visit_idx=self.to_visit_idx)
                sol.evaluate_aco(self.selectFirstNode, self.selectNextNode, self.tau_T, self.eta)
                sol.improve_quality()
                self.colony_T.append(sol)
                self.updateTau(self.tau_T, sol, self.tau0_T)

            while len(self.colony_P) < int(self.P_size / 2):
                sol = Solution(self.problem, visited_idx=self.visited_idx, to_visit_idx=self.to_visit_idx)
                sol.evaluate_aco(self.selectFirstNode, self.selectNextNode, self.tau_P, self.eta)
                sol.improve_quality()
                self.colony_P.append(sol)
                self.updateTau(self.tau_T, sol, self.tau0_T)

            tau_TP = self.calcTauTP()
            xsol = Solution(self.problem, visited_idx=self.visited_idx, to_visit_idx=self.to_visit_idx)
            xsol.evaluate_aco(self.selectFirstNode, self.selectNextNode, tau_TP, self.eta)

            # update external archive
            self.update_archive(self.colony_T + self.colony_P + [xsol])
            self.update_ideal_distance()
            # update Pheromone matrices
            sol_list = [sol for sol in self.EAP]
            sorted_T = sorted(sol_list, key=lambda x: x.objectives[0])
            sorted_P = sorted(sol_list, key=lambda x: x.objectives[1])
            self.ant_T = sorted_T[0]
            self.ant_P = sorted_P[0]
            self.updateTau(self.tau_T, self.ant_T, 1 / self.ant_T.objectives[0])
            self.updateTau(self.tau_P, self.ant_P, 1 / self.ant_P.objectives[1])
            self.colony_T.clear()
            self.colony_P.clear()
            print("%s/%s， size of EAP: %s" % (self.iter, self.M_iter, len(self.EAP)))
            self.iter += 1
            t2 = time.perf_counter()
            if t2 - t1 > self.tm_budget:
                break
        t2 = time.perf_counter()
        print(f'cost= {t2 - t1:.8f}s')
