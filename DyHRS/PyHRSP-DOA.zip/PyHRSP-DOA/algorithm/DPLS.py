import copy
import itertools
import time

from abc import ABC
import random

import numpy as np

from algorithm.utils.neighborhood import *
from model.solution import Solution
from algorithm.gMOO import gMOO
from model.entities import *

from ortools.constraint_solver import routing_enums_pb2
from ortools.constraint_solver import pywrapcp


class DPLS(gMOO, ABC):

    def __init__(self, problem: Problem, param_dict: dict):

        super().__init__(problem, param_dict)
        self.Qmax = param_dict['Qmax']

    # TODO initialize the PLS with population
    def initialize(self):
        super().initialize(init_pop=True)
        for sol in self.sol_list:
            sol.evaluate_rui()

        self.update_archive(self.sol_list)

    def get_data_model(self, tour=[]):
        # xtour = [0] + tour
        dist_matrix = [[0] * (len(tour) + 1)] * (len(tour) + 1)
        for i in range(1, len(tour) + 1):
            ix = tour[i - 1]
            s1: Slab = self.problem.get_slab(ix)
            for j in range(1, len(tour) + 1):
                if i != j:
                    jx = tour[j - 1]
                    dist_matrix[i][j] = self.problem.dist_matrix[ix, jx]
                    s2: Slab = self.problem.get_slab(jx)
                    if s1.width == s2.width and s1.gauge == s2.gauge and s1.hardness == s2.hardness:
                        dist_matrix[i][j] = 10 * dist_matrix[i][j]
        data = {'distance_matrix': dist_matrix, 'num_vehicles': 1, 'depot': 0}
        return data

    # TODO the main procedure of PLS
    def execute(self):
        # 1. iterated search
        PS0 = copy.copy(self.EAP)
        t1 = time.time()
        self.iter = 1
        while True:
            if len(PS0) == 0:
                tmp_PS = []
                while len(tmp_PS) < self.P_size:
                    sel_soln = random.choice(self.sol_list)
                    tmp_tour = list(set(sel_soln.final_tour) - set(self.visited_idx))
                    n = random.randint(3, len(tmp_tour)-3)
                    new_tour = tmp_tour[n:] + tmp_tour[:n]
                    sol = Solution(self.problem, visited_idx=[i for i in self.visited_idx],
                                   to_visit_idx=[i for i in new_tour])
                    sol.evaluate_rui()
                    tmp_PS.append(sol)
            else:
                sel_soln = self.select_solution_hv(PS0)
                tmp_PS = self.local_search(sel_soln)
            sel_soln.explored = True
            for ps in tmp_PS:
                ps.explored = False
            self.update_archive(tmp_PS)
            PS0 = [xs for xs in self.EAP if not xs.explored]
            print(self.iter, '-size PS=', len(PS0), ': size EAP=', len(self.EAP))

            t2 = time.time()
            if t2 - t1 > self.tm_budget:
                break
            self.iter += 1
        # 3. return pareto solutions
        return

    def name(self):
        return 'DPLS'

    def select_neighborhood(self, t):
        if t < len(self.__bandits) * 3:
            b = t % 3 + 1
        else:
            b = max(self.__bandits.keys(), key=lambda x: self.__bandits[x].estimates + np.sqrt(
                2 * np.log(t) / (1 + self.__bandits[x].I)))
        return b

    def neighborhood1(self, xSoln: Solution):
        block_size1 = random.randint(2, 10)
        block_size2 = random.randint(2, 10)

        tmp_tour = list(set(xSoln.final_tour) - set(self.visited_idx))
        n = len(tmp_tour)
        # 随机选择第一个块的起始位置
        s1 = random.randint(0, n - block_size1)
        e1 = s1 + block_size1
        # 确保第二个块与第一个块不重叠
        s2 = random.randint(0, n - block_size2)
        while s2 < e1 and s2 + block_size2 > s1:
            s2 = random.randint(0, n - block_size2)
        e2 = s2 + block_size2
        # print(s1, e1, s2, e2)
        # 交换两个块
        if s2 < s1:
            s1, s2 = s2, s1
            e1, e2 = e2, e1
        new_tour = tmp_tour[:s1] + tmp_tour[s2:e2] + tmp_tour[e1:s2] + tmp_tour[s1:e1] + tmp_tour[e2:]
        # print(new_tour)
        new_sol = Solution(self.problem, visited_idx=[i for i in self.visited_idx],
                           to_visit_idx=[i for i in new_tour])
        new_sol.evaluate_rui()

        new_X = [new_sol.uncollected] + new_sol.subtours

        return new_X

    def neighborhood2(self, xSoln: Solution):
        old_X = [xSoln.uncollected] + xSoln.subtours
        uncols = [(s, self.problem.get_slab(s).width) for s in old_X[0]]
        uncols.sort(key=lambda x: x[1])
        old_X[0] = [x[0] for x in uncols]

        i1 = random.randint(0, len(old_X) - 1)
        i2 = random.randint(0, len(old_X) - 1)
        while i1 == i2:
            i2 = random.randint(0, len(old_X) - 1)
        jx = min(len(old_X[i1]), len(old_X[i2]))
        j1 = random.randint(0, jx - 4)
        j2 = random.randint(j1 + 1, jx)

        new_X: Solution = copy.deepcopy(old_X)
        for j in range(j1, j2):
            s1 = old_X[i1][j]
            s2 = old_X[i2][j]
            if s1 in self.visited_idx or s2 in self.visited_idx:
                continue
            new_X[i1][j] = s2
            new_X[i2][j] = s1

        return new_X

    def check_feasibility(self, sub_tours):
        for i in range(1, len(sub_tours)):
            tour = sub_tours[i]
            max_len = self.problem.round_list[i - 1].capacity
            min_len = self.problem.min_ratio_capacity * max_len
            tot_len = 0
            for j, s in enumerate(tour):
                slab: Slab = self.problem.get_slab(s)
                tot_len += slab.length
            if tot_len < min_len or tot_len > max_len:
                return False
        return True

    def select_solution_hv(self, PS):
        if len(PS) < 2:
            return PS[0]
        OHS = []
        PS.sort(key=lambda x: (x.objectives[0], -x.objectives[1]))
        for i, s in enumerate(PS):
            if i == 0:
                s_sup = None
            else:
                s_sup = PS[i - 1]
            if i == len(PS) - 1:
                s_inf = None
            else:
                s_inf = PS[i + 1]
            if s_inf is None:
                ohvc = 2 * (s.objectives[0] - s_sup.objectives[0]) * (s_sup.objectives[1] - s.objectives[1])
            elif s_sup is None:
                ohvc = 2 * (s_inf.objectives[0] - s.objectives[0]) * (s.objectives[1] - s_inf.objectives[1])
            else:
                ohvc_sup = (s.objectives[0] - s_sup.objectives[0]) * (s_sup.objectives[1] - s.objectives[1])
                ohvc_inf = (s_inf.objectives[0] - s.objectives[0]) * (s.objectives[1] - s_inf.objectives[1])
                ohvc = ohvc_inf + ohvc_sup
            OHS.append((i, ohvc))
        sorted(OHS, key=lambda ohs: ohs[1])
        return PS[OHS[-1][0]]

    def reroute_by_CP(self, tour):
        data = self.get_data_model(tour)
        # 创建路由索引管理器
        manager = pywrapcp.RoutingIndexManager(len(data['distance_matrix']), data['num_vehicles'], data['depot'])

        # 创建Routing Model
        routing = pywrapcp.RoutingModel(manager)

        def distance_callback(from_index, to_index):
            """返回两个节点之间的距离"""
            from_node = manager.IndexToNode(from_index)
            to_node = manager.IndexToNode(to_index)
            return data['distance_matrix'][from_node][to_node]

        transit_callback_index = routing.RegisterTransitCallback(distance_callback)
        # 设置成本函数
        routing.SetArcCostEvaluatorOfAllVehicles(transit_callback_index)
        # 设置搜索参数
        search_parameters = pywrapcp.DefaultRoutingSearchParameters()
        search_parameters.first_solution_strategy = routing_enums_pb2.FirstSolutionStrategy.PATH_CHEAPEST_ARC

        # 求解问题
        solution = routing.SolveWithParameters(search_parameters)

        if solution:
            index = routing.Start(0)
            route_distance = 0
            new_tour = []
            while not routing.IsEnd(index):
                previous_index = index
                index = solution.Value(routing.NextVar(index))
                x = manager.IndexToNode(index)
                if x != 0:
                    new_tour.append(tour[x - 1])
                route_distance += routing.GetArcCostForVehicle(previous_index, index, 0)
        else:
            print('No shortest path is found !')
            new_tour = tour

        return new_tour

    def local_search(self, xSoln: Solution):

        ps_pool = []
        # 1. inter_move 搜索
        for n in range(self.Qmax):
            if random.random() < 0.5:
                new_X = self.neighborhood1(xSoln)
            else:
                new_X = self.neighborhood2(xSoln)

            if not self.check_feasibility(new_X):
                continue
            for i in range(1, len(new_X)):
                fix_x = [s for s in self.visited_idx]
                new_x = [s for s in new_X[i] if s not in fix_x]
                x = self.reroute_by_CP(new_x)
                new_X[i] = fix_x + x
            tour = []
            for i in range(1, len(new_X)):
                tour.extend(new_X[i])
            tour.extend(new_X[0])
            to_visit = [s for s in tour if s not in self.visited_idx]
            temp_sol = Solution(self.problem, visited_idx=self.visited_idx,
                                to_visit_idx=to_visit)
            temp_sol.evaluate_rui()
            ps_pool.append(temp_sol)

        return ps_pool
