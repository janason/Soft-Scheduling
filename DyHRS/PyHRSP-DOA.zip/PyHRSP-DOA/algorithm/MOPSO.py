import random
import time

from model.entities import Problem
from model.solution import Solution
from algorithm.gMOO import gMOO


class MOPSO(gMOO):
    def __init__(self, problem: Problem, params):
        super().__init__(problem, params)
        self.x_list = []
        self.p_xs = []
        self.g_xs = []
        self.v = []
        self.Vmax = 0.5
        self.Vmin = -0.5
        self.w = 0.5
        self.c1 = 0.15
        self.c2 = 0.15
        self.LZ = 3
        self.GZ = 8

    def name(self):
        return 'MOPSO'

    def initialize(self):
        super().initialize(init_pop=True)
        self.x_list = []
        self.p_xs = []
        self.g_xs = []
        self.v = []
        for i in range(self.P_size):
            sol: Solution = self.sol_list[i]
            sol.evaluate_rui()
            N = len(sol.final_tour)
            x = [0] * N
            for j, s in enumerate(sol.final_tour):
                if s in self.visited_idx:
                    x[s - 1] = 0 - 10 / (j + 1)
                else:
                    x[s - 1] = (j + 1) / N
            self.x_list.append(x)
            self.p_xs.append([(x, sol)])
            self.v.append([self.Vmax] * N)

        fronts, ranks = self.fast_non_dominated_sorting(self.sol_list)
        sort_idx = self.calculate_crowding_distance(fronts, ranks)
        for i in sort_idx[0: self.GZ]:
            self.g_xs.append((self.x_list[i], self.sol_list[i]))
        self.update_archive(self.sol_list)
        print("epoch=", 0, " EAP size=", len(self.EAP))

        # self.pg = best_sol.slab_no_seq

    def update_position(self):
        w = self.w
        c1 = self.c1
        c2 = self.c2
        pg = self.g_xs[random.randint(0, self.GZ - 1)][0]

        g_x = []
        g_s = []
        for p in range(self.P_size):
            x = self.x_list[p]
            sol = self.sol_list[p]
            v = self.v[p]
            il = random.randint(0, len(self.p_xs[p]) - 1)
            pl = self.p_xs[p][il][0]
            r1 = random.random()
            r2 = random.random()
            new_v = []
            new_x = []
            for i in range(len(v)):
                if x[i] >= 0:
                    v_ = w * v[i] + c1 * r1 * (pl[i] - x[i]) + c2 * r2 * (pg[i] - x[i])
                    new_v.append(min(v_, self.Vmax))
                    new_x.append(max(x[i] + new_v[i], 0))
                else:
                    new_v.append(0)
                    new_x.append(x[i])
            new_sol: Solution = self.trans_x2sol(new_x)
            self.v[p] = new_v
            self.sol_list[p] = new_sol
            self.x_list[p] = new_x

            pareto_set = [(x, s) for (x, s) in self.p_xs[p] if not new_sol.dominate(s)]
            if not any(s.dominate(new_sol) for (x, s) in pareto_set):
                pareto_set.append((new_x, new_sol))
            if len(pareto_set) > self.LZ:
                self.p_xs[p] = random.sample(pareto_set, self.LZ)
            else:
                self.p_xs[p] = pareto_set

            for j in range(len(self.p_xs[p])):
                xx = self.p_xs[p][j]
                g_x.append(xx[0])
                g_s.append(xx[1])

        fronts, ranks = self.fast_non_dominated_sorting(g_s)
        sort_idx = self.calculate_crowding_distance(fronts, ranks, g_s)
        for i in sort_idx[0: self.GZ]:
            self.g_xs.append((g_x[i], g_s[i]))
        self.update_archive(self.sol_list)

    def trans_x2sol(self, x):
        sorted_x = sorted(enumerate(x), key=lambda x: x[1])
        seq = [i[0] + 1 for i in sorted_x if i[1] > 0]
        sol = Solution(self.problem, visited_idx=self.visited_idx, to_visit_idx=seq)
        sol.evaluate_rui()
        return sol

    def execute(self):
        t1 = time.perf_counter()
        self.iter = 1
        while True:
            self.update_position()
            self.update_ideal_distance()
            ants = []
            for sol in self.sol_list:
                sol.improve_quality(resort=False, swap=True)
                ants.append(sol)
            self.update_archive(ants)
            print("epoch=", self.iter + 1, " EAP size=", len(self.EAP))
            self.iter += 1
            t2 = time.perf_counter()
            if t2 - t1 > self.tm_budget:
                break

        t2 = time.perf_counter()
        print(f'cost= {t2 - t1:.8f}s')
