import time
import numpy as np

from algorithm import MPMOAS
from algorithm.utils.transfer import Transfer
from model.solution import *
from algorithm.gMOO import gMOO
from model.entities import *
import itertools


# Jia S J, Yi J, Yang G K, et al. A multi-objective optimisation algorithm for the hot rolling batch scheduling
# problem[J]. International Journal of Production Research, 2013, 51(3): 667-681.

class PMMAS(gMOO):
    def __init__(self, problem, param_dict):
        super().__init__(problem, param_dict)
        self.alpha = param_dict['alpha']
        self.beta = param_dict['beta']
        self.rho = param_dict['rho']
        self.prev_visit_list = []

        self.Q = 0.9
        self.Tau1 = {}  # 信息素
        self.Tau2 = {}  # 信息素
        self.eta = {}  # 启发因子

        self.tau1_min = math.inf
        self.tau1_max = -math.inf

        self.tau2_min = math.inf
        self.tau2_max = -math.inf

        print('initialization')

    def name(self):
        return "PMMAS"

    def initialize(self):
        super().initialize()
        visiting_list = self.visited_idx + self.to_visit_idx
        # initialize Tau & eta
        for i, j in itertools.product([0] + visiting_list, visiting_list):
            if i == j:
                continue
            self.Tau1[i, j] = 1.0
            self.Tau2[i, j] = 1.0
            self.eta[i, j] = self.problem.prize_dict[j] / (self.problem.dist_matrix[i, j] + 1)

        # initialize eta and tau
        if self.problem.t > 0:
            trans1 = Transfer(self.problem, self.Tau1, self.C)
            trans1.node_learning(self.prev_visit_list)
            trans1.update_tau(self.to_visit_idx + self.visited_idx, self.Tau1, self.tau1_min, self.tau1_max)

            trans2 = Transfer(self.problem, self.Tau2, self.C)
            trans2.node_learning(self.prev_visit_list)
            trans2.update_tau(self.to_visit_idx + self.visited_idx, self.Tau2, self.tau2_min, self.tau2_max)

        self.prev_visit_list = self.visited_idx + self.to_visit_idx

    def selectFirstNode(self, SE_List):
        to_select = []
        for i, node_no in enumerate(SE_List):
            slab: Slab = self.problem.get_slab(node_no)
            to_select.append((node_no, slab.width))
        to_select.sort(key=lambda x: x[1], reverse=True)
        next_node_no = to_select[0][0]
        return next_node_no

    # def selectNextNode(self, lw, LW, current_node_no, SE_List):
    def selectNextNode(self, current_node_no, SE_List, dyn_constr, lamda, eta):  # lw, LW, current_node_no, SE_List):
        # 获得可选列表
        candidates = list(set(self.allow_list[current_node_no]).intersection(set(SE_List)))
        sel_list = []
        # 同宽约束
        for id in candidates:
            salb: Slab = self.problem.get_slab(id)
            if dyn_constr[0][0] + salb.length <= dyn_constr[0][1] \
                    and dyn_constr[1][0] - salb.length > dyn_constr[1][1]:
                sel_list.append(id)
        if len(sel_list) == 0:
            return -1
        prob = np.zeros(len(sel_list))
        for i, next_node_no in enumerate(sel_list):
            eta0 = eta[current_node_no, next_node_no]
            tau1 = self.Tau1[current_node_no, next_node_no]
            tau2 = self.Tau2[current_node_no, next_node_no]
            a1 = lamda * self.alpha
            a2 = (1 - lamda) * self.alpha
            prob[i] = (tau1 ** a1) * (tau2 ** a2) * (eta0 ** self.beta)
        # use Roulette to determine the next node
        cumsumprob = (prob / sum(prob)).cumsum()
        cumsumprob -= np.random.rand()
        next_node_no = sel_list[list(cumsumprob >= 0).index(True)]
        return next_node_no

    def update_Tau(self, Tau, g):
        for i, j in Tau.keys():
            tau = (1 - self.rho) * Tau[i, j]
            f_best = math.inf
            d_tau = 0
            for sol in self.EAP:
                if sol.is_exist_path(i, j):
                    d_tau = len(sol.subtours) / sol.objectives[g]
                if sol.objectives[g] < f_best:
                    f_best = sol.objectives[g]
            tau += d_tau
            _tau_max = 1 / self.rho * self.problem.round_number / f_best
            if tau > _tau_max:
                tau = _tau_max
            _tau_min = _tau_max / 5
            if tau < _tau_min:
                tau = _tau_min
            Tau[i, j] = tau
        return _tau_min, _tau_max

    def execute(self):
        t1 = time.perf_counter()
        self.iter = 1
        while True:
            # solution construction and update external archive population
            ants = []
            for k in range(self.P_size):
                lamda = k / (self.P_size - 1)
                sol = Solution(self.problem, visited_idx=self.visited_idx, to_visit_idx=self.to_visit_idx)
                sol.evaluate_aco(self.selectFirstNode, self.selectNextNode, lamda, self.eta)
                sol.improve_quality(resort=False, swap=True)
                ants.append(sol)
            # update external archive
            self.update_archive(ants)
            self.update_ideal_distance()
            # update Pheromone matrices
            self.tau1_min, self.tau1_max = self.update_Tau(self.Tau1, 0)
            self.tau2_min, self.tau2_max = self.update_Tau(self.Tau2,  1)
            self.sol_list = [ant for ant in ants]
            print("%s/%s， size of EAP: %s" % (self.iter, self.M_iter, len(self.EAP)))
            self.iter = self.iter + 1
            t2 = time.perf_counter()
            if t2 - t1 > self.tm_budget:
                break
        t2 = time.perf_counter()
        print(f'tm cost= {t2 - t1:.8f}s')
