import copy
import math

from HRMS.model.entities import Problem, Slab

OBJ_CNT = 1


class Solution:

    def __init__(self, problem: Problem, nodes=[], fixed_idx=[]):
        self._ant_tour = nodes
        self._capacity = [rod.capacity for rod in problem.round_list]
        self._subtours = [([], []) for rod in problem.round_list]
        self._objectives = [float('inf') for i in range(OBJ_CNT)]
        self._fixed_idx = fixed_idx
        self._problem = problem
        self._remain_idx = []
        self._visited = []
        self._unvisited = []
        self._rounds = []
        self._is_feasible = True
        return

    def is_exist_path(self, from_node, to_node):
        for tour in self._subtours:
            if tour.count(from_node) > 0:
                i = tour.index(from_node)
                if i < len(tour) - 1:
                    if tour[i + 1] == to_node:
                        return True
        return False

    @property
    def objectives(self):
        return self._objectives

    @objectives.setter
    def objectives(self, value):
        self._objectives = value

    @property
    def ant_tour(self):
        return self._ant_tour

    @property
    def capacity(self):
        return self._capacity

    @property
    def subtours(self):
        return self._subtours

    @ant_tour.setter
    def ant_tour(self, value):
        self._ant_tour = value

    @property
    def is_feasible(self):
        return self._is_feasible

    @is_feasible.setter
    def is_feasible(self, value):
        self._is_feasible = value

    @property
    def visited(self):
        return self._visited

    @visited.setter
    def visited(self, value):
        self._visited = value

    @property
    def unvisited(self):
        return self._unvisited

    @unvisited.setter
    def unvisited(self, value):
        self._unvisited = value

    @property
    def rounds(self):
        return self._rounds

    @rounds.setter
    def rounds(self, value):
        self._rounds = value

    def reset(self):
        for A in self._subtours:
            A.clear()
        self._objectives = (float('inf') for i in range(OBJ_CNT))
        return

    def evaluate(self):
        self.reset()
        if len(self._ant_tour) == 0:
            return math.inf
        seqs = copy.copy(self._ant_tour)
        travel_dist = 0.0
        is_feasible = True
        for k in range(len(self._subtours)):
            tour = self._subtours[k]
            remain = self._capacity[k]
            prev_node = 0
            len_same_width = 0
            current_width = 0
            prev_slab: Slab = None
            while remain >= 0:
                curr_node = seqs[0]
                curr_slab: Slab = self._problem.get_slab(curr_node)
                if prev_slab is not None:
                    if curr_slab.width != prev_slab.width and curr_slab.hardness != prev_slab.hardness \
                            and curr_slab.gauge != prev_slab.gauge:
                        is_feasible = False
                    if curr_slab.width == prev_slab.width:
                        is_feasible = False
                if remain - self._problem.dmd_dict[curr_node] < 0:
                    break
                travel_dist += self._problem.dist_matrix[(prev_node, curr_node)]
                remain = remain - self._problem.dmd_dict[curr_node]
                tour.append(curr_node)
                prev_node = curr_node
                seqs.pop(0)
        loss = 0
        for node in seqs:
            loss += self._problem.prize_dict[node]
        if is_feasible:
            self._objectives = [travel_dist, loss]
        else:
            self._objectives = [travel_dist * 100, loss * 100]

    def evaluate_aco(self, select_first_node, select_next_node, tau=None, eta=None):
        self._ant_tour = []
        candidates = [s.idx for s in self._problem.released_slabs]
        travel_cost = 0.0
        n = 0
        infeasible = False
        for r, tour in enumerate(self._subtours):
            remain = self._capacity[r]
            LW_limit = self._capacity[r] * self._problem.max_ratio_same_width
            lw_cumul = 0
            prev_node = 0
            prev_width = -1
            tour_len = 0
            while remain > 0:
                if n < len(self._fixed_idx):  # 选择已固定的板坯
                    node = self._fixed_idx[n]
                    slab: Slab = self._problem.get_slab(node)
                    if lw_cumul + slab.length > LW_limit:
                        node = -1
                else:
                    if prev_node > 0:
                        dyn_constr = [(lw_cumul, LW_limit), (remain, 0)]
                        node = select_next_node(prev_node, candidates, dyn_constr, tau, eta)  # next slab
                    else:
                        node = select_first_node(candidates)
                if node < 0:  # 没有选到
                    break
                slab: Slab = self._problem.get_slab(node)
                if remain - slab.length < 0:  # 选中的不符合条件
                    break
                remain = remain - slab.length
                tour[1].append(node)
                candidates.remove(node)
                self._ant_tour.append(node)
                # print(remain)

                # 计算目标函数
                travel_cost += self._problem.dist_matrix[(prev_node, node)]
                if prev_width == slab.width:
                    lw_cumul += slab.length
                else:
                    lw_cumul = slab.length
                tour_len += slab.length
                prev_width = slab.width
                prev_node = node
                n = n + 1
            if tour_len < 0.8 * self._capacity[r]:
                infeasible = True

        prize_loss = 0.0
        for node in candidates:
            self._ant_tour.append(node)
            prize_loss += self._problem.prize_dict[node]

        if infeasible:
            self._objectives = travel_cost * 10, prize_loss * 10
        else:
            self._objectives = travel_cost, prize_loss
        return

    def evaluate_rui(self):
        self.reset()
        seqs = copy.copy(self._ant_tour)
        travel_dist = 0.0
        for k in range(len(self._subtours)):
            tour = self._subtours[k]
            remain = self._capacity[k]
            l_w = {}
            fixed_len = 0
            max_width = 10000
            while remain >= 0:
                node = seqs[0]
                slab: Slab = self._problem.get_slab(node)
                if remain - slab.length < 0:  # 总长度限制
                    break
                if slab.width in l_w.keys():  # 同宽长度限制
                    if l_w[slab.width] + slab.length > self._capacity[k] * self._problem.max_ratio_same_width:
                        break
                if slab.status == 2:  # 如果是已锁定的板坯，那就直接放在最后面
                    tour.append(node)
                    fixed_len += 1
                    max_width = slab.width
                else:
                    prev_pos = -1
                    for prev_node in reversed(tour):
                        prev_slab = self._problem.get_slab(prev_node)
                        if slab.width <= prev_slab.width:
                            prev_pos = tour.index(prev_node)
                            break
                        else:
                            prev_pos = -1
                    if len(tour) > 0 and prev_pos + 1 < len(tour):  # 判断找到位置是否符合要求
                        next_slab = self._problem.get_slab(tour[prev_pos + 1])
                        if next_slab.status == 2 or next_slab.width > slab.width:
                            break
                    tour.insert(prev_pos + 1, node)

                if slab.width in l_w.keys():
                    l_w[slab.width] += slab.length
                else:
                    l_w[slab.width] = slab.length
                remain = remain - self._problem.dmd_dict[node]
                seqs.pop(0)
                print(remain)

            # 计算累计距离
            prev_node = 0
            for node in tour:
                slab: Slab = self._problem.get_slab(node)
                travel_dist += self._problem.dist_matrix[(prev_node, node)]
                prev_node = node

        # 计算损失
        loss = 0
        for node in seqs:
            loss += self._problem.prize_dict[node]
        # 重构排列
        new_seqs = []
        for tour in self._subtours:
            new_seqs.extend(tour)
        new_seqs.extend(seqs)
        self.node_seq = new_seqs
        self._objectives = [travel_dist, loss]

    def dominate(self, other):
        nlt = 0
        for i, obj in enumerate(self._objectives):
            if obj < other.objectives[i]:
                nlt = nlt + 1
            if obj > other.objectives[i]:
                return False
        if nlt != 0:
            return True
        return False

    def __lt__(self, other):
        nlt = 0
        for i, obj in enumerate(self._objectives):
            if obj < other.objectives[i]:
                nlt = nlt + 1
            if obj > other.objectives[i]:
                return False
        if nlt != 0:
            return True
        return False

    def add_warmup(self):
        # for tours in self._subtours:
        #     self._visited += tours[1]
        # self._unvisited = list(set(self._ant_tour) - set(self._visited))
        for tours in self._subtours:
            tour = tours[1]
            warm_up = tours[0]
            s = tour[0]
            for i in range(3):
                dis_list = [[d, self._problem.r_dist_matrix[s, d]] for d in self._unvisited]
                dis_list.sort(key=lambda x: x[1])
                s = dis_list[i][0]
                warm_up.insert(0, s)
                self._unvisited.remove(s)
        self._visited = []
        for r, tours in enumerate(self._subtours):
            self._visited += tours[0] + tours[1]
        return
