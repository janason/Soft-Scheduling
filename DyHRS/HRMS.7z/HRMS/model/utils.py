import math
from random import random
import numpy as np
import pandas as pd
from matplotlib import pyplot as plt
import matplotlib as mpl

from HRMS.model import const
from HRMS.model.entities import *


def generate_to_file(name):
    t_slabs = []
    for i in range(const.N):
        rnd = max(min(np.random.normal(0, 1), 1), 0)
        W = int(const.min_width + (const.max_width - const.min_width) * rnd)
        rnd = np.random.random()
        G = int(const.min_gauge + (const.max_gauge - const.min_gauge) * rnd)
        rnd = np.random.random()
        H = int(const.min_hardn + (const.max_hardn - const.min_hardn) * rnd)
        rnd = np.random.random()
        L = int(const.min_leng + (const.max_leng - const.min_leng) * rnd)
        P = math.floor(np.random.uniform(1, 10) * 10) / 10
        t = 0
        slab = Slab(i + 1, W, G, H, L, P)
        t_slabs.append((t, slab))
    n = const.N
    for e in range(1, const.E + 1):
        t = random.randint(e * 15, (e + 1) * 15 - 1)
        N = random.randint(5, 15)
        for i in range(N):
            rnd = max(min(np.random.normal(0, 1), 1), 0)
            W = int(const.min_width + (const.max_width - const.min_width) * rnd)
            rnd = np.random.random()
            G = int(const.min_gauge + (const.max_gauge - const.min_gauge) * rnd)
            rnd = np.random.random()
            H = int(const.min_hardn + (const.max_hardn - const.min_hardn) * rnd)
            rnd = np.random.random()
            L = int(const.min_leng + (const.max_leng - const.min_leng) * rnd)
            P = math.floor(np.random.uniform(1, 10) * 10) / 10
            n = n + 1
            slab = Slab(n, W, G, H, L, P)
            t_slabs.append((t, slab))
    rounds = []
    for i in range(const.K):
        rund = Round(i + 1, const.C, const.U)
        rounds.append(rund)

    file_path = '..//data//' + name + '.txt'

    with open(file_path, 'w') as f:
        f.write('[VEHICLE]\n')
        text = '{0} {1}\n'.format(const.K, const.C)
        f.write(text)
        f.write('V\tC\tU \n')
        for round in rounds:
            text = '{0}\t{1}\t{2} \n'.format(round.idx, round.capacity, round.limits)
            f.write(text)

        f.write('[CUSTOMER]\n')
        f.write('T\tid\tW\tG\tH\tL\tP \n')
        slabs = []
        w_slabs = []
        T = []
        for t, c in t_slabs:
            if t == 0:
                slabs.append(c)
            else:
                w_slabs.append((t, c))
                if t not in T:
                    T.append(t)
            text = '{0}\t{1}\t{2}\t{3}\t{4}\t{5}\t{6} \n'.format(t, c.idx, c.width, c.gauge, c.hardness, c.length,
                                                                 c.price)
            f.write(text)
        problem = Problem(name, slabs, rounds, T)
        problem.T = T
        problem.waiting_list = w_slabs

    return problem


# --------------------- get a test instance from the file -------------------
def read_from_file(name):
    file_path = '../data/' + name + '.txt'
    slabs = []
    rounds = []
    slabs = []
    T = []
    with open(file_path, 'r') as f:
        lines = f.readlines()
        txt = lines[1].split()
        round_number = int(txt[0])
        for r in range(len(lines)):
            x = lines[r].split()
            if r in range(3, round_number + 3):
                print(x)
                round = Round(int(x[0]), int(x[1]), int(x[2]))
                rounds.append(round)
            if r > 4 + round_number:
                t = int(x[0])
                client = Slab(int(x[1]), float(x[2]), float(x[3]), float(x[4]), float(x[5]), float(x[6]))
                client.release_time = t
                slabs.append(client)
                if t not in T:
                    T.append(t)
        problem = Problem(name, slabs, rounds, T)

    return problem


# draw the graph of the final init_solution
def plot_rolling_solution(solution):
    colors = mpl.cm.Dark2.colors
    font = {'family': 'serif',
            'color': 'white',
            'weight': 'bold',
            'size': 9,
            }
    for k in range(0, len(solution.rounds)):
        vehicle_id = solution.rounds[k][0].idx
        x = []
        y = []
        c = []
        txt = []
        for l in range(1, len(solution.rounds[k])):
            node = solution.rounds[k][l]
            x.append(node.idx)
            y.append(node.width)
            c.append(colors[0])
            txt.append("{0} [{1}-{2}]".format(node.start_time, node.ready_time, node.dead_time))
        fig, ax = plt.subplots(figsize=(20, 15))
        # plt.figure()
        ax.set_title('Vehicle-{0}'.format(vehicle_id))
        rects = ax.barh(range(len(x)), y, color=c)
        for lbl in ax.get_xticklabels():
            lbl.set_picker(True)
        for i in range(0, len(rects)):
            rect = rects[i]
            width = rect.get_width()
            height = rect.get_height()
            ax.text(width / 2, rect.get_y() + height / 2, txt[i], ha='center', va='center', fontdict=font)
    # plt.xticks(range(len(x)), x)
    plt.show()


def read_from_excel(file_name, no):
    df = pd.read_excel(file_name, sheet_name=no)
    print(df)

    rounds = []
    round_number = 2
    for r in range(round_number):
        round = Round(r + 1, 4200, 3)
        rounds.append(round)

    slabs = []
    for index, row in df.iterrows():
        slab = Slab(idx=int(row['slab_id']), w=float(row['slab_wid']), g=float(row['slab_thk']),
                    h=float(row['slab_hdn']), l=float(row['slab_len']) / 100)
        slab.Temp = float(row['slab_temp'])

        slab.weight = float(row['slab_wgh'])
        slab.pt_in_server = int(row['roll_time']) * 2 + 1
        slab.pt_in_queue = int(row['heat_time']) - 30

        slabs.append(slab)

    problem = Problem(no, slabs, rounds, [0])

    return problem
