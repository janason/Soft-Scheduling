from collections import deque

class Slab:
    def __init__(self, idx, w, g, h, l, p=1.0):
        self.idx = idx
        self.width = w
        self.gauge = g
        self.hardness = h
        self.length = l
        self.price = p
        self.release_time = 0
        self.Temp = 0
        self.weight = 0

        self.round = None
        self.status = 0  # 0: releasing, 1: heating, 2: in_waiting, 3: rolled

    def __repr__(self):
        return f"S_{self.idx}"

    def reset(self):
        pass


    # cost function
    def distance(self, target):
        if self.width <= 0 or target.width <= 0:
            return 0
        if self.width >= target.width:
            # dist = abs(self.width - target.width) / 1 * 0.3 + abs(self.gauge - target.gauge) / 1 * 0.7 + \
            #        abs(self.hardness - target.hardness) * 10
            dist = abs(self.width - target.width) / 1 * 2.0 + abs(self.gauge - target.gauge) / 1 * 2.0 + \
                        abs(self.hardness - target.hardness) * 4.0
        else:
            dist = 100 * abs(target.width - self.width)

        if self.width <= target.width:
            r_dist = target.width - self.width
        else:
            r_dist = 100 * abs(target.width - self.width)

        return dist, r_dist

    def jump_count(self, target):
        cnt = 0
        if self.width != target.width:
            cnt += 1
        if self.gauge != target.gauge:
            cnt += 1
        if self.hardness != target.hardness:
            cnt += 1
        if self.Temp != target.Temp:
            cnt += 1
        return cnt


# a rolling unit
class Round:
    def __init__(self, number, capacity, limits):
        self.idx = number  # 编号
        self.capacity = capacity  # 能力 = 等价于最大轧制公里数
        self.limits = limits  # 跳变次数限制
        self.slab_list = []
        self.lens_wid = {}  # cumulative length of the same width

    def reset(self):
        self.lens_wid = {}  # cumulative length of the same width
        for s in self.slab_list:
            s.reset()
        self.slab_list = []

    def __repr__(self):
        return f"V_{self.idx}"


class FQueue:
    __slots__ = ('id', 'status', 'capacity', 'available_time', 'doing_list', 'done_list')

    def __init__(self, id, capacity):
        self.id = id
        self.status = 0  # 0：空闲；1：能力已满
        self.capacity = capacity
        self.available_time = 0  # 可用时间，板坯可以进入的时间
        self.doing_list = deque()

    def reset(self):
        self.status = 0  # 0：空闲；1：能力已满
        self.available_time = 0  # 释放时间，最末板坯出炉时间
        self.doing_list.clear()


class RServer:
    __slots__ = ('id', 'status', 'available_time', 'slab')

    def __init__(self, id):
        self.id = id
        self.status = 0  # 0-idle ；1-busy
        self.available_time = 0  # 释放时间，最末板坯出炉时间
        self.slab = None

    def reset(self):
        self.status = 0  # 0-idle ；1-busy
        self.available_time = 0  # 释放时间，最末板坯出炉时间
        self.slab = None


class Problem:

    def __init__(self, name, slabs: list, rounds: list, T: list):
        self.t = 0
        self.T = T
        self.past = 0
        self.name = name
        self.all_slabs = {s.idx: s for s in slabs}
        self.released_slabs = []

        self.fixed_slabs = []
        self.round_list = rounds
        self.round_number = len(rounds)
        self.slab_number = len(slabs)
        self.max_ratio_same_width = 0.5  # 同宽比例限制
        self.min_ratio_capacity = 0.8  # 最小容量
        self.jump_limits = 3  # 同时跳变限制

        self.dmd_dict = {s.idx: s.length for s in slabs}
        self.prize_dict = {s.idx: s.price for s in slabs}
        self.dist_matrix = {}
        self.r_dist_matrix = {}
        self.round_states = []  # starting 和 remain
        for s1 in slabs:
            for s2 in slabs:
                if s1 is s2:
                    continue
                dist = s1.distance(s2)
                self.dist_matrix[s1.idx, s2.idx] = dist[0]
                self.r_dist_matrix[s1.idx, s2.idx] = dist[1]
            self.dist_matrix[0, s1.idx] = 0
        return

    def __repr__(self):
        return f"Instance: {self.name}\n" \
               f"Vehicle number: {self.round_number}\n"

    def get_slab(self, idx):
        return self.all_slabs[idx]

    def update(self, t):
        # release orders
        s_list = [s for s in self.all_slabs.values() if s.release_time == t]
        for s in s_list:
            s.status = 1
            self.released_slabs.append(s)
        if t > 0:
            self.past += len(s_list)
        for i in range(self.past):
            self.fixed_slabs[i].status = 2  # fixed
        self.fixed_slabs = [s for s in self.fixed_slabs if s.status == 2]
        # update states
        for rond in self.round_list:
            rond.reset()

        if t in self.T:
            self.T.remove(t)
        self.t = t
