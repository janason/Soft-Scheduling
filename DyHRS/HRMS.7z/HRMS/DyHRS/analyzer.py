import math
import os

import numpy as np
import openpyxl
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import statsmodels.api as sm
from pymoo.factory import get_performance_indicator
from statsmodels.formula.api import ols
from statsmodels.stats.multicomp import MultiComparison
import matplotlib as mpl
from mpl_toolkits.mplot3d import Axes3D
import numpy as np
import matplotlib.pyplot as plt
from scipy import stats
import csv
from openpyxl import load_workbook

from HRMS.algorithm.population.indicators import hv_indicator, sp_indicator, get_pareto_front, sr_indicator


def ANOVA(df, key, x_tick=[]):

    sns.set(style='darkgrid')
    # mpl.rcParams['font.sans-serif'] = ['SimHei']
    sns.set(font_scale=1)
    plt.figure(figsize=(4.5, 6.0))

    df_melt = pd.melt(df.reset_index(), id_vars=['index'])
    df_melt.columns = ['index', 'Algorithms', key]

    model = ols(key+ ' ~ C(Algorithms)', data=df_melt).fit()
    anova_table = sm.stats.anova_lm(model, typ=1)
    print(anova_table)


    # mc = MultiComparison(df_melt[key], df_melt['Levels'])
    # tukey_result = mc.tukeyhsd(alpha=0.05)
    # print(tukey_result)

    sns.boxplot(x='Algorithms', y=key, data=df_melt,  width=0.40,
                fliersize=2, linewidth=1)
    sns.swarmplot(x='Algorithms', y=key, data=df_melt)
    plt.xticks(range(5),x_tick)
    # plt.set_xlabel('(' + chr(97 + i) + ')', y=-0.28, fontsize=12)
    # plt.set_ylabel(key, fontsize=12)
    plt.tick_params(labelsize=11)

    plt.show()


def plot_data_curve(df):
    plt.figure(figsize=(6, 3.2))
    # sns.set_theme(style="darkgrid")
    sns.lineplot(data=df, x="iter", y="hv1", marker="o", markersize=6, dashes=False, label='I-greedy', lw=1)
    sns.lineplot(data=df, x="iter", y="hv2", marker="o", linestyle='--', markersize=6, dashes=True, label='I-random',
                 lw=1)
    sns.lineplot(data=df, x="iter", y="hv3", marker="s", markersize=6, dashes=False, label='II-greedy', lw=1)
    sns.lineplot(data=df, x="iter", y="hv4", marker="s", linestyle='--', markersize=6, dashes=True, label='II-random',
                 lw=1)
    plt.legend(prop={'size': 10.5})
    # plt.tick_params(labelsize=10.5)
    plt.tick_params(axis='both', which='major', labelsize=10.5, pad=0)
    plt.xlabel("iteration", fontsize=11, labelpad=0)
    plt.ylabel("hypervolume", fontsize=11, labelpad=0)
    plt.show()


def cal_mo_metric(file_name, algos, data):
    T = data['mACOq'][0].unique()
    hv_list = {a: [] for a in algos}
    sp_list = {a: [] for a in algos}
    sr_list = {a: [] for a in algos}
    for t in T:
        z_max = [1e0, 1e0]
        z_min = [1e4, 1e4]
        Z_obj = []
        for algo, dfx in data.items():
            df = dfx[dfx[0] == t]
            min_vals = df.min()
            max_vals = df.max()

            if max_vals[1] > z_max[0]:
                z_max[0] = max_vals[1]
            if max_vals[2] > z_max[1]:
                z_max[1] = max_vals[2]

            if min_vals[1] < z_min[0]:
                z_min[0] = min_vals[1]
            if min_vals[2] < z_min[1]:
                z_min[1] = min_vals[2]

            z_obj = df[[1, 2]].values.tolist()
            Z_obj.extend(z_obj)
        pf = get_pareto_front(Z_obj)
        for algo, dfy in data.items():
            df = dfy[dfy[0] == t]
            z_obj = dfy[[1, 2]].to_numpy()
            _range = np.array(z_max) - np.array(z_min)
            z_norm = (z_obj - z_min) / _range
            hv = hv_indicator(z_obj=z_obj, n_obj=2, max_pt=z_max, min_pt=z_min, ref_pt=[1.0, 1.0])
            hv_list[algo].append(hv)
            sp = sp_indicator(solution=z_norm)
            sp_list[algo].append(sp)
            sr = sr_indicator(z_obj, pf)
            sr_list[algo].append(sr)

    df_hv = pd.DataFrame(hv_list)
    df_sp = pd.DataFrame(sp_list)
    df_sr = pd.DataFrame(sr_list)
    print('#####  hv:')
    print(df_hv.mean())
    print('#####  sp:')
    print(df_sp.mean())
    print('#####  sr:')
    print(df_sr.mean())

    with open('reslut/hv.txt', "a") as file:  # 只需要将之前的”w"改为“a"即可，代表追加内容
        hvx = df_hv.mean().values.tolist()
        str = file_name + '\t'
        for i in range(len(hvx)):
            str += f'{hvx[i]:.4f}' + '\t'
        file.write(str + '\n')

    with open('reslut/sp.txt', "a") as file:  # 只需要将之前的”w"改为“a"即可，代表追加内容
        spx = df_sp.mean().values.tolist()
        str = file_name + '\t'
        for i in range(len(spx)):
            str += f'{spx[i]:.4f}' + '\t'
        file.write(str + '\n')

    with open('reslut/sr.txt', "a") as file:  # 只需要将之前的”w"改为“a"即可，代表追加内容
        srx = df_sr.mean().values.tolist()
        str = file_name + '\t'
        for i in range(len(srx)):
            str += f'{srx[i]:.4f}' + '\t'
        file.write(str + '\n')

def plot_real_case():
    df = pd.read_excel(io='real_case.xlsx', sheet_name='mACOq2')
    sns.set_theme(style="white")
    sns.relplot(x="f1", y="f2", hue="t", style="t", s=100, sizes=(60, 60), palette="muted",
                height=5, data=df)
    plt.show()
    max_f = [1e0, 1e0]
    min_f = [1e4, 1e4]

    for i in range(4):
        dfi = pd.read_excel(io='real_case_log.xlsx', sheet_name='log-'+str(i))
        min_f1 = dfi[['f1']].min().values[0]
        max_f1 = dfi[['f1']].max().values[0]
        min_f2 = dfi[['f2']].min().values[0]
        max_f2 = dfi[['f2']].max().values[0]
        if min_f1 < min_f[0]:
            min_f[0] = min_f1
        if min_f2 < min_f[1]:
            min_f[1] = min_f2
        if max_f1 > max_f[0]:
            max_f[0] = max_f1
        if max_f2 > max_f[1]:
            max_f[1] = max_f2
        print(max_f, min_f)
    dist_over_time = []
    for i in range(4):
        dfi = pd.read_excel(io='real_case_log.xlsx', sheet_name='log-'+str(i))
        f_val = dfi[['f1', 'f2']].to_numpy()
        p_val = dfi[['p']].to_numpy().tolist()
        _range = np.array(max_f) - np.array(min_f)
        f_norm = (f_val - min_f) / _range
        np_dist = np.sum(f_norm, axis=1).T

        np_array = np.vstack((np.array([p[0] for p in p_val]), np_dist))
        df_dist = pd.DataFrame(np_array.T, columns = ['p','d'])
        means = df_dist.groupby('p').min()
        dist_over_time.append(means)
        print(means)

    fig, ax1 = plt.subplots()
    sns.lineplot(data=dist_over_time[0], x='p', y='d', marker="o", markersize=5, color='k', label='t=0', lw=0.8, ax=ax1)
    ax1.legend(loc=2)
    ax2 = ax1.twinx()
    sns.lineplot(data=dist_over_time[1], x='p', y='d', marker="s", markersize=5, label='t=1', lw=0.8, ax=ax2)
    sns.lineplot(data=dist_over_time[2], x='p', y='d', marker="v", markersize=5, label='t=2', lw=0.8, ax=ax2)
    sns.lineplot(data=dist_over_time[3], x='p', y='d', marker="d", markersize=5, label='t=3', lw=0.8,
                 ax=ax2)
    ax2.legend(loc=0)
    ax1.set_xlabel("Iterations")
    ax1.set_ylabel("Minimum distance (t=0)")
    ax2.set_ylabel("Minimum distance (t>0)")
    plt.show()




if __name__ == "__main__":
    # load data1 file
    # for i in range(1, 31):
    #     file_name = 'data_' + str(i)
    #     print('---------------' +  file_name + '-------------------')
    #     sheet_name = ['mACOq', 'mACOp', 'mACSp', 'NSGA-II', 'mPSO']
    #     data = {}
    #     for i in range(len(sheet_name)):
    #         df = pd.read_excel(io=file_name + '.xlsx', sheet_name=sheet_name[i])
    #         data[sheet_name[i]] = df
    #     cal_mo_metric(file_name, sheet_name, data)
    # df = pd.read_excel(io='anova.xlsx', sheet_name='hv')
    # ANOVA(df, 'MHV', x_tick=['mACO/OL','P-ACO', 'P-MMAS','NSGA-II','MOPSO'])
    plot_real_case()
