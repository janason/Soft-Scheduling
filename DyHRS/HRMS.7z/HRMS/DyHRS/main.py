import matplotlib as mpl
import os

import openpyxl
import seaborn as sns
from matplotlib import pyplot as plt

from HRMS.algorithm.population.ACO import *
from HRMS.algorithm.population.mACOd import *
from HRMS.algorithm.population.mACOq import mACOq
from HRMS.algorithm.population.mACOp import mACOp

from HRMS.model import const
from HRMS.model.utils import read_from_file, generate_to_file

const.K = 6
const.M = 35
const.N = const.K * const.M
const.C = 800
const.U = 10  # 跳变次数
const.E = const.K - 1  # 动态事件次数
const.min_width = 6
const.max_width = 15
const.min_gauge = 1
const.max_gauge = 5
const.min_hardn = 1
const.max_hardn = 5
const.min_leng = 20
const.max_leng = 40


# randomly generate new instance

def main():
    is_new_instance: bool = False
    # -------------------------1. read or generate instance---------------------
    if is_new_instance:
        file_num = len([lists for lists in os.listdir('../data//')
                        if os.path.isfile(os.path.join('../data//', lists))])  # 获取文件数量
        file_name = 'data_' + str(file_num + 1)
        problem = generate_to_file(file_name)
        return
    else:
        file_name = 'data_1'
        problem = read_from_file(file_name)
    # --------------------------2. run optimization individual------------------------
    data = {}
    problem.update(0)
    algo = mACOp(problem, popsize=20, epochs=10)
    algo.initialize()
    algo.execute()
    algo.output()
    pf = np.array(algo.frontier)
    tm = np.array([problem.t] * len(algo.frontier))
    PF = np.insert(pf, 0, values=tm, axis=1)
    data[0] = algo.ideal_distance
    while len(problem.T) > 0:
        t = problem.T[0]
        problem.update(problem.T[0])
        algo.initialize()
        algo.execute()
        algo.output()
        pf = np.array(algo.frontier)
        tm = np.array([problem.t] * len(algo.frontier))
        pft = np.insert(pf, 0, values=tm, axis=1)
        PF = np.append(PF, pft, axis=0)
        data[t] = algo.ideal_distance

    if os.path.exists(file_name + '.xlsx'):
        wb = openpyxl.load_workbook(file_name + '.xlsx')
        writer = pd.ExcelWriter(file_name + '.xlsx', engine='openpyxl')
        writer.book = wb
    else:
        writer = pd.ExcelWriter(file_name + '.xlsx', engine='openpyxl')

    df_PF = pd.DataFrame(PF)
    df_PF.to_excel(excel_writer=writer, sheet_name=algo.name())
    writer.save()

    ax = sns.lineplot(data=pd.DataFrame(data))
    plt.show()

    return


if __name__ == '__main__':
    main()




