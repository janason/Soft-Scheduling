import pandas as pd

from HRMS.CoHRS.queue_simulator import init_simulator
from HRMS.algorithm.population.ACO import *
from HRMS.algorithm.population.mACOd import *
from HRMS.model.utils import read_from_excel

# 1 deep copy 效率优化，提升速度
# 2 dispatch rule 仿真规则集成

def main():
    # --------------------------1. read instance  ----------------------
    file_name = 'instances.xlsx'
    inst_no = '#1'
    problem = read_from_excel(file_name, inst_no)
    # --------------------------2. run algorithm -----------------------
    init_simulator()
    problem.update(0)
    start_time = time.perf_counter()
    algo = ACO(problem, popsize=30, epochs=40)
    algo.initialize()
    algo.execute()
    algo.output()

    algo.plotObj(algo.history_best_obj)
    algo.plotSoln(algo.best_sol)

    end_time = time.perf_counter()
    execution_time = end_time - start_time
    print(f"程序运行时间为：{execution_time} 秒")

    return


if __name__ == '__main__':
    main()
