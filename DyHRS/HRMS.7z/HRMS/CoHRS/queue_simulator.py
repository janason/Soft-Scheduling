import copy
import time

import pyomo.environ as pyo
from matplotlib import pyplot as plt
from scipy.stats import truncnorm
import numpy as np
import pandas as pd

from HRMS.model import const
from HRMS.model.entities import Problem, Slab, FQueue, RServer
from HRMS.model.utils import read_from_excel


def init_simulator():
    const.SETUP_TIME = 90
    const.LOAD_TIME = 2
    const.RHF_NUM = 3
    const.RHF_CAP = 15
    const.RHF_RULE_FIX = 0  # 仿真选择规则
    const.RHF_RULE_EAT = 1  # earliest arrival time
    const.RHF_RULE_LQL = 2  # longest queue length
    const.RHF_RULE_SQL = 3  # shortest queue length


def randomize(mu):
    noise_scale = 0.5
    noise_level = 0.05
    sigma = noise_level * mu
    lower, upper = mu - noise_scale * sigma, mu + noise_scale * sigma
    X = truncnorm((lower - mu) / sigma, (upper - mu) / sigma, loc=mu, scale=sigma)
    rnd = X.rvs()
    return int(rnd)

class FSlab:
    # __slots__ = ('evt_time', 'evt_type', 'slab', 'source')

    def __init__(self, slab:Slab, r_no):
        self.id = slab.idx

        self.pt_in_server = slab.pt_in_server
        self.pt_in_queue = slab.pt_in_queue
        self.max_waiting = 60

        self.no_in_server = 0
        self.tm_arrival = 0
        self.tm_ready = 0
        self.tm_depart = 0
        self.tm_rolling = 0
        self.tm_finish = 0

        self.id_queue = -1
        self.id_round = r_no

    def __repr__(self):
        return f"S_{self.id}"

class Event:
    __slots__ = ('evt_time', 'evt_type', 'slab', 'source')

    def __init__(self, evt_time, evt_type, slab, src=None):
        self.evt_time = evt_time
        self.evt_type = evt_type  # 0：输入（板坯进入加热炉），1：输出（板坯离开加热炉）
        self.slab = slab  # slab
        self.source = src  # RHF


class Simulator:
    def __init__(self, problem: Problem):
        self.problem = problem

        self.simu_slabs = []
        self.round_list = [[] for _ in range(problem.round_number)]
        self.dest_round = []
        self.arrival_list = []
        self.f_list = []
        self.rhf_list = []
        self.roll_desk = None
        self.allocations = 0
        self.f_opt = 1.0e6
        self.Q_rule = 2

    def run(self, replicates):

        for i in range(replicates):
            f = self.run_simulation(self.simu_slabs, self.arrival_list, self.rhf_list, self.roll_desk)
            self.f_list.append(f)

        mean = np.mean(self.f_list)
        std = np.std(self.f_list, ddof=1)
        self.allocations = len(self.f_list)
        return mean, std

    # 先用 规则+前向+反向调度的方法确定机器分配 + 加热炉时间
    # 然后用 仿真的方法计算目标值
    def select_furnace(self, slabs_in_queue, curr_slab, prev_slab, rule=1):
        des_q = -100
        if rule == const.RHF_RULE_EAT:
            min_tm = 1.0e4
            for q, slabs in slabs_in_queue.items():
                if len(slabs) == 0:
                    tm = prev_slab.tm_arrival
                elif 0 < len(slabs) < const.RHF_CAP:
                    q_slab = slabs[0]
                    tm = max(prev_slab.tm_arrival, q_slab.tm_arrival, q_slab.tm_ready - curr_slab.pt_in_queue)
                else:
                    q_slab = slabs[-1]
                    qq_slab = slabs[-const.RHF_CAP]
                    tm = max(prev_slab.tm_arrival, q_slab.tm_arrival, q_slab.tm_ready - curr_slab.pt_in_queue,
                             qq_slab.tm_depart)
                if tm < min_tm:
                    min_tm = tm
                    des_q = q
            return des_q

        if rule == const.RHF_RULE_SQL:
            min_ql = 1.0e4
            for q, slabs in slabs_in_queue.items():
                if len(slabs) < min_ql:
                    min_ql = len(slabs)
                    des_q = q
            return des_q

        if rule == const.RHF_RULE_LQL:
            max_ql = -1.0e4
            min_qc = 1.0e4
            qs = []
            for q, slabs in enumerate(slabs_in_queue):
                ql = len(slabs) % const.RHF_CAP
                if ql >= max_ql:
                    max_ql = ql
                    qs.append(q)
            for q in qs:
                qc = len(slabs_in_queue[q]) / const.RHF_CAP
                if qc < min_qc:
                    min_qc = qc
                    des_q = q
            return des_q

    def forward_scheduling(self):

        slabs_in_queue = [[] for _ in self.rhf_list]
        sche_slabs = [s for s in self.simu_slabs]
        prev_slab = sche_slabs.pop(0)

        # ----- 首块板坯入炉 ------
        slabs_in_queue[0].append(prev_slab)
        prev_slab.tm_arrival = 0
        prev_slab.tm_ready = prev_slab.tm_arrival + prev_slab.pt_in_queue
        prev_slab.tm_depart = prev_slab.tm_ready
        prev_slab.tm_rolling = prev_slab.tm_depart
        prev_slab.tm_finish = prev_slab.tm_rolling + prev_slab.pt_in_server
        prev_slab.id_queue = 0
        # ----- 板坯逐一入炉 ------
        while len(sche_slabs) > 0:
            curr_slab = sche_slabs.pop(0)
            q_id = self.select_furnace(slabs_in_queue, curr_slab, prev_slab, self.Q_rule)
            curr_slab.id_queue = q_id
            if len(slabs_in_queue[q_id]) == 0:
                curr_slab.tm_arrival = prev_slab.tm_arrival
                curr_slab.tm_ready = curr_slab.tm_arrival + curr_slab.pt_in_queue
                curr_slab.tm_depart = max(curr_slab.tm_ready, prev_slab.tm_finish)
                curr_slab.tm_rolling = curr_slab.tm_depart
                curr_slab.tm_finish = curr_slab.tm_rolling + curr_slab.pt_in_server
            elif 0 < len(slabs_in_queue[q_id]) < const.RHF_CAP:
                q_slab = slabs_in_queue[q_id][-1]
                curr_slab.tm_arrival = max(prev_slab.tm_arrival, q_slab.tm_arrival,
                                           q_slab.tm_ready - curr_slab.pt_in_queue) + const.LOAD_TIME
                curr_slab.tm_ready = curr_slab.tm_arrival + curr_slab.pt_in_queue
                curr_slab.tm_depart = max(curr_slab.tm_ready, prev_slab.tm_finish)
                if curr_slab == self.round_list[curr_slab.id_round][0]:
                    curr_slab.tm_rolling = prev_slab.tm_finish + const.SETUP_TIME
                else:
                    curr_slab.tm_rolling = curr_slab.tm_depart + 0
                curr_slab.tm_finish = curr_slab.tm_rolling + curr_slab.pt_in_server
            else:
                q_slab = slabs_in_queue[q_id][-1]
                qq_slab = slabs_in_queue[q_id][-const.RHF_CAP]
                curr_slab.tm_arrival = max(prev_slab.tm_arrival, q_slab.tm_arrival,
                                           q_slab.tm_ready - curr_slab.pt_in_queue, qq_slab.tm_depart) + const.LOAD_TIME
                curr_slab.tm_ready = curr_slab.tm_arrival + curr_slab.pt_in_queue
                curr_slab.tm_depart = max(curr_slab.tm_ready, prev_slab.tm_finish)
                if curr_slab == self.round_list[curr_slab.id_round][0]:
                    curr_slab.tm_rolling = prev_slab.tm_finish + const.SETUP_TIME
                else:
                    curr_slab.tm_rolling = curr_slab.tm_depart + 0
                curr_slab.tm_finish = curr_slab.tm_rolling + curr_slab.pt_in_server

            slabs_in_queue[q_id].append(curr_slab)
            prev_slab = curr_slab

        return slabs_in_queue

    def backward_scheduling(self, slab_list, q_list):
        slabs_in_queue = {}
        for q in q_list:
            slabs_in_queue[q.id] = []

        sche_slabs = [s for s in slab_list]
        next_slab = sche_slabs.pop(-1)
        q_id = next_slab.RHF.id
        slabs_in_queue[q_id].insert(0, next_slab)
        next_slab.tm_depart = next_slab.tm_rolling
        next_slab.tm_ready = next_slab.tm_depart
        next_slab.tm_arrival = next_slab.tm_ready - next_slab.pt_in_queue
        MIN_ST = next_slab.tm_arrival

        while len(sche_slabs) > 0:
            curr_slab = sche_slabs.pop(-1)
            if curr_slab == curr_slab.round.slab_list[-1]:
                curr_slab.tm_finish = next_slab.tm_rolling - const.SETUP_TIME
            else:
                curr_slab.tm_finish = next_slab.tm_rolling
            curr_slab.tm_rolling = curr_slab.tm_finish - curr_slab.pt_in_server
            slab_queue = slabs_in_queue[curr_slab.RHF.id]
            if len(slab_queue) == 0:
                curr_slab.tm_depart = min(curr_slab.tm_rolling, next_slab.tm_depart)
                curr_slab.tm_ready = min(curr_slab.tm_depart, next_slab.tm_ready)
                curr_slab.tm_arrival = min(next_slab.tm_arrival, curr_slab.tm_ready - curr_slab.pt_in_queue)
            elif 0 < len(slabs_in_queue[q_id]) < const.RHF_CAP:
                q_slab = slab_queue[0]
                curr_slab.tm_depart = min(curr_slab.tm_rolling, next_slab.tm_depart, q_slab.tm_depart)
                curr_slab.tm_ready = min(curr_slab.tm_depart, next_slab.tm_ready, q_slab.tm_ready)
                curr_slab.tm_arrival = min(curr_slab.tm_ready - curr_slab.pt_in_queue, next_slab.tm_arrival,
                                           q_slab.tm_arrival) - const.LOAD_TIME
            else:
                q_slab = slab_queue[0]
                qq_slab = slabs_in_queue[q_id][const.RHF_CAP - 1]
                curr_slab.tm_depart = min(curr_slab.tm_rolling, next_slab.tm_depart, q_slab.tm_depart,
                                          qq_slab.tm_arrival)
                curr_slab.tm_ready = min(curr_slab.tm_depart, next_slab.tm_ready, q_slab.tm_ready)
                curr_slab.tm_arrival = min(curr_slab.tm_ready - curr_slab.pt_in_queue, next_slab.tm_arrival,
                                           q_slab.tm_arrival) - const.LOAD_TIME
            slab_queue.insert(0, curr_slab)
            if MIN_ST > curr_slab.tm_arrival:
                MIN_ST = curr_slab.tm_arrival

            next_slab = curr_slab

        for slab in slab_list:
            slab.tm_finish -= MIN_ST
            slab.tm_rolling -= MIN_ST
            slab.tm_depart -= MIN_ST
            slab.tm_ready -= MIN_ST
            slab.tm_arrival -= MIN_ST
        return slabs_in_queue

    # 进入加热炉： 当前板坯，目标加热炉，进入时间， roll 释放时间
    def handle_arrival_event(self, prev_slab, slab, target_rhf, clock):
        # 1. 加热炉已满，不能进入
        if target_rhf is None:
            return False
        # 2. 更新加热炉、板坯状态
        if len(target_rhf.doing_list) == 0:
            slab.tm_arrival = clock
        else:
            last_slab = target_rhf.doing_list[-1]
            slab.tm_arrival = max(prev_slab.tm_arrival, last_slab.tm_arrival + const.LOAD_TIME, clock)

        # slab.rpt = randomize(slab.pt_in_queue)
        slab.tm_ready = slab.tm_arrival + randomize(slab.pt_in_queue)
        slab.RHF = target_rhf
        target_rhf.doing_list.append(slab)

        if len(target_rhf.doing_list) >= const.RHF_CAP:
            target_rhf.status = 1
            slab.RHF.available_time = max(slab.tm_arrival + const.LOAD_TIME, target_rhf.doing_list[0].tm_ready)
        else:
            target_rhf.status = 0
            slab.RHF.available_time = slab.tm_arrival + const.LOAD_TIME

        return True

    def departure_event(self, slab, server, clock):
        if server.status == 0:
            return False

        slab.tm_depart = clock
        slab.tm_rolling = clock
        slab.tm_finish = slab.tm_rolling + slab.pt_in_server
        slab.status = 3

        server.status = 1
        server.available_time = slab.tm_finish

        slab.RHF.doing_list.remove(slab)
        slab.RHF.done_list.append(slab)

        slab.RHF.status = 0

        return True

    def handle_departure_event(self, prev_slab, slab, server, clock):
        # 1. 如果HRM忙，不能进入
        if server.status == 1:
            return False

        # 2. 更新轧机、板坯状态
        if slab.no_in_server == 0 or prev_slab is None:
            slab.tm_depart = clock
        else:
            slab.tm_depart = max(prev_slab.tm_depart, clock)

        slab.tm_rolling = slab.tm_depart
        slab.tm_finish = slab.tm_rolling + slab.pt_in_server
        slab.status = 3

        if slab == self.round_list[slab.id_round][-1]:
            server.available_time = slab.tm_finish + const.SETUP_TIME
        else:
            server.available_time = slab.tm_finish
        server.status = 1

        slab.RHF.doing_list.remove(slab)

        slab.RHF.status = 0
        return True

    def initialize(self):
        self.rhf_list = [FQueue(i, const.RHF_CAP) for i in range(1, 4)]
        self.roll_desk = RServer(1)
        slabs_in_queue = self.forward_scheduling()
        self.f_opt, self.arrival_list = self.timing_by_MILP(slabs_in_queue)
        return True

    # rule 1 最短队列有效
    # rule 2 最长队列优先
    # rule 3 最小Gap优先
    def select_queue(self, rule, rhf_list, slab):
        target_rhf = None
        target_avt = 0
        if rule == 0:  # 指定RHF
            if len(slab.RHF.doing_list) == 0:
                target_rhf = slab.RHF
                target_avt = 0
            elif 0 < len(slab.RHF.doing_list) < const.RHF_CAP:
                target_rhf = slab.RHF
                target_avt = slab.RHF.doing_list[-1].tm_arrival + const.LOAD_TIME
            else:
                target_rhf = None
                first_slab = slab.RHF.doing_list[0]
                target_avt = max(first_slab.tm_ready, first_slab.tm_depart)

        if rule == 1:
            min_load = 1000
            for f in rhf_list:
                if len(f.doing_list) < min_load and len(f.doing_list) < const.RHF_CAP:
                    target_rhf = f
                    min_load = len(f.doing_list)

        if rule == 2:
            max_load = -1000
            for f in rhf_list:
                if len(f.doing_list) >= const.RHF_CAP:
                    continue
                if len(f.doing_list) > max_load:
                    target_rhf = f
                    max_load = len(f.doing_list)

        return target_rhf, target_avt

    def run_simulation(self, slab_list, arrival_list, rhf_list, roll_desk):
        # 1. initialize parameters and events
        event_list = [Event(evt_time=max(arrival_list[r], 0), evt_type=0, slab=slab_list[r])
                      for r in range(len(slab_list))]
        roll_desk.status = 0
        for i, s in enumerate(slab_list):
            s.tm_arrival = 0
            s.tm_ready = 0
            s.tm_depart = 0
            s.tm_rolling = 0
            s.tm_finish = 0
            s.status = 0
            s.RHF = self.rhf_list[s.id_queue]
            s.no_in_server = i
            # if s.RHF is None:
            #     print(s)
        for ql in rhf_list:
            ql.reset()
        roll_desk.reset()

        # 2. run simulation
        waiting_slabs = []
        while len(event_list) > 0:
            # 从事件列表中选择下一个事件
            event_list.sort(key=lambda x: (x.evt_time, x.slab.no_in_server))
            current_event = event_list.pop(0)
            clock = current_event.evt_time
            current_slab = current_event.slab
            idx = slab_list.index(current_slab)
            prev_slab = None
            if idx > 0:
                prev_slab = slab_list[idx - 1]
            # print(clock, ' ', current_event.evt_type, ' ', current_slab.id)
            if current_event.evt_type == 0:  # enter into RHF
                # 处理板坯到达事件
                best_queue, avt = self.select_queue(const.RHF_RULE_FIX, rhf_list, current_slab)
                if best_queue is None:
                    waiting_slabs.append(current_slab)
                    event_list.append(Event(evt_time=max(avt, clock + 1), evt_type=0, slab=current_slab))
                    continue
                is_enqueue = self.handle_arrival_event(prev_slab, current_slab, best_queue, clock)
                # arrival time 已经确定，只生成板坯离开事件
                if is_enqueue:
                    if prev_slab is None:
                        event_list.append(Event(evt_time=current_slab.tm_ready, evt_type=1, slab=current_slab))
                    else:
                        event_list.append(Event(evt_time=max(prev_slab.tm_depart, current_slab.tm_ready),
                                                evt_type=1, slab=current_slab))
                else:
                    print('no data')

            elif current_event.evt_type == 1:  # depart from RHF

                if prev_slab is not None:
                    roll_desk.available_time = max(prev_slab.tm_ready, prev_slab.tm_depart, roll_desk.available_time)
                if clock < roll_desk.available_time:
                    roll_desk.status = 1
                else:
                    roll_desk.status = 0
                is_start = self.handle_departure_event(prev_slab, current_slab, roll_desk, clock)
                if not is_start:
                    event_list.append(Event(evt_time=roll_desk.available_time, evt_type=1, slab=current_slab))
                else:
                    pass

        f1 = 0
        f2 = 0
        for s in range(len(slab_list)):
            slab = slab_list[s]
            # print(slab.idx, slab.tm_arrival, slab.tm_ready, slab.tm_depart, slab.tm_rolling, slab.tm_finish)
            f1 += slab.tm_depart - slab.tm_ready
            if s == 0:
                f2 += slab.tm_rolling
            else:
                f2 += slab.tm_rolling - slab_list[s - 1].tm_finish
        f2 = f2 - len(self.round_list) * const.SETUP_TIME
        f_obj = 0.8 * f1 + 0.2 * f2

        # print('f1=', f1, ' f2=', f2, ' f=', f_obj)
        # self.plot_final_result()
        return f_obj / len(slab_list)

    def plot_final_result(self):
        # plt.figure(dpi=150)
        import seaborn as sns
        sns.set_theme(style="ticks")

        lw = 2
        fig, ax = plt.subplots(figsize=(10, 6))
        ax.set_xlabel('Time')

        # 加热炉甘特图
        for i, slab in enumerate(self.simu_slabs):
            colors = ['r', 'g', 'b']
            lines = ['-', '--', ':']
            if i == 0:
                t = 1
            else:
                b_slab = self.simu_slabs[i - 1]
                if slab.id_round == b_slab.id_round:
                    t += 1
                else:
                    t = 1
            if slab.id_queue >= 0:
                plt.text(slab.tm_arrival, t, f'{slab.id}:{slab.tm_arrival}-{slab.tm_ready}-{slab.tm_depart}    '
                                             f'{slab.tm_rolling}-{slab.tm_finish}', size=10)
                c_id = slab.id_round
                l_id = slab.id_queue
                plt.plot([slab.tm_arrival, slab.tm_ready], [t, t], linestyle=lines[l_id], c=colors[c_id], linewidth=lw,
                         marker="|",
                         markersize=8)
                plt.plot([slab.tm_ready, slab.tm_depart], [t, t], linestyle=lines[l_id], c=colors[c_id], linewidth=lw,
                         marker="|",
                         markersize=8)

        HR = []
        for slab in self.simu_slabs:
            b = (slab.tm_rolling, slab.tm_finish, slab.id)
            HR.append(b)
            # print(slab.idx, '=', slab.st_heating, '-', slab.et_heating, '-', slab.st_leave, '#', slab.st_rolling, '-',
            #       slab.et_rolling)
        for i, task in enumerate(HR):
            colors = ['r', 'g', 'b']
            c_id = self.simu_slabs[i].id_round- 1
            start = task[0]
            end = task[1]
            ax.barh(-2, end - start, left=start, height=1, color=colors[c_id], alpha=0.8)

        ax.barh(-1, self.simu_slabs[-1].tm_finish + 10, left=0, height=0.25, color="black")

        plt.xlabel("time")
        plt.ylabel("slab")
        plt.ylim(-4, 58)
        plt.xlim(0, self.simu_slabs[-1].tm_finish + 10)
        plt.show()

    def timing_by_MILP(self, slabs_in_queue):
        model = pyo.ConcreteModel("RF")
        model.SLAB_SET = pyo.RangeSet(len(self.simu_slabs))
        model.b = pyo.Var(model.SLAB_SET, domain=pyo.NonNegativeReals, bounds=(0, 2000))  # begin time of heating
        model.e = pyo.Var(model.SLAB_SET, domain=pyo.NonNegativeReals, bounds=(0, 2000))  # end time of heating
        model.d = pyo.Var(model.SLAB_SET, domain=pyo.NonNegativeReals, bounds=(0, 2000))  # depart time of heating
        model.r = pyo.Var(model.SLAB_SET, domain=pyo.NonNegativeReals, bounds=(0, 2000))  # begin time of rolling
        model.g = pyo.Var(model.SLAB_SET, domain=pyo.NonNegativeReals, bounds=(0, 2000))  # end time of rolling

        prev_id = 1
        prev_slab = self.simu_slabs[prev_id - 1]
        model.constr = pyo.ConstraintList()
        model.constr.add(model.b[prev_id] >= 0)
        model.constr.add(model.e[prev_id] - model.b[prev_id] == prev_slab.pt_in_queue)
        model.constr.add(model.d[prev_id] - model.e[prev_id] >= 0)
        model.constr.add(model.r[prev_id] - model.d[prev_id] == 0)
        model.constr.add(model.g[prev_id] - model.r[prev_id] == prev_slab.pt_in_server)

        for curr_id in pyo.RangeSet(2, len(self.simu_slabs)):
            curr_slab = self.simu_slabs[curr_id - 1]
            slab_queue = slabs_in_queue[curr_slab.id_queue]
            q_no = slab_queue.index(curr_slab)
            if q_no == 0:  # 加热炉第一块板坯
                model.constr.add(model.b[curr_id] - model.b[prev_id] >= 0)
                model.constr.add(model.e[curr_id] - model.b[curr_id] == curr_slab.pt_in_queue)
                model.constr.add(model.e[curr_id] - model.e[prev_id] >= 0)
                model.constr.add(model.d[curr_id] - model.d[prev_id] >= 0)
                model.constr.add(model.d[curr_id] - model.e[curr_id] >= 0)
                model.constr.add(model.r[curr_id] - model.d[curr_id] == 0)
            elif 0 < q_no < len(slab_queue) - 1:  # 加热炉未满
                prev_id_q = self.simu_slabs.index(slab_queue[q_no - 1]) + 1
                model.constr.add(model.b[curr_id] - model.b[prev_id] >= 0)
                model.constr.add(model.b[curr_id] - model.b[prev_id_q] >= const.LOAD_TIME)
                model.constr.add(model.e[curr_id] - model.b[curr_id] == curr_slab.pt_in_queue)
                model.constr.add(model.e[curr_id] - model.e[prev_id] >= 0)
                model.constr.add(model.e[curr_id] - model.e[prev_id_q] >= 0)
                model.constr.add(model.d[curr_id] - model.d[prev_id] >= 0)
                model.constr.add(model.d[curr_id] - model.d[prev_id_q] >= 0)
                model.constr.add(model.d[curr_id] - model.e[curr_id] >= 0)
                model.constr.add(model.r[curr_id] - model.d[curr_id] == 0)
            else:
                prev_id_q = self.simu_slabs.index(slab_queue[q_no - 1]) + 1
                prev_id_qq = self.simu_slabs.index(slab_queue[q_no - const.RHF_CAP]) + 1
                model.constr.add(model.b[curr_id] - model.b[prev_id] >= 0)
                model.constr.add(model.b[curr_id] - model.b[prev_id_q] >= const.LOAD_TIME)
                model.constr.add(model.e[curr_id] - model.b[curr_id] == curr_slab.pt_in_queue)
                model.constr.add(model.e[curr_id] - model.e[prev_id] >= 0)
                model.constr.add(model.e[curr_id] - model.e[prev_id_q] >= 0)
                model.constr.add(model.d[curr_id] - model.e[curr_id] >= 0)
                model.constr.add(model.d[curr_id] - model.d[prev_id] >= 0)
                model.constr.add(model.d[curr_id] - model.d[prev_id_q] >= 0)
                model.constr.add(model.r[curr_id] - model.d[curr_id] == 0)
                model.constr.add(model.b[curr_id] - model.d[prev_id_qq] >= 0)

            if curr_slab == self.round_list[curr_slab.id_round][0]:
                model.constr.add(model.r[curr_id] >= model.g[prev_id] + const.SETUP_TIME)
            else:
                model.constr.add(model.r[curr_id] == model.g[prev_id])
            model.constr.add(model.g[curr_id] == model.r[curr_id] + curr_slab.pt_in_server)
            prev_id = curr_id

        # 最小化板坯多住炉时间
        obj1 = sum([model.d[s] - model.e[s] for s in pyo.RangeSet(len(self.simu_slabs))])
        obj2 = sum([model.r[s] - model.g[s - 1] for s in pyo.RangeSet(2, len(self.simu_slabs))]) + model.r[
            1] - const.SETUP_TIME*len(self.round_list)
        model.obj = pyo.Objective(expr=0.8 * obj1 + 0.2 * obj2, sense=pyo.minimize)

        results = pyo.SolverFactory('cplex').solve(model)
        if results.solver.status != pyo.SolverStatus.ok:
            print('infeasible')
            return 1000000  # 返回一个极大数

        # print(results)
        # print('f1=', pyo.value(obj1), ' f2=', pyo.value(obj2), ' f=', model.obj())
        arrival_list = []
        for i in pyo.RangeSet(len(self.simu_slabs)):
            slab = self.simu_slabs[i - 1]
            # slab.tm_arrival = 0
            # slab.tm_ready = 0
            # slab.tm_depart = 0
            # slab.tm_rolling = 0
            # slab.tm_finish = 0

            slab.tm_arrival = int(pyo.value(model.b[i]))
            # slab.tm_ready = int(pyo.value(model.e[i]))
            # slab.tm_depart = int(pyo.value(model.d[i]))
            # slab.tm_rolling = int(pyo.value(model.r[i]))
            # slab.tm_finish = int(pyo.value(model.g[i]))

            arrival_list.append(slab.tm_arrival)

        # self.plot_final_result()

        return model.obj(), arrival_list


def plot_stat_result(simu_list):
    import seaborn as sns
    sns.set_theme(style="ticks")
    colors = sns.color_palette("hls", 8)
    # sns.set_palette('hls')

    size = int(len(simu_list))
    a = np.array([simu_list[i].allocations for i in range(size)])
    b = [simu_list[i].f_list for i in range(size)]
    x = np.arange(size)

    fig = plt.figure()
    ax = fig.add_subplot(111)
    ax.plot(x + 1, a, '--', marker='s', c=colors[0])

    ax2 = ax.twinx()
    ax2.boxplot(b)

    # fig.legend(loc=1, bbox_to_anchor=(1, 1), bbox_transform=ax.transAxes)
    ax.set_xlabel("No. of solutions")
    ax.set_ylabel(r"Allocations")
    ax2.set_ylabel(r"Means")
    plt.show()


def get_ranks(array):
    """
    Returns a numpy array containing ranks of numbers within a input numpy array
    e.g. [3, 2, 1] returns [2, 1, 0]
    e.g. [3, 2, 1, 4] return [2, 1, 0, 3]

    Parameters:
    --------
    array - np.ndarray, numpy array (only tested with 1d)

    Returns:
    ---------
    np.ndarray, ranks

    """
    temp = array.argsort()
    ranks = np.empty_like(temp)
    ranks[temp] = np.arange(len(array))
    return ranks


def _parameter_c(means, ses, k, m):
    order = np.argsort(means)
    s_ses = [ses[r] for r in order]
    s_means = [means[r] for r in order]

    c = ((s_ses[m] * s_means[m - 1]) + (s_ses[m - 1] * s_means[m])) / (s_ses[m - 1] + s_ses[m])

    return c


def OCBA(_S, _T, _delta, _n0):
    _k = len(_S)
    _total_reward = 0
    _current_round = 0
    _allocations = np.zeros(_k, np.int32)
    _means = np.zeros(_k, np.float64)
    _vars = np.zeros(_k, np.float64)
    _ratios = np.zeros(_k, np.float64)
    _sq = np.zeros(_k, np.float64)

    for s in _S:
        s.run(_n0)

    return


def OCBAm(_S, _T, _delta, _n0, _m=3):
    _k = len(_S)
    _means = np.zeros(_k, np.float64)
    _stds = np.zeros(_k, np.float64)
    _ses = np.zeros(_k, np.float64)
    _ratios = np.zeros(_k, np.float64)
    _sq = np.zeros(_k, np.float64)

    if len(_S) <= _m:
        for k, S in enumerate(_S):
            n = _T / _k
            _means[k], _stds[k] = S.run(n)
        return

    # initialize
    add_n = np.full(shape=_k, fill_value=_n0, dtype=np.int16)
    for k in range(_k):
        _means[k], _stds[k] = _S[k].run(add_n[k])
        _ses[k] = _stds[k] / np.sqrt(_S[k].allocations)
    T = sum([s.allocations for s in _S])
    while T < _T:
        # calculate parameter c and deltas
        c = _parameter_c(_means, _ses, _k, _m)
        deltas = _means - c
        # allocate
        add_n = np.full(shape=_k, fill_value=0, dtype=np.int16)
        old_n = np.array([_S[k].allocations for k in range(_k)])

        for i in range(_delta):
            values = np.divide(old_n + add_n, np.square(np.divide(_ses, deltas)))
            ranks = get_ranks(values)
            add_n[ranks.argmin()] += 1
        # simulate
        for k in range(_k):
            _means[k], _stds[k] = _S[k].run(add_n[k])
            _ses[k] = _stds[k] / np.sqrt(_S[k].allocations)
        T = sum([s.allocations for s in _S])

    for k in range(_k):
        _means[k] = np.mean(_S[k].f_list)
        _stds[k] = np.std(_S[k].f_list)

    bests = np.argpartition(_means, _m)[0:_m]  # return top m
    return bests, _means, _stds


if __name__ == '__main__':

    file_name = 'instances.xlsx'
    inst_no = '#1'
    problem = read_from_excel(file_name, inst_no)

    T1 = time.time()
    init_simulator()  # 初始化参数

    simu_list = []
    N = 10
    for i in range(N):
        df = pd.read_excel('solutions.xlsx', sheet_name="S-" + str(i + 1))
        problem.update(0)
        simu = Simulator(problem)
        for index, row in df.iterrows():
            idx = row['slab']
            rdx = row['round']
            slab = problem.get_slab(idx)
            fslab = FSlab(slab, rdx - 1)
            simu.simu_slabs.append(fslab)
            simu.round_list[rdx-1].append(fslab)
            fslab.no_in_server = index

        simu.initialize()
        simu_list.append(simu)
    T2 = time.time()
    print('程序运行时间:%s秒' % ((T2 - T1)))

    bests = OCBAm(simu_list, N * 20, 10, 5, 3)
    print(bests)
    # plot_final_result(input_slabs)
    T3 = time.time()
    print('程序运行时间:%s秒' % ((T3 - T2)))
    plot_stat_result(simu_list)
