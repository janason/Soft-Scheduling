import math
import random
import copy
import time

from HRMS.algorithm.base import *
from HRMS.model.Solution import Solution
from HRMS.algorithm.population.gMOO import gMOO


class mPSO(gMOO):
    def __init__(self, problem: Problem, popsize, epochs):
        super().__init__(problem, popsize, epochs)
        self.x_list = []
        self.p_xs = []
        self.g_xs = []
        self.v = []
        self.Vmax = 0.5
        self.Vmin = -0.5
        self.w = 0.5
        self.c1 = 0.15
        self.c2 = 0.15
        self.LZ = 3
        self.GZ = 8
        self.all_nodes = [s.idx for s in problem.fixed_slabs] + self.cand_idx

    def name(self):
        return 'mPSO'

    def initialize(self):
        super().initialize()
        self.x_list = []
        self.g_xs = []
        self.p_xs = [[] for i in range(self.P_size)]
        fixed_nodes = [s.idx for s in self.problem.fixed_slabs]
        for i in range(self.P_size):
            sol: Solution = self.sol_list[i]
            sol.evaluate_rui()
            N = self.cand_cnt + len(self.problem.fixed_slabs)
            x = [0] * N
            for j, s in enumerate(sol.node_seq):
                if s in fixed_nodes:
                    x[s - 1] = 0 - 1 / (j + 1)
                else:
                    x[s - 1] = (j + 1) / N
            self.x_list.append(x)
            self.p_xs[i].append((x, sol))
            self.v.append([self.Vmax] * N)

        fronts, ranks = self.fast_non_dominated_sorting(self.sol_list)
        sort_idx = self.calculate_crowding_distance(fronts, ranks)
        for i in sort_idx[0: self.GZ]:
            self.g_xs.append((self.x_list[i], self.sol_list[i]))

        print("epoch=", 0, " EAP size=", len(self.EAP))

        # self.pg = best_sol.slab_no_seq

    def update_position(self):
        w = self.w
        c1 = self.c1
        c2 = self.c2
        pg = self.g_xs[random.randint(0, self.GZ - 1)][0]

        g_x = []
        g_s = []
        for p in range(self.P_size):
            x = self.x_list[p]
            sol = self.sol_list[p]

            v = self.v[p]
            il = random.randint(0, len(self.p_xs[p]) - 1)
            pl = self.p_xs[p][il][0]
            r1 = random.random()
            r2 = random.random()
            new_v = []
            new_x = []
            for i in range(len(v)):
                if x[i] >= 0:
                    v_ = w * v[i] + c1 * r1 * (pl[i] - x[i]) + c2 * r2 * (pg[i] - x[i])
                    new_v.append(min(v_, self.Vmax))
                    new_x.append(max(x[i] + new_v[i], 0))
                else:
                    new_v.append(0)
                    new_x.append(x[i])
            new_sol = self.trans_x2sol(new_x)
            self.v[p] = new_v
            self.sol_list[p] = new_sol
            self.x_list[p] = new_x

            # 有问题……
            del_idx = []
            not_dominated = True
            for j, z in enumerate(self.p_xs[p]):
                if new_sol.dominate(z[1]):
                    del_idx.append(j)
                if z[1].dominate(new_sol):
                    not_dominated = False
            if not_dominated:
                new_pl = [(new_x, new_sol)]
                for j, z in enumerate(self.p_xs[p]):
                    if j not in del_idx:
                        new_pl.append(z)
                if len(new_pl) > self.LZ:
                    self.p_xs[p] = new_pl[0:self.LZ]
                else:
                    self.p_xs[p] = new_pl

            for j in range(len(self.p_xs[p])):
                xx = self.p_xs[p][j]
                g_x.append(xx[0])
                g_s.append(xx[1])

        fronts, ranks = self.fast_non_dominated_sorting(g_s)
        sort_idx = self.calculate_crowding_distance(fronts, ranks, g_s)
        for i in sort_idx[0: self.GZ]:
            self.g_xs.append((g_x[i], g_s[i]))
        self.update_archive(self.sol_list)

    def trans_x2sol(self, x):
        sorted_x = sorted(enumerate(x), key=lambda x: x[1])
        seq = [i[0]+1 for i in sorted_x]
        sol = Solution(self.problem, seq)
        sol.evaluate_rui()
        return sol

    def execute(self):
        t1 = time.perf_counter()
        ep = 1
        while True:
            self.update_position()
            self.update_ideal_distance()
            print("epoch=", ep + 1, " EAP size=", len(self.EAP))
            ep = ep + 1
            t2 = time.perf_counter()
            if t2 - t1 > self.budget:
                break

        t2 = time.perf_counter()
        print(f'cost= {t2 - t1:.8f}s')
