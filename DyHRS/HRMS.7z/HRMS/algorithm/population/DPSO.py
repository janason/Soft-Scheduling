import random
import copy
from HRMS.algorithm.base import *
from HRMS.algorithm.population.gMOO import gMOO
from HRMS.algorithm.population.gSOO import gSOO


class DPSO(gSOO):
    def __init__(self, problem: Problem, popsize, epochs):
        super().__init__(problem, popsize, epochs)
        self.pl = []
        self.pg = None
        self.v = []
        self.Vmax = 5
        self.w = 0.8
        self.c1 = 2
        self.c2 = 2

    def name(self):
        return 'discrete particle swarm optimization'

    def initialize(self):
        node_seq = copy.deepcopy(self.node_seq_list)
        best_sol = Solution(self.problem)
        best_sol.obj = float('inf')
        for i in range(self.popsize):
            seed = int(random.randint(0, 10))
            random.seed(seed)
            random.shuffle(node_seq)
            sol = Solution(self.problem)
            sol.slab_no_seq = copy.deepcopy(node_seq)
            sol.evaluate()
            self.sol_list.append(sol)
            self.v.append([self.Vmax] * self.node_count)
            self.pl.append(sol)
            if sol.objective < best_sol.objective:
                best_sol = copy.deepcopy(sol)
        self.best_sol = best_sol
        self.pg = best_sol.slab_no_seq

    def updatePosition(self):
        w = self.w
        c1 = self.c1
        c2 = self.c2
        pg = self.pg
        for id, sol in enumerate(self.sol_list):
            x = sol.slab_no_seq
            v = self.v[id]
            pl = self.pl[id].slab_no_seq
            r1 = random.random()
            r2 = random.random()
            new_v = []
            for i in range(self.node_count):
                v_ = w * v[i] + c1 * r1 * (pl[i] - x[i]) + c2 * r2 * (pg[i] - x[i])
                if v_ > 0:
                    new_v.append(min(v_, self.Vmax))
                else:
                    new_v.append(max(v_, -self.Vmax))
            new_x = [min(int(x[i] + new_v[i]), self.node_count - 1) for i in range(self.node_count)]
            new_x = self.adjustRoutes(new_x)
            self.v[id] = new_v

            new_sol = Solution(self.problem)
            new_sol.slab_no_seq = new_x
            new_sol.evaluate
            self.sol_list[id] = new_sol

            if new_sol.objective < self.pl[id].objective:
                self.pl[id] = copy.deepcopy(new_sol)
            if new_sol.objective < self.best_sol.objective:
                self.best_sol = copy.deepcopy(new_sol)
                self.pg = copy.deepcopy(new_x)

    def adjustRoutes(self, nodes_seq):
        all_node_list = copy.deepcopy(self.node_seq_list)
        repeat_node = []
        for id, node_no in enumerate(nodes_seq):
            if node_no in all_node_list:
                all_node_list.remove(node_no)
            else:
                repeat_node.append(id)
        for i in range(len(repeat_node)):
            nodes_seq[repeat_node[i]] = all_node_list[i]
        return nodes_seq

    def execute(self):

        history_best_obj = [self.best_sol.objective]
        for ep in range(self.epochs):
            self.updatePosition()
            history_best_obj.append(self.best_sol.objective)
            print("%s/%s: best obj: %s" % (ep, self.epochs, self.best_sol.objective))
        plotObj(history_best_obj)
        self.plotSoln(self.best_sol)
