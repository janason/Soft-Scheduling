import copy
import math
from abc import ABC
import random
import numpy as np
import matplotlib.pyplot as plt
from HRMS.algorithm.base import Algorithm
from HRMS.model.Solution import Solution
from HRMS.algorithm.topsis import Topsis
from HRMS.model.entities import *
from HRMS.model.operators import *
from HRMS.algorithm.population.indicators import *


class gMOO(Algorithm, ABC):
    def __init__(self, problem, popsize, epochs):
        self.best_soln = None
        self.problem = problem

        self.epochs = epochs
        self.P_size = popsize
        self.epoch = 0
        self.EAP = []
        self.sol_list = []
        self.ideal_distance = []
        self.hyper_volume = []
        self.spacing = []

        self.cand_idx = []
        self.cand_cnt = 0
        self.fixed_idx = []
        self.fixed_cnt = 0
        self.frontier = []
        self.budget = len(problem.released_slabs) * 0.05

    def initialize(self):

        self.epoch = 0
        self.EAP = []
        self.ideal_distance = []
        self.sol_list = []

        self.cand_idx = [s.idx for s in self.problem.released_slabs if s.status == 1]
        self.cand_cnt = len(self.cand_idx)
        self.fixed_idx = [s.idx for s in self.problem.fixed_slabs]
        self.fixed_cnt = len(self.fixed_idx)

        cand_seq = copy.deepcopy(self.cand_idx)
        for i in range(self.P_size):
            seed = int(random.randint(0, 10))
            random.seed(seed)
            random.shuffle(cand_seq)
            gene = [i for i in self.fixed_idx] + [i for i in cand_seq]
            sol = Solution(self.problem, gene)
            self.sol_list.append(sol)

    def plot_frontier(self, show_fig=True, obj_num=2):
        self.frontier = []

        if obj_num != 2:
            return
        plt.rcParams['font.sans-serif'] = ['SimHei']  # show chinese
        plt.rcParams['axes.unicode_minus'] = False  # Show minus sign
        x = []
        y = []
        for sol in self.EAP:
            x.append(sol.objectives[0])
            y.append(sol.objectives[1])
            self.frontier.append([sol.objectives[0], sol.objectives[1]])

        plt.scatter(x, y)
        plt.xlabel('obj-1')
        plt.ylabel('obj-2')
        plt.show()
        # clrs1 = generate_color_list(7, 'Reds')
        # clrs2 = generate_color_list(7, 'Blues')
        # x = 0
        # r = 0
        # for rod in self.problem.round_list:
        #     r = r + 1
        #     for slab in rod.slab_list:
        #         x = x + 1
        #         y1 = 0 - slab.width / 2
        #         y2 = 0 + slab.width / 2
        #         if slab.status == 2:
        #             plt.plot([x, x], [y1, y2], color='k', linewidth=slab.gauge * 2)
        #         else:
        #             if r % 2 == 0:
        #                 plt.plot([x, x], [y1, y2], color=clrs1[slab.hardness], linewidth=slab.gauge * 2)
        #             else:
        #                 plt.plot([x, x], [y1, y2], color=clrs2[slab.hardness], linewidth=slab.gauge * 2)

    def plotObj(self, obj_list):
        plt.rcParams['font.sans-serif'] = ['SimHei']  # show chinese
        plt.rcParams['axes.unicode_minus'] = False  # Show minus sign
        plt.plot(np.arange(1, len(obj_list) + 1), obj_list)
        plt.xlabel('Iterations')
        plt.ylabel('Obj Value')
        plt.grid()
        plt.xlim(1, len(obj_list) + 1)
        plt.show()

    def plotSoln(self, bestSol: Solution):
        plt.rcParams['font.sans-serif'] = ['SimHei']  # show chinese
        plt.rcParams['axes.unicode_minus'] = False  # Show minus sign

        clrs1 = generate_color_list(7, 'Reds')
        clrs2 = generate_color_list(7, 'Blues')
        x = 0
        r = 0
        for rod in self.problem.round_list:
            r = r + 1
            for slab in rod.slab_list:
                x = x + 1
                y1 = 0 - slab.width / 2
                y2 = 0 + slab.width / 2
                if slab.status == 2:
                    plt.plot([x, x], [y1, y2], color='k', linewidth=slab.gauge * 2)
                else:
                    if r % 2 == 0:
                        plt.plot([x, x], [y1, y2], color=clrs1[int(slab.hardness)], linewidth=slab.gauge * 2)
                    else:
                        plt.plot([x, x], [y1, y2], color=clrs2[int(slab.hardness)], linewidth=slab.gauge * 2)

        plt.xlabel('Orders', fontsize=12, labelpad=0)
        plt.ylabel('Width', fontsize=12, labelpad=0)
        plt.grid()
        plt.xlim(1, x)
        plt.show()

    def update_archive(self, A):
        save_idx = []
        for k, xsol in enumerate(A):
            # 更新外部种群
            p = 0
            # 需要被删除的集合
            dele_idx = []
            # 支配前沿集合，的数量
            for i, ysol in enumerate(self.EAP):
                # F_Y是否支配pi号个体，支配？哪pi就完了，被剔除。。
                if xsol.dominate(ysol):
                    # 列入被删除的集合
                    dele_idx.append(i)
                if ysol.dominate(xsol):
                    # 它有被别人支配！！记下来能支配它的个数
                    p += 1
            new_EAP = []
            for save_id in range(len(self.EAP)):
                if save_id not in dele_idx:
                    # 不需要被删除，那就保存
                    new_EAP.append(self.EAP[save_id])
            # 更新上面计算好的新的支配前沿
            self.EAP = new_EAP
            # 如果p==0，意味着没人支配id_Y
            # 没人支配id_Y？太好了，加进支配前沿呗
            if p == 0:
                # 不在里面直接加新成员
                self.EAP.append(xsol)
                save_idx.append(k)
        # over
        return save_idx

    def update_ideal_distance(self):
        ideal_point = (0, 0)
        dist = 0
        min_dist = math.inf
        for sol in self.EAP:
            x = math.sqrt((sol.objectives[0] - ideal_point[0]) ** 2 + (sol.objectives[1] - ideal_point[1]) ** 2)
            if min_dist > x:
                min_dist = x

        self.ideal_distance.append(min_dist)

    def calc_indicator(self):
        obj_list = [[s.objectives[0], s.objectives[1]] for s in self.EAP]
        hv = hv_indicator(np.array(obj_list), n_obj=2)

        self.hyper_volume.append(hv)

        sp = sp_indicator(solution=np.array(obj_list))

        self.spacing.append(sp)

        return hv, sp

    def find_best_soln(self):

        results = []
        for sol in self.EAP:
            results.append(list(sol.objectives))

        evaluation_matrix = np.array(results)

        weights = [1.0] * len(results[0])

        '''
        if higher value is preferred - True
        if lower value is preferred - False
        '''
        criterias = np.array([False] * len(results[0]))

        t = Topsis(evaluation_matrix, weights, criterias)

        t.calc()

        # print("best_distance\t", t.best_distance)
        # print("worst_distance\t", t.worst_distance)

        # print("weighted_normalized",t.weighted_normalized)

        # print("worst_similarity\t", t.worst_similarity)
        # print("rank_to_worst_similarity\t", t.rank_to_worst_similarity())

        # print("best_similarity\t", t.best_similarity)
        # print("rank_to_best_similarity\t", t.rank_to_best_similarity())

        seq = t.rank_to_best_similarity()
        self.best_soln = self.EAP[seq[0] - 1]

    def output(self):

        print(self.calc_indicator())
        self.plot_frontier(2)

        self.find_best_soln()
        if self.best_soln is None:
            return
        self.problem.fixed_slabs.clear()
        for id in self.best_soln.ant_tour:
            slab = self.problem.get_slab(id)
            self.problem.fixed_slabs.append(slab)


        for r, tour in enumerate(self.best_soln.subtours):
            self.problem.round_list[r].reset()
            tour_len = 0
            for id in tour[1]:
                slab = self.problem.get_slab(id)
                tour_len += slab.length
                self.problem.round_list[r].slab_list.append(slab)
            print(tour_len)

        self.plotSoln(self.best_soln)

    def fast_non_dominated_sorting(self, sol_list=None):
        if sol_list is None:
            sol_list = self.sol_list
        S = [[] for i in range(0, len(sol_list))]
        front = [[]]
        n = [0 for i in range(0, len(sol_list))]
        rank = [0 for i in range(0, len(sol_list))]
        for p in range(0, len(sol_list)):
            S[p] = []
            n[p] = 0
            pSol: Solution = sol_list[p]
            for q in range(0, len(sol_list)):
                qSol: Solution = sol_list[q]
                if pSol.dominate(qSol):
                    if q not in S[p]:
                        S[p].append(q)
                elif qSol.dominate(pSol):
                    n[p] = n[p] + 1
            if n[p] == 0:
                rank[p] = 0
                if p not in front[0]:
                    front[0].append(p)
        i = 0
        while len(front[i]) != 0:
            Q = []
            for p in front[i]:
                for q in S[p]:
                    n[q] = n[q] - 1
                    if n[q] == 0:
                        rank[q] = i + 1
                        if q not in Q:
                            Q.append(q)
            i = i + 1
            front.append(Q)
        del front[len(front) - 1]

        if sol_list is None:
            self.EAP = [self.sol_list[i] for i in front[0]]

        return front, rank

    def calculate_crowding_distance(self, fronts, ranks, sol_list=None):
        if sol_list is None:
            sol_list = self.sol_list
        sort_ranks = [[ranks[i], -1, i] for i in range(len(ranks))]
        for front in fronts:
            fn = len(front)
            xlist = [sol_list[i] for i in front]
            crowding_distance = [0] * fn
            for m in range(len(xlist[0].objectives)):
                xlist.sort(key=lambda sol: sol.objectives[m])
                crowding_distance[0] = 10 ** 6
                crowding_distance[fn - 1] = 10 ** 6
                m_values = [sol.objectives[m] for sol in xlist]
                scale = max(m_values) - min(m_values)
                if scale == 0:
                    scale = 1
                for i in range(1, fn - 1):
                    crowding_distance[i] += (xlist[i + 1].objectives[m] - xlist[i - 1].objectives[m]) / scale
            for i, j in enumerate(front):
                sort_ranks[j][1] = crowding_distance[i]
        sort_ranks.sort(key=lambda x: (x[0], -x[1]))
        return [rd[2] for rd in sort_ranks]
