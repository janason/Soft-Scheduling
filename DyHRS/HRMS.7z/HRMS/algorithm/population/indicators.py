############################################################################

# Created by: Prof. Valdecy Pereira, D.Sc.
# UFF - Universidade Federal Fluminense (Brazil)
# email:  valdecy.pereira@gmail.com
# Multivariate Indicators

# Citation: 
# PEREIRA, V. (2022). GitHub repository: <https://github.com/Valdecy/pyMultiojective>

############################################################################

# Required Libraries
import itertools
import numpy as np
from pymoo.factory import get_performance_indicator
from pymoo.indicators.hv import HV

from scipy import spatial


############################################################################

# Available Indicators:

# GD          (https://apps.dtic.mil/sti/pdfs/ADA364478.pdf)
# GD+         (https://doi.org/10.1007/978-3-319-15892-1_8)
# IGD         (https://doi.org/10.1007/978-3-540-24694-7_71)
# IGD+        (https://doi.org/10.1007/978-3-319-15892-1_8)
# MS          (https://doi.org/10.1162/106365600568202)
# SP          (https://doi.org/10.1109/TEVC.2006.882428)
# Hypervolume (https://scholar.afit.edu/cgi/viewcontent.cgi?article=6130&context=etd)

############################################################################

# Helper Functions

# Functon: Generate Data Points
def generate_points(min_values=[-5, -5], max_values=[5, 5], list_of_functions=[], step=[0.1, 0.1], pf_min=True):
    x = []
    for j in range(0, len(min_values)):
        values = np.arange(min_values[j], max_values[j] + step[j], step[j])
        x.append(values)
    cartesian_product = list(itertools.product(*x))
    front = np.array(cartesian_product, dtype=np.dtype('float'))
    front = np.c_[front, np.zeros((len(cartesian_product), len(list_of_functions)))]
    for j in range(0, len(list_of_functions)):
        value = [list_of_functions[j](item) for item in cartesian_product]
        front[:, len(min_values) + j] = value
    return front


# minimal, a dominate b return 1, b dominate a return -1, else return 0
def dominates(a, b, maximise=False):
    if sum([a[i] == b[i] for i in range(len(a))]) == len(a):
        return 0

    if sum([a[i] >= b[i] for i in range(len(a))]) == len(a):
        if maximise:
            return 1
        else:
            return -1
    elif sum([a[i] <= b[i] for i in range(len(a))]) == len(a):
        if maximise:
            return -1
        else:
            return 1
    else:
        return 0


def get_pareto_front(pts):
    pf = []
    for k, pt_k in enumerate(pts):
        p = 0
        dele_idx = []
        # 支配前沿集合，的数量
        for i, pt_i in enumerate(pf):
            is_dominate = dominates(pt_k, pt_i)
            if is_dominate > 0:
                # 列入被删除的集合
                dele_idx.append(i)
            if is_dominate < 0:
                # 它有被别人支配！！记下来能支配它的个数
                p += 1
        new_pf = []
        for save_id in range(len(pf)):  # 不需要被删除，那就保存
            if save_id not in dele_idx:
                new_pf.append(pf[save_id])
        # 更新上面计算好的新的支配前沿
        pf = new_pf
        # 如果p==0，意味着没人支配id_Y
        # 没人支配id_Y？太好了，加进支配前沿呗
        if p == 0:
            # 不在里面直接加新成员
            pf.append(pt_k)
    return pf


# Function:  Pareto Front
def pareto_front_points(pts, pf_min=True):
    def pareto_front(pts, pf_min):
        pf = np.zeros(pts.shape[0], dtype=np.bool_)
        for i in range(0, pts.shape[0]):
            cost = pts[i, :]
            if pf_min == True:
                g_cost = np.logical_not(np.any(pts > cost, axis=1))
                b_cost = np.any(pts < cost, axis=1)
            else:
                g_cost = np.logical_not(np.any(pts < cost, axis=1))
                b_cost = np.any(pts > cost, axis=1)
            dominated = np.logical_and(g_cost, b_cost)
            if (np.any(pf) == True):
                if (np.any(np.all(pts[pf] == cost, axis=1)) == True):
                    continue
            if not (np.any(dominated[:i]) == True or np.any(dominated[i + 1:]) == True):
                pf[i] = True
        return pf

    idx = np.argsort(((pts - pts.mean(axis=0)) / (pts.std(axis=0) + 1e-7)).sum(axis=1))
    pts = pts[idx]
    pf = pareto_front(pts, pf_min)
    pf[idx] = pf.copy()
    return pf


############################################################################

# GD - Generational Distance

# Function: GD
def gd_indicator(min_values=[-5, -5], max_values=[5, 5], list_of_functions=[], step=[0.1, 0.1], solution=[],
                 custom_pf=[], pf_min=True):
    if solution.shape[1] > len(min_values):
        sol = solution[:, len(min_values):]
    elif solution.shape[1] == len(min_values):
        sol = np.copy(solution)
    if len(custom_pf) > 0:
        front = np.copy(custom_pf)
    else:
        front = generate_points(min_values, max_values, list_of_functions, step, pf_min)
        pf = pareto_front_points(pts=front[:, len(min_values):], pf_min=pf_min)
        front = front[pf, len(min_values):]
    d_i = [(spatial.KDTree(front).query(sol[i, :])) for i in range(0, sol.shape[0])]
    d = [item[0] for item in d_i]
    gd = np.sqrt(sum(d)) / len(d)
    return gd


############################################################################

# GD+ - Generational Distance Plus

# Function: GD+
def gd_plus_indicator(min_values=[-5, -5], max_values=[5, 5], list_of_functions=[], step=[0.1, 0.1], solution=[],
                      custom_pf=[], pf_min=True):
    if (solution.shape[1] > len(min_values)):
        sol = solution[:, len(min_values):]
    elif (solution.shape[1] == len(min_values)):
        sol = np.copy(solution)
    if (len(custom_pf) > 0):
        front = np.copy(custom_pf)
    else:
        front = generate_points(min_values, max_values, list_of_functions, step, pf_min)
        pf = pareto_front_points(pts=front[:, len(min_values):], pf_min=pf_min)
        front = front[pf, len(min_values):]
    d_i = [(spatial.KDTree(front).query(sol[i, :])) for i in range(0, sol.shape[0])]
    idx = [item[1] for item in d_i]
    s = [max(max(sol[i, :] - front[idx[i], :]), 0) ** 2 for i in range(0, sol.shape[0])]
    gdp = np.sqrt(sum(s)) / len(s)
    return gdp


############################################################################

# IGD - Inverted Generational Distance

# Function: IGD
def igd_indicator(min_values=[-5, -5], max_values=[5, 5], list_of_functions=[], step=[0.1, 0.1], solution=[],
                  custom_pf=[], pf_min=True):
    if (solution.shape[1] > len(min_values)):
        sol = solution[:, len(min_values):]
    elif (solution.shape[1] == len(min_values)):
        sol = np.copy(solution)
    if (len(custom_pf) > 0):
        front = np.copy(custom_pf)
    else:
        front = generate_points(min_values, max_values, list_of_functions, step, pf_min)
        pf = pareto_front_points(pts=front[:, len(min_values):], pf_min=pf_min)
        front = front[pf, len(min_values):]
    d_i = [(spatial.KDTree(sol).query(front[i, :])) for i in range(0, front.shape[0])]
    d = [item[0] for item in d_i]
    igd = np.sqrt(sum(d)) / len(d)
    return igd


############################################################################

# IGD+ - Inverted Generational Distance Plus

# Function: IGD+
def igd_plus_indicator(min_values=[-5, -5], max_values=[5, 5], list_of_functions=[], step=[0.1, 0.1], solution=[],
                       custom_pf=[], pf_min=True):
    if (solution.shape[1] > len(min_values)):
        sol = solution[:, len(min_values):]
    elif (solution.shape[1] == len(min_values)):
        sol = np.copy(solution)
    if (len(custom_pf) > 0):
        front = np.copy(custom_pf)
    else:
        front = generate_points(min_values, max_values, list_of_functions, step, pf_min)
        pf = pareto_front_points(pts=front[:, len(min_values):], pf_min=pf_min)
        front = front[pf, len(min_values):]
    d_i = [(spatial.KDTree(sol).query(front[i, :])) for i in range(0, front.shape[0])]
    idx = [item[1] for item in d_i]
    s = [max(max(sol[idx[i], :] - front[i, :]), 0) ** 2 for i in range(0, front.shape[0])]
    igdp = np.sqrt(sum(s)) / len(s)
    return igdp


############################################################################

# MS - Maximum Spread

# Function:  Maximum Spread
def ms_indicator(min_values=[-5, -5], max_values=[5, 5], list_of_functions=[], step=[0.1, 0.1], solution=[],
                 custom_pf=[], pf_min=True):
    if (solution.shape[1] > len(min_values)):
        sol = solution[:, len(min_values):]
    elif (solution.shape[1] == len(min_values)):
        sol = np.copy(solution)
    if (len(custom_pf) > 0):
        front = np.copy(custom_pf)
    else:
        front = generate_points(min_values, max_values, list_of_functions, step, pf_min)
        pf = pareto_front_points(pts=front[:, len(min_values):], pf_min=pf_min)
        front = front[pf, len(min_values):]
    s_max = np.max(sol, axis=0)
    s_min = np.min(sol, axis=0)
    f_max = np.max(front, axis=0)
    f_min = np.min(front, axis=0)
    ms = 0
    for i in range(0, len(list_of_functions)):
        ms = ms + ((min(s_max[i], f_max[i]) - max(s_min[i], f_min[i])) / (f_max[i] - f_min[i])) ** 2
    ms = np.sqrt(ms / len(list_of_functions))
    return ms


# SP - Spacing

# Function:  Spacing
def sp_indicator(min_values=[-5, -5], max_values=[5, 5], list_of_functions=[], step=[0.1, 0.1], solution=[],
                 custom_pf=[], pf_min=True):
    if solution.shape[1] > len(min_values):
        sol = solution[:, len(min_values):]
    elif solution.shape[1] == len(min_values):
        sol = np.copy(solution)
    if sol.shape[0]>1:
        dm = np.zeros(sol.shape[0])
        for i in range(0, sol.shape[0]):
            dm[i] = min([np.linalg.norm(sol[i] - sol[j]) for j in range(0, sol.shape[0]) if i != j])
        d_mean = np.mean(dm)
        spacing = np.sqrt(np.sum((dm - d_mean) ** 2) / sol.shape[0])
    else:
        spacing = 1.0
    return spacing


############################################################################

# Hypervolume (S-Metric)

# Function: Hypervolume
def hv_indicator(z_obj=[], n_obj=2, max_pt=[], min_pt=[], ref_pt=[]):
    if z_obj.shape[1] != n_obj:
        print('error')
        return 0
    if len(max_pt) == 0 or len(min_pt) == 0:
        z_max = np.max(z_obj, axis=0)
        z_min = np.min(z_obj, axis=0)
    else:
        z_max = np.array(max_pt)
        z_min = np.array(min_pt)
    v_obj = (z_obj - z_min) / (z_max - z_min + 1)
    if 0 == len(ref_pt):
        ref_pt = [1.0] * n_obj

    # hv_c = pg.hypervolume(v_obj)
    # hv1 = hv_c.compute(ref_pt)

    ind = HV(ref_point=ref_pt)
    hv2 = ind(v_obj)
    return hv2


############################################################################
# Success Ratio
def sr_indicator(z_objs=[], pf=[]):
    n = 0
    for z1 in z_objs:
        for z2 in pf:
            if z1[0] == z2[0] and z1[1] == z2[1]:
                n = n + 1
                break
    return n * 1.0 / len(pf)
