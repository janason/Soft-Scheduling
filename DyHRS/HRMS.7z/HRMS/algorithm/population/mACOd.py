import math
import time
import random
import numpy as np
from numpy import ndarray

from HRMS.model.Solution import *
from HRMS.algorithm.population.gMOO import gMOO
from HRMS.model.entities import *
from HRMS.model.operators import *
import itertools


# Acciarini G, Izzo D, Mooij E. Mhaco: a multi-objective hypervolume-based ant colony optimizer for space trajectory
# optimization[C]//2020 IEEE Congress on Evolutionary Computation (CEC). IEEE, 2020: 1-8.

# MACO/d 不太适合

class mACOd(gMOO):

    def __init__(self, problem, popsize, epochs):
        # ant i to solution i， # 种群大小，取决于vector_csv_file/下的xx.csv

        self.epoch = 0
        self.W = np.loadtxt(fname='D:\\8.GitSync\\PySteelScheduler\\HRMS\\algorithm\\population\\weight_vector.csv')
        popsize = self.W.shape[0]
        self.T_size = 10
        self.G_size = OBJ_CNT
        # 蚂蚁的T个邻居。比如：T=2，(0.1,0.9)的邻居：(0,1)、(0.2,0.8)。永远固定不变
        self.Neighbor = []
        # 理想点。（比如最小化，理想点是趋于0）
        self.Z = [0, 0]
        # 蚂蚁的G个分组
        self.Group = []
        self.ant_2_grp = []

        N = 0
        self.ant_2_grp = []
        for g in range(self.G_size):
            ng = int(popsize / OBJ_CNT)
            self.Group.append([N + i for i in range(ng)])
            self.ant_2_grp.extend([g] * ng)
            N += ng
        if N < popsize:
            self.Group[-1].append(N)
            self.ant_2_grp.append(self.G_size - 1)

        # 邻居设定（只会对邻居内的相互更新、交叉）
        self.find_neighbors()

        super().__init__(problem, popsize, epochs)
        self.history_best_obj = None
        self.costs = {}
        self.alpha = 1
        self.beta = 2
        self.Q = 10
        self.rho = 0.1
        self.tau = {}  # 信息素
        self.eta = {}  # 启发因子

        self.tau_min = math.inf
        self.tau_max = -math.inf

        self.allow_list = {i: [] for i in self.fixed_idx + self.cand_idx}  # tabu list for node

        for i in self.fixed_idx + self.cand_idx:
            self.costs[0, i, 0] = 0
            self.costs[0, i, 1] = - problem.get_slab(i).price
            for j in self.fixed_idx + self.cand_idx:
                if i == j:
                    continue
                self.costs[i, j, 0] = problem.dist_matrix[i, j]
                self.costs[i, j, 1] = - problem.get_slab(j).price

    # 计算T个邻居
    def find_neighbors(self):
        # 计算权重的T个邻居
        if self.T_size < 1:
            return -1
        for bi in range(self.W.shape[0]):
            Bi = self.W[bi]
            DIS = np.sum((self.W - Bi) ** 2, axis=1)
            B_T = np.argsort(DIS)
            # 第0个是自己（距离永远最小）
            B_T = B_T[1:self.T_size + 1]
            self.Neighbor.append(B_T)

    def name(self):
        return "mACO/d"

    def initialize(self):
        self.EAP = []
        self.allow_list[0] = []
        # initialize allow_list
        for i in self.fixed_idx + self.cand_idx:
            self.allow_list[0].append(i)
            s1: Slab = self.problem.get_slab(i)
            for j in self.fixed_idx + self.cand_idx:
                if i == j:
                    continue
                s2: Slab = self.problem.get_slab(j)
                if s1.width == s2.width or s1.hardness == s2.hardness or s1.gauge == s2.gauge:
                    if s1.width >= s2.width:
                        self.allow_list[i].append(j)
        # initialize Tau
        for i, j, g in itertools.product([0] + self.fixed_idx + self.cand_idx, self.fixed_idx + self.cand_idx,
                                         range(self.G_size)):
            if i != j:
                self.tau[i, j, g] = 1.0
        # initialize eta
        for i, j, k in itertools.product([0] + self.fixed_idx + self.cand_idx, self.fixed_idx + self.cand_idx,
                                         range(self.P_size)):
            if i == j:
                continue
            Cij = [self.costs[i, j, g] for g in range(self.G_size)]
            xx = sum([x * y for x, y in zip(self.W[k, :], Cij)])
            if xx == 0:
                self.eta[i, j, k] = 1.0
            else:
                self.eta[i, j, k] = 1.0 / xx
        return

    def selectFirstNode(self, SE_List):
        to_select = []
        for i, node_no in enumerate(SE_List):
            slab: Slab = self.problem.get_slab(node_no)
            to_select.append((node_no, slab.width))
        to_select.sort(key=lambda x: x[1], reverse=True)
        next_node_no = to_select[0][0]
        return next_node_no

    def selectNextNode(self, lw, LW, current_node_no, SE_List, ant_no):
        # 不能同时跳变
        sel_listx = list(set(self.allow_list[current_node_no]).intersection(set(SE_List)))
        sel_list = []
        # 同宽约束
        for id in sel_listx:
            salb: Slab = self.problem.get_slab(id)
            if lw + salb.length <= LW:
                sel_list.append(id)
        if len(sel_list) == 0:
            return -1

        prob = np.zeros(len(sel_list))
        for i, next_node_no in enumerate(sel_list):
            eta = self.eta[current_node_no, next_node_no, ant_no]
            if self.epoch > 0:
                ant = self.sol_list[ant_no]
                grp = self.ant_2_grp[ant_no]
                if ant.is_exist_path(current_node_no, next_node_no):
                    tau = self.tau[current_node_no, next_node_no, grp] + 0.05 * self.tau_max
                else:
                    tau = self.tau[current_node_no, next_node_no, grp]
            else:
                grp = self.ant_2_grp[ant_no]
                tau = self.tau[current_node_no, next_node_no, grp]
            prob[i] = ((eta ** self.alpha) * (tau ** self.beta))
        # use Roulette to determine the next node
        cumsumprob = (prob / sum(prob)).cumsum()
        cumsumprob -= np.random.rand()
        next_node_no = sel_list[list(cumsumprob > 0).index(True)]

        if next_node_no < 0:
            print('error')

        return next_node_no

    def upateTau(self, ants: list):
        g_min = math.inf
        for g in range(self.G_size):
            g_sum = 0.0
            for k in self.Group[g]:
                g_val = self.calc_tchbycheff_dist(k, ants[k])
                g_sum += g_val
                if g_val < g_min:
                    g_min = g_val
            for i, j in itertools.product([0] + self.cand_idx, self.cand_idx):
                if i == j:
                    continue
                self.tau[i, j, g] = 0.95 * self.tau[i, j, g] + 1.0 / g_sum
        self.tau_max = (len(self.EAP) + 1) / (0.05 * g_min)
        self.tau_min = self.tau_max / (2 * len(self.cand_idx))

    def execute(self):
        t1 = time.perf_counter()
        for ep in range(self.epochs):
            # solution construction
            ants = []
            for k in range(self.P_size):
                sol = Solution(self.problem, [])
                sol.evaluate_aco(self.selectFirstNode, self.selectNextNode)
                ants.append(sol)
            # update external archive
            self.update_archive(ants)
            self.update_ideal_distance()
            # update Pheromone matrices
            self.upateTau(ants)
            # update sub-problems or ants
            if len(self.sol_list) > 0:
                for k in range(self.P_size):
                    new_sol = ants[k]
                    old_sol = self.sol_list[k]
                    new_dist = self.calc_tchbycheff_dist(k, new_sol)
                    old_dist = self.calc_tchbycheff_dist(k, old_sol)
                    if new_dist < old_dist:
                        self.sol_list[k] = new_sol
            else:
                self.sol_list = [x for x in ants]
                if ants[0] in self.sol_list:
                    print('xxx')

            print("%s/%s， size of EAP: %s" % (ep, self.epochs, len(self.EAP)))
        t2 = time.perf_counter()
        print(f'cost= {t2 - t1:.8f}s')
        self.find_best_soln()
        self.plot_frontier(2)
        self.output()
        self.plotSoln(self.best_soln)

    def calc_tchbycheff_dist(self, idx, x: Solution):
        # idx：X在种群中的位置
        # 计算X的切比雪夫距离（与理想点Z的）
        max = self.Z[0]
        ri = self.W[idx]
        fv = x.objectives
        for i in range(len(fv)):
            fi = ri[i] * abs(fv[i] - self.Z[i])
            if fi > max:
                max = fi
        return max
