import random
import time

import numpy as np
import pandas as pd
from scipy.stats import ttest_1samp

from HRMS.CoHRS.queue_simulator import Simulator, OCBAm, FSlab
from HRMS.algorithm.population.gSOO import gSOO
from HRMS.model.Solution import *
from HRMS.model.entities import *


class ACO(gSOO):

    def __init__(self, problem, popsize, epochs):
        super().__init__(problem, popsize, epochs)

        self.history_best_obj = None
        self.distance = {}
        self.alpha = 1
        self.beta = 2
        self.Q = 10
        self.rho = 0.1
        self.tau = {}
        self.allow_list = {i: [] for i in self.nodes}  # tabu list for node
        self._n_cluster = 10
        self._n_pos = 3  # head, middle, tail
        self._states = [(i + 1, j + 1) for i in range(self._n_cluster) for j in range(self._n_pos)]
        self._actions = [0, 1, 2]
        self._q_table = pd.DataFrame(data=[[0 for _ in self._actions] for _ in self._states],
                                     index=self._states, columns=self._actions)
        self._cluster_dict = {}

        print(self._cluster_dict)

    def name(self):
        return "ant colony optimization"

    def initialize(self):
        self.best_sol = None  # Solution(self.problem)
        self.allow_list[0] = []
        for i in self.nodes:
            self.allow_list[0].append(i)
            s1: Slab = self.problem.get_slab(i)
            for j in self.nodes:
                if i == j:
                    continue
                s2: Slab = self.problem.get_slab(j)
                self.tau[i, j] = self.Q / (1 + self.problem.dist_matrix[i, j])
                if (s1.width != s2.width) + (s1.hardness != s2.hardness) + (s1.gauge != s2.gauge) + (
                        s1.Temp != s2.Temp) <= 3:
                    if -50 < (s1.width - s2.width) <= 200 and abs(s1.gauge - s2.gauge) <= 20 and abs(
                            s1.hardness - s2.hardness) <= 3:
                        self.allow_list[i].append(j)
            self.tau[0, i] = self.Q * 100 / s1.width

        return

    def construct_solution(self, is_random=False):
        all_nodes_seq = [n for n in self.nodes]
        sol = Solution(self.problem, [])
        dist = 0.0
        n = 0
        for r in range(len(sol.subtours)):
            if n < len(self.problem.fixed_slabs):
                s = self.problem.fixed_slabs[n].idx
            else:
                if is_random:
                    s = random.choice(all_nodes_seq)
                else:
                    s = self.searchFirstNode(all_nodes_seq)  # 这个地方使用聚类学习算法
            sv = 0
            slab: Slab = self.problem.get_slab(s)
            lw = slab.length
            cap = self.problem.round_list[r].capacity
            rm = cap
            tour = sol.subtours[r][1]
            while rm - slab.length >= 0:  # 判断是否可以加入
                tour.append(s)
                sol.ant_tour.append(s)
                rm = rm - slab.length
                all_nodes_seq.remove(s)
                if sv > 0:
                    dist += self.problem.dist_matrix[sv, s]
                    prev_slab: Slab = self.problem.get_slab(sv)
                    if prev_slab.width == slab.width:
                        lw += slab.length
                    else:
                        lw = slab.length
                sv = s
                n = n + 1
                if n < len(self.problem.fixed_slabs):
                    s = self.problem.fixed_slabs[n].idx
                else:
                    s = self.searchNextNode(lw, cap * 1.0, s, all_nodes_seq)  # next slab
                if s < 0:
                    break
                slab: Slab = self.problem.get_slab(s)

        loss = 0.0
        for s in all_nodes_seq:
            sol.unvisited.append(s)
            slab: Slab = self.problem.get_slab(s)
            loss += slab.price
        sol.add_warmup()
        sol.objectives = dist + loss * 20,

        return sol

    def movePosition(self):
        sol_list = []
        for k in range(self.popsize):
            # construct solution
            sol = self.construct_solution(False)
            sol_list.append(sol)
        self.handle_constr(sol_list)
        for k in range(self.popsize):
            if self.best_sol is None:
                self.best_sol = copy.copy(sol)
            elif sol < self.best_sol and sol.is_feasible:
                self.best_sol = copy.copy(sol)
        self.sol_list = [sol for sol in sol_list]

    def searchFirstNode(self, SE_List, used_tau=False):
        if used_tau:
            candidates = []
            for i, node_no in enumerate(SE_List):
                slab: Slab = self.problem.get_slab(node_no)
                candidates.append((node_no, slab.width, slab.price))
            candidates.sort(key=lambda x: (x[1], x[2]), reverse=True)
            rnd = random.randint(0, int(len(candidates) * 0.1))
            next_node_no = candidates[rnd][0]
            if candidates[rnd][1] < 5:
                print('first node:', candidates[rnd])
        else:
            next_node_no = self.searchNextNode(0, 1.0e5, 0, SE_List)
        return next_node_no

    def searchNextNode(self, lw, LW, current_node_no, SE_List):
        # 不能同时跳变
        sel_listx = list(set(self.allow_list[current_node_no]).intersection(set(SE_List)))
        sel_list = []
        # 同宽约束
        for id in sel_listx:
            salb: Slab = self.problem.get_slab(id)
            if lw + salb.length <= LW:
                sel_list.append(id)
        if len(sel_list) == 0:
            return -1

        prob = np.zeros(len(sel_list))
        for i, node_no in enumerate(sel_list):
            eta = 1 / (self.problem.dist_matrix[current_node_no, node_no] + 1.0)
            tau = self.tau[current_node_no, node_no]
            prob[i] = ((eta ** self.alpha) * (tau ** self.beta))
        # use Roulette to determine the next node
        cumsumprob = (prob / sum(prob)).cumsum()
        cumsumprob -= np.random.rand()
        next_node_no = sel_list[list(cumsumprob > 0).index(True)]
        return next_node_no

    def upateTau(self, style=2):
        rho = self.rho
        if style == 0:
            for k in self.tau.keys():
                self.tau[k] = (1 - rho) * self.tau[k]
            for sol in self.sol_list:
                ant_tour = sol.ant_tour
                for i in range(len(ant_tour) - 1):
                    from_node_no = ant_tour[i]
                    to_node_no = ant_tour[i + 1]
                    self.tau[from_node_no, to_node_no] += self.Q / self.best_sol.objectives[0]
        else:
            for k in self.tau.keys():
                self.tau[k] = (1 - rho) * self.tau[k]
            F_set, I_set = [], []
            for sol in self.sol_list:
                if sol.is_feasible:
                    F_set.append(sol)
                else:
                    I_set.append(sol)
            F_set.sort(key=lambda x: x.objectives[0])
            w = len(F_set)
            for r, sol in enumerate(F_set):
                for bitour in sol.subtours:
                    tour = bitour[1]
                    to_no = tour[0]
                    self.tau[0, to_no] += (w - r) * 1 / sol.objectives[0]
                    for i in range(len(tour) - 1):
                        from_no, to_no = tour[i], tour[i + 1]
                        self.tau[from_no, to_no] += (w + 1 - r) * 1 / sol.objectives[0]
            for sol in I_set:
                for bitour in sol.subtours:
                    tour = bitour[1]
                    to_no = tour[0]
                    self.tau[0, to_no] -= 1.0 / self.best_sol.objectives[0]
                    for i in range(len(tour) - 1):
                        from_no, to_no = tour[i], tour[i + 1]
                        self.tau[from_no, to_no] -= 1.0 / self.best_sol.objectives[0]
        return

    def handle_constr(self, sol_list):
        F_set = []
        for sol in sol_list:
            cnt = 0
            for i in range(len(sol.visited) - 1):
                from_slab = self.problem.get_slab(sol.visited[i])
                to_slab = self.problem.get_slab(sol.visited[i + 1])
                if abs(from_slab.Temp - to_slab.Temp) > 50:
                    cnt = cnt + 1
            if 4 >= cnt:
                sol.is_feasible = True
                F_set.append(sol)
            else:
                sol.is_feasible = False

        print(f'仿真开始(solutions = {len(F_set)})----------')
        T1 = time.time()
        simu_list = []
        for sol in F_set:
            self.problem.update(0)

            simu = Simulator(self.problem)
            for r, tours in enumerate(sol.subtours):
                tour = tours[0] + tours[1]
                for id in tour:
                    slab = self.problem.get_slab(id)
                    fslab = FSlab(slab, r)
                    simu.simu_slabs.append(fslab)
                    simu.round_list[r].append(fslab)
                    # simu.dest_round.append(r)

                    # self.problem.round_list[r].slab_list.append(slab)
                    # slab.round = self.problem.round_list[r]

            simu.initialize()
            simu_list.append(simu)

        bests, means, stds = OCBAm(simu_list, len(F_set) * 10, 10, 5, 2)

        for i in range(len(F_set)):
            res = ttest_1samp(simu_list[i].f_list, popmean=12, alternative='less')
            if res.pvalue > 0.05:
                F_set[i].is_feasible = False

        T2 = time.time()
        print('仿真运行:%s秒' % ((T2 - T1)))
        return True

    def execute(self):
        self.history_best_obj = []
        t1 = time.perf_counter()
        for ep in range(self.epochs):
            self.movePosition()
            self.upateTau()
            self.history_best_obj.append(self.best_sol.objectives[0])
            print("%s/%s， best obj: %s" % (ep, self.epochs, self.best_sol.objectives[0]))
        t2 = time.perf_counter()
        print(f'consuming time = {t2 - t1:.8f}s')

    def output(self):
        if self.best_sol is None:
            print('The best solution is None')
            return
        self.problem.fixed_slabs.clear()
        for id in self.best_sol.ant_tour:
            slab = self.problem.get_slab(id)
            self.problem.fixed_slabs.append(slab)

        writer = pd.ExcelWriter('solutions.xlsx')
        for sol in self.sol_list:
            input_slabs = []
            tot_num = 0
            data = {'slab': [], 'round': []}
            for r, tours in enumerate(sol.subtours):
                self.problem.round_list[r].reset()
                tot_len = 0
                tour = tours[0] + tours[1]
                for id in tour:
                    slab = self.problem.get_slab(id)
                    tot_len += slab.length
                    self.problem.round_list[r].slab_list.append(slab)
                    slab.round = self.problem.round_list[r]
                    input_slabs.append(slab)
                    tot_num += 1
                    data['slab'].append(id)
                    data['round'].append(r + 1)
                # print(f'{r + 1}: total len={tot_len}')

            # print(self.problem, 'selected num= ', tot_num)
            df = pd.DataFrame(data)
            df.to_excel(writer, sheet_name='S-' + str(self.sol_list.index(sol) + 1))

        writer.save()
        # writer.close()
