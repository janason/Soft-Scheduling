import math
import time
import random
import numpy as np

from HRMS.model.Solution import *
from HRMS.algorithm.population.gMOO import gMOO
from HRMS.algorithm.qLearning import *
from HRMS.model.entities import *
from HRMS.model.operators import *
import itertools


# Chiang T C, Hsu W H. A knowledge-based evolutionary algorithm for the multiobjective vehicle routing problem with
# time windows[J]. Computers & Operations Research, 2014, 45: 25-37.

#

class mACOq(gMOO):

    def __init__(self, problem, popsize, epochs):

        super().__init__(problem, popsize, epochs)
        self.history_best_obj = None
        # self.distance = {}
        self.alpha = 1
        self.beta = 2
        self.Q = 10
        self.rho = 0.05
        self.G = 7
        self.Tau = {}
        self.Eta = [{} for i in range(self.G)]
        self.allow_list = {}  # allow list for all nodes
        self.omega = [(0, 1.0), (0.125, 0.875), (0.25, 0.75), (0.5, 0.5), (0.75, 0.25), (0.875, 0.125), (1.0, 0.0)]
        self.trails = [[0, 0] for g in range(self.G)]  # trails & score

    def name(self):
        return "mACOq"

    def initialize(self):
        super().initialize()
        self.sol_list.clear()
        self.allow_list = {i: [] for i in [0] + self.fixed_idx + self.cand_idx}  # allow list for all nodes
        # initialize eta
        for g in range(self.G):
            eta = {}
            for i1, i2 in itertools.product(self.fixed_idx + self.cand_idx, self.fixed_idx + self.cand_idx):
                if i1 != i2:
                    eta[i1, i2] = self.problem.prize_dict[i2] ** self.omega[g][0] / \
                                  (self.problem.dist_matrix[i1, i2] + 1) ** self.omega[g][1]
            self.Eta[g] = eta

        for i1 in self.allow_list.keys():
            if i1 == 0:
                self.allow_list[0].append(self.fixed_idx + self.cand_idx)
                continue
            s1: Slab = self.problem.get_slab(i1)
            for i2 in self.cand_idx + self.fixed_idx:
                if i1 == i2:
                    continue
                s2: Slab = self.problem.get_slab(i2)
                if s1.width == s2.width or s1.hardness == s2.hardness or s1.gauge == s2.gauge:
                    if s1.width >= s2.width:
                        self.allow_list[i1].append(i2)
            # if len(self.allow_list[i1]) < 20:
            #     print(i1)

        if self.problem.t > 0:
            model = Learner(self.Tau, self.problem)
            model.learning()
            for i1 in self.allow_list.keys():
                for i2 in self.cand_idx + self.fixed_idx:
                    if i1 == i2:
                        continue
                    if i1 == 0:
                        s2: Slab = self.problem.get_slab(i2)
                        x = [s2.width, s2.gauge, s2.hardness, 0, s2.price]
                    else:
                        s1: Slab = self.problem.get_slab(i1)
                        s2: Slab = self.problem.get_slab(i2)
                        x = [s2.width - s1.width, s2.gauge - s1.gauge, s2.hardness - s1.hardness, s1.price,
                             s2.price]
                    if (i1, i2) not in self.Tau.keys():
                        self.Tau[i1, i2] = model.predict([x])
                    xtau = self.Tau[i1, i2] / (math.pow(0.95, 100))
                    if xtau > self.Q:
                        xtau = self.Q
                    self.Tau[i1, i2] = xtau
            # print(self.Tau)
        else:
            for i1 in self.allow_list.keys():
                for i2 in self.cand_idx + self.fixed_idx:
                    if i1 != i2:
                        self.Tau[i1, i2] = 1.0
        return

    def searchFirstNode(self, SE_List):
        candidates = []
        for i, node_no in enumerate(SE_List):
            slab: Slab = self.problem.get_slab(node_no)
            candidates.append((node_no, slab.width, slab.price))
        candidates.sort(key=lambda x: (x[1], x[2]), reverse=True)
        rnd = random.randint(0, int(len(candidates) * 0.1))
        next_node_no = candidates[rnd][0]
        return next_node_no

    def searchNextNode(self, current_node_no, SE_List, dyn_constr, Tau, Eta):
        # 获得可选列表
        allows = self.allow_list[current_node_no]
        candidates = list(set(allows).intersection(set(SE_List)))
        sel_list = []
        # 同宽约束
        for id in candidates:
            salb: Slab = self.problem.get_slab(id)
            if dyn_constr[0][0] + salb.length <= dyn_constr[0][1] \
                    and dyn_constr[1][0] - salb.length > dyn_constr[1][1]:
                sel_list.append(id)
        if len(sel_list) == 0:
            return -1

        prob = np.zeros(len(sel_list))
        for i, node_no in enumerate(sel_list):
            eta = Eta[current_node_no, node_no]
            tau = Tau[current_node_no, node_no]
            prob[i] = ((eta ** self.alpha) * (tau ** self.beta))
        # use Roulette to determine the next node
        cumsumprob = (prob / sum(prob)).cumsum()
        cumsumprob -= np.random.rand()
        next_node_no = sel_list[list(cumsumprob > 0).index(True)]
        return next_node_no

    def upate_tau(self, sol_list):

        self.EAP.sort(key=lambda x: (x.objectives[0], -x.objectives[1]))
        OHI = []

        for i, s in enumerate(self.EAP):
            if i == 0:
                s_sup = None
            else:
                s_sup = self.EAP[i - 1]
            if i == len(self.EAP) - 1:
                s_inf = None
            else:
                s_inf = self.EAP[i + 1]
            if s_inf is None and s_sup is None:
                ohvc = 1.0
            elif s_inf is None:
                ohvc = 2 * (s.objectives[0] - s_sup.objectives[0]) * (s_sup.objectives[1] - s.objectives[1])
            elif s_sup is None:
                ohvc = 2 * (s_inf.objectives[0] - s.objectives[0]) * (s.objectives[1] - s_inf.objectives[1])
            else:
                ohvc_sup = (s.objectives[0] - s_sup.objectives[0]) * (s_sup.objectives[1] - s.objectives[1])
                ohvc_inf = (s_inf.objectives[0] - s.objectives[0]) * (s.objectives[1] - s_inf.objectives[1])
                ohvc = ohvc_inf + ohvc_sup
            OHI.append(ohvc)

        sum_ohi = sum(OHI)
        ratios = [v / sum_ohi for v in OHI]

        rho = self.rho
        for k in self.Tau.keys():
            self.Tau[k] = (1 - rho) * self.Tau[k]
        # update Tau according to sol.nodes_seq(solution of TSP)
        for s, sol in enumerate(self.EAP):
            from_node = 0
            for _,tour in sol.subtours:
                for node in tour:
                    to_node = node
                    self.Tau[from_node, to_node] += self.Q * ratios[s]
                    from_node = to_node

    def select_eta(self, ep, k):
        N = ep * self.P_size + k + 1
        trails = [self.trails[g][0] for g in range(self.G)]
        if min(trails) < 5:
            g = random.randint(0, self.G - 1)
        else:
            if random.random() < 0.5:
                g = random.randint(0, self.G - 1)
            else:
                ucb = []
                for g in range(self.G):
                    mean = self.trails[g][1] / self.trails[g][0]
                    ucb.append(mean + np.sqrt(2 * np.log(N) / self.trails[g][0]))
                g = np.argmax(ucb)
        return g, self.Eta[g]

    def update_scores(self, ants, survivals):

        for i, g in ants:
            self.trails[g][0] += 1  # one more trail
            if i in survivals:
                self.trails[g][1] += 1  # get more scores

    def execute(self):
        t1 = time.perf_counter()
        ep = 1
        while True:
            # solution construction and update external archive population
            sols = []
            ants = []
            for k in range(self.P_size):
                sol = Solution(self.problem, nodes=[], fixed_idx=self.fixed_idx)
                g, eta = self.select_eta(ep, k)
                ants.append((k, g))
                sol.evaluate_aco(self.searchFirstNode, self.searchNextNode, self.Tau, eta)
                sols.append(sol)
            # update external archive
            survivals = self.update_archive(sols)
            self.update_scores(ants, survivals)
            self.update_ideal_distance()
            # update Pheromone matrices
            self.upate_tau(self.EAP)
            # update sub-problems or ants
            self.sol_list = [ant for ant in sols]
            print("%s/%s， size of EAP: %s" % (ep, self.epochs, len(self.EAP)))

            with open('log.txt', "a") as file:  # 只需要将之前的”w"改为“a"即可，代表追加内容
                for s in self.EAP:
                    str = f'{self.problem.t}'+ '\t' + f'{ep}' + '\t' + f'{s.objectives[0]:.1f}' + '\t' + f'{s.objectives[1]:.1f}'
                    file.write(str + '\n')

            ep = ep + 1
            t2 = time.perf_counter()
            if ep > self.epochs:
                break

        t2 = time.perf_counter()
        print(f'cost= {t2 - t1:.8f}s')
        with open('log.txt', "a") as file:  # 只需要将之前的”w"改为“a"即可，代表追加内容
            file.write(f'cost= {t2 - t1:.4f}s' + '\n')
