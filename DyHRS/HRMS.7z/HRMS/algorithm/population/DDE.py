import time

import pandas as pd
import math
import random
import numpy as np
import copy
import xlsxwriter
import matplotlib.pyplot as plt

from HRMS.algorithm.base import *
from HRMS.algorithm.population.gSOO import gSOO
from HRMS.model.operators import *


class DDE(gSOO):
    def __init__(self, problem: Problem, popsize, epochs):
        super().__init__(problem, popsize, epochs)

        self.Cr = 0.5
        self.F = 0.5

    def name(self):
        return "differential evolution"

    def initialize(self):
        nodes_seq = copy.deepcopy(self.node_seq_list)
        self.best_sol = Solution(self.problem)
        for i in range(self.popsize):
            seed = int(random.randint(0, 10))
            random.seed(seed)
            random.shuffle(nodes_seq)
            sol = Solution(self.problem)
            sol.slab_no_seq = copy.deepcopy(nodes_seq)
            sol.evaluate
            self.sol_list.append(sol)
            if sol.objective < self.best_sol.objective:
                self.best_sol = copy.deepcopy(sol)

    # Differential mutation; mutation strategies: DE/rand/1/bin
    def muSol(self, v1):
        x1 = self.sol_list[v1].slab_no_seq
        while True:
            v2 = random.randint(0, self.popsize - 1)
            if v2 != v1:
                break
        while True:
            v3 = random.randint(0, self.popsize - 1)
            if v3 != v2 and v3 != v1:
                break
        x2 = self.sol_list[v2].slab_no_seq
        x3 = self.sol_list[v3].slab_no_seq
        mu_x = [min(int(x1[i] + self.F * (x2[i] - x3[i])), self.node_count - 1) for i in
                range(self.node_count)]
        return mu_x

    # Differential Crossover
    def crossSol(self, vx, vy):
        cro_x = []
        for i in range(self.node_count):
            if random.random() < self.Cr:
                cro_x.append(vy[i])
            else:
                cro_x.append(vx[i])
        cro_x = self.adjustRoutes(cro_x)
        return cro_x

    def adjustRoutes(self, nodes_seq):
        all_node_list = copy.deepcopy(self.node_seq_list)
        repeat_node = []
        for id, node_no in enumerate(nodes_seq):
            if node_no in all_node_list:
                all_node_list.remove(node_no)
            else:
                repeat_node.append(id)
        for i in range(len(repeat_node)):
            nodes_seq[repeat_node[i]] = all_node_list[i]
        return nodes_seq

    def execute(self):
        history_best_obj = []
        for ep in range(self.epochs):
            for i in range(self.popsize):
                v1 = random.randint(0, self.popsize - 1)
                sol = self.sol_list[v1]
                mu_x = self.muSol(v1)
                u = self.crossSol(sol.slab_no_seq, mu_x)
                u_obj = sol.evaluate1(u)
                if u_obj <= sol.objective:
                    sol.slab_no_seq = copy.deepcopy(u)
                    sol.evaluate
                    if sol.objective < self.best_sol.objective:
                        self.best_sol = copy.deepcopy(sol)
            history_best_obj.append(self.best_sol.objective)
            print("%s/%s， best obj: %s" % (ep, self.epochs, self.best_sol.objective))
        plotObj(history_best_obj)
        self.plotSoln(self.best_sol)


