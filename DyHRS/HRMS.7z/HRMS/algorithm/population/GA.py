import time

import pandas as pd
import math
import random
import numpy as np
from abc import ABC
import random
import numpy as np
import matplotlib.pyplot as plt
from HRMS.algorithm.base import Algorithm
from HRMS.algorithm.population.gSOO import gSOO
from HRMS.model.entities import *
from HRMS.model.operators import *


class GA(gSOO):
    def __init__(self, problem: Problem, popsize, epochs):
        super().__init__(problem, popsize, epochs)
        self.pc = 0.7
        self.pm = 0.1
        self.n_select = int(popsize / 2)

    def name(self):
        return 'genetic algorithm'

    def initialize(self):
        nodes_seq = copy.deepcopy(self.node_seq_list)
        for i in range(self.popsize):
            seed = int(random.randint(0, 10))
            random.seed(seed)
            random.shuffle(nodes_seq)
            sol = Solution(self.problem)
            sol.slab_no_seq = copy.deepcopy(nodes_seq)
            sol.evaluate
            self.sol_list.append(sol)

    def selectSol(self):
        sol_list = copy.deepcopy(self.sol_list)
        self.sol_list = []
        for i in range(self.n_select):
            f1_index = random.randint(0, len(sol_list) - 1)
            f2_index = random.randint(0, len(sol_list) - 1)
            f1_fit = sol_list[f1_index].objective
            f2_fit = sol_list[f2_index].objective
            if f1_fit > f2_fit:
                self.sol_list.append(sol_list[f2_index])
            else:
                self.sol_list.append(sol_list[f1_index])

    # Order Crossover (OX)
    def crossSol(self):
        sol_list = copy.deepcopy(self.sol_list)
        self.sol_list = []
        while True:
            f1_index = random.randint(0, len(sol_list) - 1)
            f2_index = random.randint(0, len(sol_list) - 1)
            if f1_index != f2_index:
                f1 = copy.deepcopy(sol_list[f1_index])
                f2 = copy.deepcopy(sol_list[f2_index])
                if random.random() <= self.pc:
                    cro1_index = int(random.randint(0, self.node_count - 1))
                    cro2_index = int(random.randint(cro1_index, self.node_count - 1))
                    new_c1_f = []
                    new_c1_m = f1.slab_no_seq[cro1_index:cro2_index + 1]
                    new_c1_b = []
                    new_c2_f = []
                    new_c2_m = f2.slab_no_seq[cro1_index:cro2_index + 1]
                    new_c2_b = []
                    for index in range(self.node_count):
                        if len(new_c1_f) < cro1_index:
                            if f2.slab_no_seq[index] not in new_c1_m:
                                new_c1_f.append(f2.slab_no_seq[index])
                        else:
                            if f2.slab_no_seq[index] not in new_c1_m:
                                new_c1_b.append(f2.slab_no_seq[index])
                    for index in range(self.node_count):
                        if len(new_c2_f) < cro1_index:
                            if f1.slab_no_seq[index] not in new_c2_m:
                                new_c2_f.append(f1.slab_no_seq[index])
                        else:
                            if f1.slab_no_seq[index] not in new_c2_m:
                                new_c2_b.append(f1.slab_no_seq[index])
                    new_c1 = copy.deepcopy(new_c1_f)
                    new_c1.extend(new_c1_m)
                    new_c1.extend(new_c1_b)
                    f1.slab_no_seq = new_c1
                    new_c2 = copy.deepcopy(new_c2_f)
                    new_c2.extend(new_c2_m)
                    new_c2.extend(new_c2_b)
                    f2.slab_no_seq = new_c2
                    self.sol_list.append(copy.deepcopy(f1))
                    self.sol_list.append(copy.deepcopy(f2))
                else:
                    self.sol_list.append(copy.deepcopy(f1))
                    self.sol_list.append(copy.deepcopy(f2))
                if len(self.sol_list) > self.popsize:
                    break

    # mutation
    def muSol(self):
        sol_list = copy.deepcopy(self.sol_list)
        self.sol_list = []
        while True:
            f1_index = int(random.randint(0, len(sol_list) - 1))
            f1 = copy.deepcopy(sol_list[f1_index])
            m1_index = random.randint(0, self.node_count - 1)
            m2_index = random.randint(0, self.node_count - 1)
            if m1_index != m2_index:
                if random.random() <= self.pm:
                    node1 = f1.slab_no_seq[m1_index]
                    f1.slab_no_seq[m1_index] = f1.slab_no_seq[m2_index]
                    f1.slab_no_seq[m2_index] = node1
                    self.sol_list.append(copy.deepcopy(f1))
                else:
                    self.sol_list.append(copy.deepcopy(f1))
                if len(self.sol_list) > self.popsize:
                    break

    def execute(self):

        history_best_obj = []
        best_sol = Solution(self.problem)
        self.best_sol = best_sol
        for ep in range(self.epochs):
            for sol in self.sol_list:
                sol.evaluate
                if sol.objective < self.best_sol.objective:
                    self.best_sol = copy.deepcopy(sol)
            self.selectSol()
            self.crossSol()
            self.muSol()
            history_best_obj.append(self.best_sol.objective)
            print("%s/%s， best obj: %s" % (ep, self.epochs, self.best_sol.objective))

        self.plotObj(history_best_obj)
        self.plotSoln(self.best_sol)
