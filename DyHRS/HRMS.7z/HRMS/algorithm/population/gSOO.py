from abc import ABC
import random
import numpy as np
import matplotlib.pyplot as plt
from HRMS.algorithm.base import Algorithm
from HRMS.model import Solution
from HRMS.model.entities import *
from HRMS.model.operators import *


class gSOO(Algorithm, ABC):

    def __init__(self, problem, popsize, epochs):

        self.problem = problem
        self.best_sol = None
        self.sol_list = []

        self.epochs = epochs
        self.popsize = popsize

        self.nodes = [s.idx for s in self.problem.released_slabs]
        self.node_count = len(self.nodes)

    def plotSoln(self, bestSol: Solution):
        plt.rcParams['font.sans-serif'] = ['SimHei']  # show chinese
        plt.rcParams['axes.unicode_minus'] = False  # Show minus sign

        clrs1 = generate_color_list(7, 'Reds')
        clrs2 = generate_color_list(7, 'Blues')
        x = 0
        r = 0
        for rod in self.problem.round_list:
            r = r + 1
            for slab in rod.slab_list:
                x = x + 1
                y1 = 0 - slab.width / 4
                y2 = 0 + slab.width / 4
                if slab.status == 2:
                    plt.plot([x, x], [y1, y2], color='k', linewidth=slab.gauge * 2)
                else:
                    hrdn = int(slab.hardness)
                    if r % 2 == 0:
                        plt.plot([x, x], [y1, y2], color=clrs1[hrdn], linewidth=slab.gauge/100)
                    else:
                        plt.plot([x, x], [y1, y2], color=clrs2[hrdn], linewidth=slab.gauge/100)

        plt.xlabel('slabs')
        plt.ylabel('width')
        plt.grid()
        plt.xlim(1, x)
        plt.show()

    def plotObj(self, obj_list):
        plt.rcParams['font.sans-serif'] = ['SimHei']  # show chinese
        plt.rcParams['axes.unicode_minus'] = False  # Show minus sign
        plt.plot(np.arange(1, len(obj_list) + 1), obj_list)
        plt.xlabel('Iterations')
        plt.ylabel('Obj Value')
        plt.grid()
        plt.xlim(1, len(obj_list) + 1)
        plt.show()
