import time

import pandas as pd
import math
import random
import numpy as np
import copy
import xlsxwriter
import matplotlib.pyplot as plt

from HRMS.algorithm.population.gSOO import gSOO
from HRMS.model.entities import Problem


class DQPSO(gSOO):

    def __init__(self, problem: Problem, popsize, epochs):

        super().__init__(problem, popsize, epochs)
        self.pl = []
        self.pg = None
        self.mg = None
        self.alpha = 1.0

    def name(self):
        return 'discrete quantum particle swarm optimization'

    def initialize(self):
        node_seq = copy.deepcopy(self.node_seq_list)
        best_sol = Solution(self.problem)
        mg = [0] * self.node_count
        for i in range(self.popsize):
            seed = int(random.randint(0, 10))
            random.seed(seed)
            random.shuffle(node_seq)
            sol = Solution(self.problem)
            sol.slab_no_seq = copy.deepcopy(node_seq)
            sol.evaluate
            self.sol_list.append(sol)
            # init the optimal position of each particle
            self.pl.append(sol)
            # init the average optimal position of particle population
            mg = [mg[k] + node_seq[k] / self.popsize for k in range(self.node_count)]
            # init the optimal position of particle population
            if sol.objective < best_sol.objective:
                best_sol = copy.deepcopy(sol)
        self.best_sol = best_sol
        self.pg = best_sol.slab_no_seq
        self.mg = mg

    def adjustRoutes(self, nodes_seq):
        all_node_list = copy.deepcopy(self.node_seq_list)
        repeat_node = []
        for id, node_no in enumerate(nodes_seq):
            if node_no in all_node_list:
                all_node_list.remove(node_no)
            else:
                repeat_node.append(id)
        for i in range(len(repeat_node)):
            nodes_seq[repeat_node[i]] = all_node_list[i]
        return nodes_seq

    def updatePosition(self):
        alpha = self.alpha
        pg = self.pg
        mg = self.mg
        mg_ = [0] * self.node_count  # update optimal position of each particle for next iteration
        for id, sol in enumerate(self.sol_list):
            x = sol.slab_no_seq
            pl = self.pl[id].slab_no_seq
            pi = []
            for k in range(self.node_count):  # calculate pi(ep+1)
                phi = random.random()
                pi.append(phi * pl[k] + (1 - phi) * pg[k])
            # calculate x(ep+1)
            if random.random() <= 0.5:
                X = [min(int(pi[k] + alpha * abs(mg[k] - x[k]) * math.log(1 / random.random())),
                         self.node_count - 1)
                     for k in range(self.node_count)]
            else:
                X = [min(int(pi[k] - alpha * abs(mg[k] - x[k]) * math.log(1 / random.random())),
                         self.node_count - 1)
                     for k in range(self.node_count)]

            X = self.adjustRoutes(X)

            new_sol = Solution(self.problem)
            new_sol.slab_no_seq = X
            new_sol.evaluate
            self.sol_list[id] = new_sol

            if new_sol.objective < self.pl[id].objective:
                self.pl[id] = copy.deepcopy(new_sol)
            if new_sol.objective < self.best_sol.objective:
                self.best_sol = copy.deepcopy(new_sol)
                self.pg = copy.deepcopy(X)

            mg_ = [mg_[k] + self.pl[id].slab_no_seq[k] / self.popsize for k in range(self.node_count)]
            self.sol_list[id] = new_sol
        # update mg
        self.mg = copy.deepcopy(mg_)

    def execute(self):

        history_best_obj = [self.best_sol.objective]
        for ep in range(self.epochs):
            self.updatePosition()
            history_best_obj.append(self.best_sol.objective)
            print("%s/%s: best obj: %s" % (ep, self.epochs, self.best_sol.objective))
        plotObj(history_best_obj)
        self.plotSoln(self.best_sol)


