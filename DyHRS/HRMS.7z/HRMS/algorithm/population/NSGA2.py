import copy
import itertools
import time

import pandas as pd
import math
import random
import numpy as np
from abc import ABC
import random
import numpy as np
import matplotlib.pyplot as plt
from HRMS.algorithm.base import Algorithm
from HRMS.model.Solution import Solution
from HRMS.algorithm.population.gMOO import gMOO
from HRMS.model.entities import *


# Liu L L, Wan X, Gao Z, et al. Research on modelling and optimization of hot rolling scheduling[J]. Journal of
# ambient intelligence and humanized computing, 2019, 10(3): 1201-1216.

# Mańdziuk J, Żychowski A. A memetic approach to vehicle routing problem with dynamic requests[J]. Applied Soft
# Computing, 2016, 48: 522-534.


class NSGA2(gMOO, ABC):
    def __init__(self, problem: Problem, popsize, epochs):
        super().__init__(problem, popsize, epochs)
        self.pc = 1.0
        self.pm = 0.05

    def name(self):
        return 'NSGA-II'

    def initialize(self):

        super().initialize()
        for sol in self.sol_list:
            sol.evaluate_rui()
        fronts, ranks = self.fast_non_dominated_sorting(self.sol_list)
        sort_idx = self.calculate_crowding_distance(fronts, ranks)
        self.sol_list = [self.sol_list[i] for i in sort_idx[0:self.P_size]]
        self.EAP = [self.sol_list[i] for i in fronts[0]]
        self.update_ideal_distance()
        print("epoch=", 0, " EAP size=", len(self.EAP))

    def selectSol(self, sol_sols):
        p1 = random.randint(0, len(sol_sols) - 1)
        p2 = p1
        while p1 == p2:
            p2 = random.randint(0, len(sol_sols) - 1)
        return p1, p2

    #  PMX Crossover
    def crossSol(self, sel_sols):
        offspring = []
        while len(offspring) < self.P_size:
            # 1.选择个体
            p1, p2 = self.selectSol(sel_sols)
            old_seq1 = copy.deepcopy(self.sol_list[p1].node_seq)
            old_seq2 = copy.deepcopy(self.sol_list[p2].node_seq)

            # 2.交换片段
            left = int(random.randint(self.fixed_cnt, self.cand_cnt - 5))
            right = int(random.randint(left + 1, self.fixed_cnt + self.cand_cnt - 1))
            new_seq1 = copy.deepcopy(old_seq1)
            new_seq2 = copy.deepcopy(old_seq2)

            new_seq1[left:right] = old_seq2[left:right]
            new_seq2[left:right] = old_seq1[left:right]

            # 3.消除重复基因
            map1 = dict(zip(new_seq1[left:right], new_seq2[left:right]))
            map2 = dict(zip(new_seq2[left:right], new_seq1[left:right]))

            for i in range(self.fixed_cnt, left):
                s1 = new_seq1[i]
                if s1 not in map1.keys():
                    continue
                while s1 in map1.keys():
                    d1 = map1[s1]
                    s1 = d1
                new_seq1[i] = d1
            for i in range(self.fixed_cnt, left):
                s2 = new_seq2[i]
                if s2 not in map2.keys():
                    continue
                while s2 in map2.keys():
                    d2 = map2[s2]
                    s2 = d2
                new_seq2[i] = d2

            for i in range(right, self.cand_cnt + self.fixed_cnt):
                s1 = new_seq1[i]
                if s1 not in map1.keys():
                    continue
                while s1 in map1.keys():
                    d1 = map1[s1]
                    s1 = d1
                new_seq1[i] = d1
            for i in range(right, self.cand_cnt + self.fixed_cnt):
                s2 = new_seq2[i]
                if s2 not in map2.keys():
                    continue
                while s2 in map2.keys():
                    d2 = map2[s2]
                    s2 = d2
                new_seq2[i] = d2

            offspring.append(Solution(self.problem, new_seq1))
            offspring.append(Solution(self.problem, new_seq2))
        return offspring

    # Order Crossover (PMX), 为下次 knowledge-based MOEA 准备
    def crossover(self):
        sol_list = copy.deepcopy(self.sol_list)
        offspring = []
        while True:
            p1_index = random.randint(0, len(sol_list) - 1)
            p2_index = random.randint(0, len(sol_list) - 1)
            if p1_index == p2_index:
                continue
            p1: Solution = copy.deepcopy(sol_list[p1_index])
            p2: Solution = copy.deepcopy(sol_list[p2_index])
            if random.random() >= self.pc:
                offspring.append(p1)
                offspring.append(p2)
                continue
            # 选择： 可以选择最小的 route
            r1 = random.randint(0, len(p1.subtours) - 1)
            r2 = random.randint(0, len(p2.subtours) - 2)
            # 交换： 各自的route
            p1.subtours[r1] = copy.deepcopy(p2.subtours[r2])
            p2.subtours[r2] = copy.deepcopy(p1.subtours[r1])
            # 消除重复项目
            in_list1 = p1.subtours[r1]
            for r, tour in enumerate(p1.subtours):
                if r == r1:
                    continue
                for rr in range(len(tour)):
                    if tour[rr] in p1.subtours[r1]:
                        tour[rr] = -1
                    else:
                        in_list1.append(tour[rr])
            in_list2 = p2.subtours[r2]
            for r, tour in enumerate(p2.subtours):
                if r == r2:
                    continue
                for rr in range(len(tour)):
                    if tour[rr] in p2.subtours[r2]:
                        tour[rr] = -1
                    else:
                        in_list2.append(tour[rr])
            # 补充空缺项目
            x1 = list(set(p1.node_seq) - set(in_list1))
            p1.node_seq = []
            for k in range(len(p1.subtours)):
                tour = p1.subtours[k]
                for rr in range(len(tour)):
                    if tour[rr] < 0:
                        tour[rr] = x1[0]
                        x1.pop(0)
                p1.node_seq.extend([s for s in tour if s > 0])
            x2 = list(set(p2.node_seq) - set(in_list2))
            for k in range(len(p2.subtours)):
                tour = p2.subtours[k]
                for rr in range(len(tour)):
                    if tour[rr] < 0:
                        tour[rr] = x2[0]
                        x2.pop(0)
                p1.node_seq.extend([s for s in tour if s > 0])

            if len(offspring) >= self.P_size:
                break
        return offspring

    # mutation
    def muSol(self, sol_list):
        for sol in sol_list:
            for i1, i2 in itertools.product(range(self.fixed_cnt, self.fixed_cnt + self.cand_cnt - 1),
                                            range(self.fixed_cnt, self.fixed_cnt + self.cand_cnt - 1)):
                if i1 != i2 and random.random() <= self.pm:
                    tmp = sol.node_seq[i1]
                    sol.node_seq[i1] = sol.node_seq[i2]
                    sol.node_seq[i2] = tmp

    def execute(self):
        t1 = time.perf_counter()
        ep = 1
        while True:
            offspring = self.crossSol(self.sol_list)
            self.muSol(offspring)
            for s in offspring:
                s.evaluate_rui()
            self.sol_list.extend(offspring)
            fronts, ranks = self.fast_non_dominated_sorting(self.sol_list)
            sort_idx = self.calculate_crowding_distance(fronts, ranks, self.sol_list)
            self.EAP = [self.sol_list[i] for i in fronts[0]]
            self.sol_list = [self.sol_list[i] for i in sort_idx[0:self.P_size]]
            self.update_ideal_distance()
            print("epoch=", ep + 1, " EAP size=", len(self.EAP))
            ep = ep + 1
            t2 = time.perf_counter()
            if t2 - t1 > self.budget:
                break
        t2 = time.perf_counter()
        print(f'cost= {t2 - t1:.8f}s')

        # self.find_best_soln()
        # self.plot_frontier(2)
        # self.output()
        # self.plotSoln(self.best_soln)
