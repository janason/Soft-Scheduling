import math
import time
import random
import numpy as np

from HRMS.model.Solution import *
from HRMS.algorithm.population.gMOO import gMOO
from HRMS.model.entities import *
from HRMS.model.operators import *
import itertools


# Jia S J, Yi J, Yang G K, et al. A multi-objective optimisation algorithm for the hot rolling batch scheduling
# problem[J]. International Journal of Production Research, 2013, 51(3): 667-681.

#

class mACOp(gMOO):

    def __init__(self, problem, popsize, epochs):

        super().__init__(problem, popsize, epochs)

        self.history_best_obj = None

        self.G_size = OBJ_CNT
        self.Group = []  # 蚂蚁的G个分组
        self.ant_2_grp = []

        N = 0
        self.ant_2_grp = []
        for g in range(self.G_size):
            ng = int(popsize / OBJ_CNT)
            self.Group.append([N + i for i in range(ng)])
            self.ant_2_grp.extend([g] * ng)
            N += ng
        if N < popsize:
            self.Group[-1].append(N)
            self.ant_2_grp.append(self.G_size - 1)

        self.W = [1.0, 0.0]

        self.costs = {}
        self.alpha = 1
        self.beta = 2
        self.Q = 10
        self.rho = 0.05
        self.tau = {}  # 信息素
        self.eta = {}  # 启发因子

        self.tau_min = math.inf
        self.tau_max = -math.inf

        self.allow_list = {}  # tabu list for node

        print('initialization')

    def name(self):
        return "mACOp"

    def initialize(self):
        super().initialize()
        self.sol_list.clear()
        self.allow_list = {i: [] for i in [0] + self.fixed_idx + self.cand_idx}  # allow list for all nodes

        # initialize allow_list
        for i1 in self.fixed_idx + self.cand_idx:
            self.allow_list[0].append(i1)
            s1: Slab = self.problem.get_slab(i1)
            for i2 in self.fixed_idx + self.cand_idx:
                if i1 == i2:
                    continue
                s2: Slab = self.problem.get_slab(i2)
                if s1.width == s2.width or s1.hardness == s2.hardness or s1.gauge == s2.gauge:  # 不允许同时跳变
                    if s1.width >= s2.width:
                        self.allow_list[i1].append(i2)

        # initialize Tau
        for i, j, g in itertools.product([0] + self.fixed_idx + self.cand_idx,
                                         self.fixed_idx + self.cand_idx, range(self.G_size)):
            if i == j:
                continue
            self.tau[i, j, g] = 1.0

        # initialize costs
        for i in self.fixed_idx + self.cand_idx:
            self.costs[0, i, 0] = 1.0
            self.costs[0, i, 1] = self.problem.get_slab(i).length
            for j in self.fixed_idx + self.cand_idx:
                if i == j:
                    continue
                self.costs[i, j, 0] = self.problem.dist_matrix[i, j]
                self.costs[i, j, 1] = self.problem.get_slab(j).length

        # initialize eta
        for i, j in itertools.product(self.fixed_idx + self.cand_idx, self.fixed_idx + self.cand_idx):
            if i != j:
                self.eta[i, j] = 1.0 / (self.costs[i, j, 0] + 1)

        return

    def selectFirstNode(self, SE_List):
        to_select = []
        for i, node_no in enumerate(SE_List):
            slab: Slab = self.problem.get_slab(node_no)
            to_select.append((node_no, slab.width))
        to_select.sort(key=lambda x: x[1], reverse=True)
        next_node_no = to_select[0][0]
        return next_node_no

    def selectNextNode(self, current_node_no, SE_List, dyn_constr, Tau, Eta):  # lw, LW, current_node_no, SE_List):
        # 获得可选列表
        candidates = list(set(self.allow_list[current_node_no]).intersection(set(SE_List)))
        sel_list = []
        # 同宽约束
        for id in candidates:
            salb: Slab = self.problem.get_slab(id)
            if dyn_constr[0][0] + salb.length <= dyn_constr[0][1] \
                    and dyn_constr[1][0] - salb.length > dyn_constr[1][1]:
                sel_list.append(id)
        if len(sel_list) == 0:
            return -1

        prob = np.zeros(len(sel_list))
        for i, next_node_no in enumerate(sel_list):
            eta = self.eta[current_node_no, next_node_no]
            tau = 0
            for g in range(self.G_size):
                tau += self.tau[current_node_no, next_node_no, g] * self.W[g]
            prob[i] = ((tau ** self.alpha) * (eta ** self.beta))
        # use Roulette to determine the next node
        cumsumprob = (prob / sum(prob)).cumsum()
        cumsumprob -= np.random.rand()
        next_node_no = sel_list[list(cumsumprob > 0).index(True)]
        return next_node_no

    def upateTau(self):
        for i, j, k in self.tau.keys():
            tau = (1 - self.rho) * self.tau[i, j, k]
            f_best = math.inf
            d_tau = 0
            for sol in self.EAP:
                if sol.is_exist_path(i, j):
                    d_tau = len(sol.subtours) / sol.objectives[k]
                if sol.objectives[k] < f_best:
                    f_best = sol.objectives[k]
            tau += d_tau
            tau_max = 1 / self.rho * self.problem.round_number / f_best
            if tau > tau_max:
                tau = tau_max
            tau_min = tau_max / 10
            if tau < tau_min:
                tau = tau_min
            self.tau[i, j, k] = tau

    def execute(self):
        t1 = time.perf_counter()
        ep = 1
        self.epoch = ep
        while True:
            self.epoch = ep
            # solution construction and update external archive population
            ants = []
            for k in range(self.P_size):
                sol = Solution(self.problem, nodes=[], fixed_idx=self.fixed_idx)
                sol.evaluate_aco(self.selectFirstNode, self.selectNextNode)
                ants.append(sol)
            # update external archive
            self.update_archive(ants)
            self.update_ideal_distance()
            # update Pheromone matrices
            self.upateTau()
            self.sol_list = [ant for ant in ants]
            print("%s/%s， size of EAP: %s" % (ep, self.epochs, len(self.EAP)))
            ep = ep + 1
            t2 = time.perf_counter()
            if t2 - t1 > self.budget:
                break

        t2 = time.perf_counter()
        print(f'cost= {t2 - t1:.8f}s')



    def output(self):
        super(mACOp, self).output()
        # if self.best_soln is None:
        #     return
        # self.problem.fixed_slabs.clear()
        # for id in self.best_soln.node_seq:
        #     slab = self.problem.get_slab(id)
        #     self.problem.fixed_slabs.append(slab)
        # for r, tour in enumerate(self.best_soln.routes):
        #     self.problem.round_list[r].reset()
        #     for id in tour:
        #         slab = self.problem.get_slab(id)
        #         self.problem.round_list[r].slab_list.append(slab)
        # print(self.problem)
