import random

from sklearn.cluster import KMeans
from sklearn.ensemble import GradientBoostingRegressor
from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.gaussian_process.kernels import RBF, ConstantKernel
from sklearn.metrics import mean_squared_error, mean_absolute_percentage_error

from HRMS.model.entities import *
from sklearn import svm


class Learner:

    def __init__(self, tau: dict, problem: Problem):
        self._tau = tau
        self._problem = problem
        self._model = None
        self._labels = None
        return

    # 使用GP
    def learning(self):
        X = []
        y = []
        for k, v in self._tau.items():
            if k[0] == 0:
                s2: Slab = self._problem.get_slab(k[1])
                x = [s2.width, s2.gauge, s2.hardness, 0, s2.price]
            else:
                s1: Slab = self._problem.get_slab(k[0])
                s2: Slab = self._problem.get_slab(k[1])
                x = [s2.width - s1.width, s2.gauge - s1.gauge, s2.hardness - s1.hardness, s1.price, s2.price]
            X.append(x)
            y.append(v)

        # kernel = RBF() + ConstantKernel(constant_value=0.01)
        #
        # gp = GaussianProcessRegressor(kernel=kernel, alpha=5, random_state=0).fit(X, y)
        # print(gp.score(X, y))
        # regr = svm.SVR(kernel='rbf')
        # regr.fit(X, y)
        # z1 = mean_absolute_percentage_error(y[0:100], regr.predict(X[0: 100]))
        # print(z1)
        #
        # est = GradientBoostingRegressor(random_state=0).fit(X, y)
        # z2 = mean_absolute_percentage_error(y[0:100], est.predict(X[:100]))
        # print(z2)
        #
        # xgb = xgboost.XGBRegressor(seed=1850)
        # xgb.fit(X, y, verbose=True)
        # z3 = mean_absolute_percentage_error(y[0:100], xgb.predict(X[:100]))
        # print(z3)

        self._model = KMeans(init="k-means++", n_clusters=30)
        z = self._model.fit(X).labels_.tolist()

        self._labels = list(zip(z, y))

        return self._model, self._labels

    def predict(self, x):
        if self._model is None:
            return None
        lbl = self._model.predict(x)
        tau0 = [y for z, y in self._labels if z == lbl[0]]
        if len(tau0) > 10:
            n = 10
        else:
            n = len(tau0)
        tau1 = random.sample(tau0, n)
        return sum(tau1)/n

