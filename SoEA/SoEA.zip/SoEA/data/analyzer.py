import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import statsmodels.api as sm
from statsmodels.formula.api import ols
from statsmodels.stats.multicomp import MultiComparison
import matplotlib as mpl
from mpl_toolkits.mplot3d import Axes3D
import numpy as np
import matplotlib.pyplot as plt
from pymoo.factory import get_performance_indicator
from scipy import stats


def ANOVA1(df, xname, yname):

    fig = plt.figure()
    fig.set_size_inches(4, 4)
    sns.set(font_scale=1)
    print('-------------------------' + yname + '---------------------------------')
    df_melt = pd.melt(df.reset_index(), id_vars=['index'])
    df_melt.columns = ['index', 'Levels', yname]

    model = ols(yname + ' ~ C(Levels)', data=df_melt).fit()
    anova_table = sm.stats.anova_lm(model, typ=1)
    print(anova_table)

    mc = MultiComparison(df_melt[yname], df_melt['Levels'])
    tukey_result = mc.tukeyhsd()
    print(tukey_result)

    sns.set_style('ticks', {'axes.edgecolor': '0',
                            'xtick.color': '0',
                            'ytick.color': '0'})
    ax = sns.boxplot(x='Levels', y=yname, data=df_melt, width=0.50, fliersize=3, linewidth=1,color='white')
    # sns.swarmplot(x='Levels', y=yname, data=df_melt,palette="vlag")
    plt.xlabel(xname, y=-0.28, fontsize=13)
    plt.ylabel(yname, fontsize=12)
    plt.subplots_adjust(wspace=0.20)
    plt.tick_params(labelsize=10)

    for i, box in enumerate(ax.artists):
        box.set_edgecolor('k')
        box.set_facecolor('w')

        # iterate over whiskers and median lines
        # for j in range(6 * i, 6 * (i + 1)):
        #     ax.lines[j].set_color('black')
    plt.setp(ax.artists, edgecolor='k', facecolor='w')
    plt.setp(ax.lines, color='k')

    plt.show()


def plot_curve(df, xlbl, ylbl, keys):
    sns.set_style("ticks")
    plt.figure(figsize=(4, 3))
    #sns.set_theme(style="darkgrid")

    for i in range(1, len(keys)):
        if i%2 == 0:
            sns.lineplot(data=df, x=keys[0], y=keys[i], marker="o", markersize=8,
                         label='$3\\times$5', dashes=True, lw=1.2,color='k')
        else:
            sns.lineplot(data=df, x=keys[0], y=keys[i], marker="s", markersize=7,
                         label='$3\\times$10', dashes=False, lw=1.2,color='k')

    plt.legend(prop={'size': 10.5})
    plt.tick_params(axis='both', which='major', labelsize=10.5, pad=0)
    plt.xlabel(xlbl, fontsize=12, labelpad=1)
    plt.ylabel(ylbl, fontsize=11, labelpad=0)

    plt.show()


if __name__ == "__main__":
    file_name = 'data.xlsx'
    df = pd.read_excel(io=file_name, sheet_name='Sheet1')
    plot_curve(df, 'level', 'RPD', ['Level', '3x5', '3x10'])
    sheet_name = ['RPD', 'CPU']
    data = {}
    for i in range(len(sheet_name)):
        df = pd.read_excel(io=file_name, sheet_name=sheet_name[i])
        ANOVA1(df, 'Algorithm', sheet_name[i])
