import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import statsmodels.api as sm
from statsmodels.formula.api import ols
from statsmodels.stats.multicomp import MultiComparison
import matplotlib as mpl
from mpl_toolkits.mplot3d import Axes3D
import numpy as np
import matplotlib.pyplot as plt
from pymoo.factory import get_performance_indicator
from scipy import stats

file_name = 'data.xlsx'
df = pd.read_excel(io=file_name, sheet_name='Sheet1')

plt.figure(figsize=(6, 3.2))
sns.set_theme(style="darkgrid")
sns.lineplot(data=df, x="Level", y="RPV1", marker="o", markersize=8, dashes=False, lw=1.2)
sns.lineplot(data=df, x="Level", y="RPV2", marker="s", markersize=8, dashes=False, lw=1.2)

# x = df['Level'].values.tolist()
# y = df['RPV'].values.tolist()
# z = df['Obj'].values.tolist()
# XY = list(zip(x, y))
# for i in range(len(XY)):
#     xy = XY[i]
#     plt.annotate(z[i], xy=xy, xytext=(-20, 8), textcoords='offset points')


plt.legend(prop={'size': 10.5})
# plt.tick_params(labelsize=10.5)
plt.tick_params(axis='both', which='major', labelsize=10.5, pad=0)
plt.xlabel("Level", fontsize=11, labelpad=0.5)
plt.ylabel("RPV(%)", fontsize=10.5, labelpad=0)
plt.show()