import sqlite3
import matplotlib.pyplot as plt
import seaborn as sns
import matplotlib as mpl
import pandas as pd
import networkx as nx
from model.entities import *


class Problem:
    def __init__(self, name):
        self.name = name
        self.batches = {}
        self.jobs = {}
        self.operations = {}
        self.stages = {}
        self.machines = {}

        self.alpha = {1: 0.125, 2: 0.25, 3: 0.5, 4: 1.0}
        self.noise_level = {1: 0.1, 2: 0.2, 3: 0.2, 4: 0.0}
        self.q_in_stage = {1: 20.0, 2: 4.0, 3: 8.0, 4: 5.0}
        # self.q_in_stage = {1: 1.0, 2: 1.0, 3: 1.0}
        self.f_dim = 1
        self.Q_max = 1000
        self.risk_level = 0.00
        self.obj_bound = 0

        return

    def __repr__(self):
        return f"instance: {self.name}"

    def read_instance(self):
        fname = self.name[0:self.name.rfind('_', 0)]
        dname = f"..//data//{fname}.db"
        conn = sqlite3.connect(dname)
        # conn = sqlite3.connect("..//data//RoSCC_3423.db")
        print("Opened database successfully")
        cur = conn.cursor()
        ds = cur.execute("select stage_id, trans_time from mbd_stage_info order by rowid asc")
        for row in ds:
            idx = int(row[0])
            stage = Stage(idx)
            trans = row[1].split(';')
            for tt in trans:
                gt = tt.split(':')
                if len(gt) > 1:
                    stage.add_transfer(int(gt[0]), int(gt[1]))
            self.stages[idx] = stage

        cur = conn.cursor()
        ds = cur.execute("select machine_id, stage_id from mbd_machine_info order by rowid asc")
        for row in ds:
            idx = int(int(row[0]) / 10), int(row[0]) % 10
            idy = int(row[1])
            machine = Machine(idx, self.stages[idy])
            self.machines[idx] = machine

        ds = cur.execute(
            "select batch_id, setup_time,ma_planned from sch_batch_info where instance_id = '"
            + self.name + "' order by rowid asc")
        for row in ds:
            idx = int(row[0].split('_')[1])
            batch = Batch(idx)
            batch.setup_time = row[1]
            idk = int(int(row[2]) / 10), int(row[2]) % 10
            batch.dest_machine = self.machines[idk]
            self.batches[idx] = batch

        ds = cur.execute(
            "select job_id, batch_id from sch_job_info where instance_id = '"
            + self.name + "' order by rowid asc")

        for row in ds:
            idx = int(row[0].split('_')[1])
            idy = int(row[1].split('_')[1])
            job = Job(idx, self.batches[idy])
            self.jobs[idx] = job

        ds = cur.execute(
            "select operation_id, realized_pt, stage_id, job_id,   machine_id, start_time, end_time, ma_tt_list, "
            "prev_stage_oper, next_stage_oper from sch_operation_info where instance_id = '" + self.name
            + "' order by operation_id")
        for row in ds:
            idx = int(row[0].split('_')[1]), int(row[0].split('_')[2])
            pt = int(row[1].split('|')[1])
            stage = self.stages[int(row[2])]
            job = self.jobs[int(row[3].split('_')[1])]
            mt = int(row[7].split(',')[0])
            oper = Operation(idx, pt, mt, stage, job)
            if len(row[4]) > 1:
                idm = int(int(row[4]) / 10), int(row[4]) % 10
                oper.machine = self.machines[idm]
                oper.start_time = row[5]
            self.operations[idx] = oper
            self.obj_bound += pt + mt

        ds = cur.execute(
            "select operation_id, realized_pt, stage_id, job_id,   machine_id, start_time, end_time, ma_tt_list, "
            "prev_stage_oper, next_stage_oper from sch_operation_info where instance_id = '" + self.name
            + "' order by operation_id")
        for row in ds:
            ido = int(row[0].split('_')[1]), int(row[0].split('_')[2])
            oper = self.operations[ido]

            if row[8].strip() != '':
                idv = int(row[8].split('_')[1]), int(row[8].split('_')[2])
                oper.prev_oper = self.operations[idv]
            if row[9].strip() != '':
                idx = int(row[9].split('_')[1]), int(row[9].split('_')[2])
                oper.next_oper = self.operations[idx]

        print('Reading problem is OK')

    def reset(self):
        for mach in self.machines.values():
            mach.operations.clear()
        for oper in self.operations.values():
            oper.machine = None
            oper.start_time = -1

    def get_last_stage(self):
        sortedKeys = sorted(self.stages.keys())
        return self.stages[sortedKeys[-1]]

    def get_in_graph(self):
        G = nx.DiGraph()
        nodes = [op.tag for op in self.operations.values()]
        nodes.insert(0, (0, 0))
        G.add_nodes_from(nodes)

        last_stage = self.stages['4']
        I = len(self.stages)
        for ma in self.machines.values():
            for r, op in enumerate(ma.operations):
                i, j = op.tag
                if i == 1:
                    G.add_edge((0, 0), (i, j), w=0)  # 到达时间暂时默认为 0
                elif i < I:
                    ix, j = op.next_oper.tag
                    G.add_edge((i, j), (ix, j), w=op.duration + op.time_to_next)
                if i < I and r < len(ma.operations) - 1:
                    i, jx = ma.operations[r + 1].tag
                    G.add_edge((i, j), (i, jx), w=op.duration)
                else:
                    bh = op.job.batch.tag

        print(G)

    def save_to_db(self):
        conn = sqlite3.connect(".//data1//DMOP_3423.db")
        print("Opened database successfully")
        cur = conn.cursor()
        for op in self.operations.values():
            sql = 'update sch_operation_info set start_time={} ,end_time= {}  where instance_id = \'{}\' ' \
                  'and  operation_id = \'{}\''.format(op.start_time, op.end_time, self.name, op.id)
            cur.execute(sql)
        conn.commit()
        conn.close()
        print("Update database successfully")

    def show_in_gantt(self):

        # 1. 绘图参数
        HKeys = list(sorted(self.batches.keys()))
        MKeys = list(reversed(sorted(self.machines.keys())))

        bar_style = {'alpha': 1.0, 'lw': 12, 'solid_capstyle': 'butt'}
        text_style = {'color': 'white', 'weight': 'bold', 'ha': 'center', 'va': 'center', 'fontsize': 8}
        colors = mpl.cm.Dark2.colors

        # 2. 绘图布局
        sns.set_theme(style="darkgrid")
        rect1 = [0.04, 0.31, 0.96, 0.68]  # [左, 下, 宽, 高] 规定的矩形区域 （全部是0~1之间的数，表示比例）
        rect2 = [0.04, 0.05, 0.96, 0.25]
        ax1 = plt.axes(rect1)
        ax2 = plt.axes(rect2)

        # 2. 绘图数据
        Tmax = 0
        for oper in self.operations.values():
            mid = oper.machine.id
            ym = MKeys.index(mid) + 1
            xs = oper.start_time
            xf = oper.end_time
            hi = HKeys.index(oper.job.batch.id)
            txt = str(oper.job.id) + ' :' + str(xs) + '-' + str(xf)
            ax1.plot([xs, xf], [ym] * 2, c=colors[hi % 7], **bar_style)
            ax1.text((xs + xf) / 2, ym - 0.03, txt, **text_style)
            if oper.end_time > Tmax:
                Tmax = oper.end_time
        WLoad = [0] * Tmax
        for oper in self.operations.values():
            xs = oper.start_time
            xf = oper.end_time
            for x in range(xs, xf, 1):
                # WLoad[x] += 1 * self.q_in_stage[oper.stage.id]
                WLoad[x] += 1

        # 3. 坐标轴
        ax1.set_ylabel('machine')
        ax1.set_ylim(0.5, len(MKeys) + 0.5)
        ax1.set_yticks(range(1, 1 + len(MKeys)))
        MLbls = []
        for i, k in MKeys:
            lbl = '$M_{' + str(i) + ',' + str(k) + '}$'
            MLbls.append(lbl)
        ax1.set_yticklabels(MLbls)

        ax1.text(Tmax, ax1.get_ylim()[0] + 6.6, "{0:0.0f}".format(Tmax), ha='center', va='top')
        ax1.plot([Tmax] * 2, ax1.get_ylim(), 'r--')
        ax1.grid(True)
        ax1.set_xlim(0, (round(Tmax / 10) + 1) * 10)
        ax2.set_xticklabels([])

        ax2.set_ylabel('workload')
        ax2.plot(WLoad, label="all", color='b')
        ax2.plot([Tmax] * 2, [0, round(max(WLoad) + 1)], 'r--')
        ax2.plot([0, Tmax], [self.Q_max] * 2, 'g--')
        ax2.grid(True)
        ax2.set_xlim(0, (round(Tmax / 10) + 1) * 10)
        ax2.set_ylim(0, round(max(WLoad) + 1))
        ax2.set_yticks(range(0, round(max(WLoad) + 1), 1))
        ax2.set_yticklabels(range(0, round(max(WLoad) + 1), 1))

        # 4.显示
        plt.get_current_fig_manager().window.showMaximized()
        plt.show()
