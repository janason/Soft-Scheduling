
class Entity(object):
    def __init__(self, idx):
        self.__idx = idx

    # @property
    # def tag(self):
    #     return self.__tag

    @property
    def id(self):
        return self.__idx

    @property
    def problem(self):
        return self.__problem

    def __repr__(self):
        return f": {self.__idx}"


class Batch(Entity):
    def __init__(self, idx):
        # tag = int(idx.split('_')[1])
        super(Batch, self).__init__(idx)
        self.__jobs = []
        self.__setup_time = 0
        self.__dest_machine = None

    @property
    def jobs(self):
        return self.__jobs

    @property
    def setup_time(self):
        return self.__setup_time

    @setup_time.setter
    def setup_time(self, value):
        self.__setup_time = value

    @property
    def dest_machine(self):
        return self.__dest_machine

    @dest_machine.setter
    def dest_machine(self, value):
        self.__dest_machine = value

    def add_job(self, job):
        self.__jobs.append(job)


class Job(Entity):
    def __init__(self, idx, batch):
        # tag = (int(idx.split('_')[1]), batch.id, len(batch.jobs) + 1)
        super(Job, self).__init__(idx)
        batch.add_job(self)
        self.__batch = batch
        self.__operations = {}

    @property
    def batch(self):
        return self.__batch

    @property
    def operations(self):
        return self.__operations

    def add_operation(self, operation):
        self.__operations[operation.id] = operation


class Operation(Entity):
    def __init__(self, idx, pt, mt, stage, job):
        #tag = int(idx.split('_')[1]), int(idx.split('_')[2])
        super(Operation, self).__init__(idx)
        self.__job = job
        self.__PT = pt
        self.__stage = stage
        self.__time_to_next = mt
        self.__prev_oper = None
        self.__next_oper = None
        self.__machine = None
        self.__start_time = -1
        self.__end_time = -1
        self.__job.add_operation(self)
        self.__stage.add_operation(self)

    @property
    def job(self):
        return self.__job

    @property
    def stage(self):
        return self.__stage

    @property
    def prev_oper(self):
        return self.__prev_oper

    @property
    def next_oper(self):
        return self.__next_oper

    @property
    def machine(self):
        return self.__machine

    @machine.setter
    def machine(self, value):
        self.__machine = value
        self.__machine.add_operation(self)

    @property
    def duration(self):
        return self.__PT

    @property
    def start_time(self):
        return self.__start_time

    @property
    def end_time(self):
        return self.__start_time + self.__PT

    @property
    def time_to_next(self):
        return self.__time_to_next

    @machine.setter
    def machine(self, value):
        self.__machine = value
        if not value is None:
            self.__machine.add_operation(self)

    @start_time.setter
    def start_time(self, value):
        self.__start_time = value

    @prev_oper.setter
    def prev_oper(self, value):
        self.__prev_oper = value

    @next_oper.setter
    def next_oper(self, value):
        self.__next_oper = value


class Machine(Entity):
    def __init__(self, idx, stage):
        # tag = int(int(idx) / 10), int(idx) % 10
        super(Machine, self).__init__(idx)
        self.__operations = []
        self.__stage = stage
        self.__stage.add_machine(self)

    @property
    def operations(self):
        self.__operations.sort(key=lambda x: x.start_time)
        return self.__operations

    @property
    def stage(self):
        return self.__stage

    def add_operation(self, operation: Operation):
        self.__operations.append(operation)





class Stage(Entity):

    def __init__(self, idx):
        tag = int(idx),
        super(Stage, self).__init__(idx)
        self.__machines = {}
        self.__transfers = {}
        self.__operations = {}
        return

    @property
    def machines(self):
        return self.__machines

    @property
    def transfers(self):
        return self.__transfers

    @property
    def operations(self):
        return self.__operations

    def add_machine(self, machine: Machine):
        self.__machines[machine.id] = machine

    def add_transfer(self, sid, time):
        self.__transfers[sid] = time

    def add_operation(self, oper):
        self.__operations[oper.id] = oper
