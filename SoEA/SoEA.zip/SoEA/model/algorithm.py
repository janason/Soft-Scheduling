from abc import ABC, abstractmethod


class Algorithm(ABC):

    def __init__(self, name, problem):
        self.__name = name
        self.__problem = problem
        self.__best_so_far = None
        self.__best_fitness = None
        self.__history = None

    @abstractmethod
    def initialize(self):
        pass

    @abstractmethod
    def execute(self):
        pass

    @abstractmethod
    def evaluate(self, solution):
        pass

    @property
    def name(self):
        return self.__name

    @property
    def problem(self):
        return self.__problem

    @property
    def best(self):
        return self.__best_so_far
