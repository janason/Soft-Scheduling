import itertools
import pandas as pd
import seaborn as sns
import numpy as np
import matplotlib.pyplot as plt
import statsmodels.api as sa
import statsmodels.formula.api as sfa
import scikit_posthocs as sp
import time
from model.indicators import *
from SoEA.config import *


def ANOVA(df, respond_col, factor_col, x_tick=[]):
    df_melt = pd.melt(df.reset_index(), id_vars=['index'])
    df_melt.columns = ['case', factor_col, respond_col]
    print(df_melt)

    lm = sfa.ols(f'{respond_col} ~ C({factor_col})', data=df_melt).fit()
    anova = sa.stats.anova_lm(lm)
    print(anova)

    plt.figure(figsize=(3.6, 4.5))
    sns.boxplot(x=factor_col, y=respond_col, data=df_melt, width=0.40,
                fliersize=2, linewidth=1, boxprops=dict(facecolor='w'))
    sns.swarmplot(x=factor_col, y=respond_col, size=4, data=df_melt)
    plt.xticks(range(len(x_tick)), x_tick)
    plt.tick_params(labelsize=9)
    plt.show()

    post_stat = sp.posthoc_conover_friedman(
        df_melt,
        melted=True,
        block_col='case',
        group_col=factor_col,
        y_col=respond_col,
    )
    print(post_stat)
    fix, ax = plt.subplots(figsize=(10.5, 6))
    heatmap_args = {'linewidths': 0.35, 'linecolor': 'white', 'clip_on': False, 'square': True,
                    'cbar_ax_bbox': [0.75, 0.35, 0.04, 0.3]}
    sp.sign_plot(post_stat, **heatmap_args)
    plt.show()

    groups = df_melt.groupby('case')
    ranks = groups[respond_col].rank(pct=True)
    avg_rank = ranks.groupby(df_melt[factor_col]).mean()
    print(avg_rank)
    plt.figure(figsize=(8, 2), dpi=100)
    sp.critical_difference_diagram(avg_rank, post_stat)
    plt.show()

    # t = time.time()  # 当前时间
    # writer = pd.ExcelWriter(f'{int(t)}.xlsx')
    # anova.to_excel(writer, sheet_name='anova', index=False)
    # post_stat.to_excel(writer, sheet_name='post', index=False)
    # writer.close()


def plot_data_curve(df):
    plt.figure(figsize=(6, 3.2))
    # sns.set_theme(style="darkgrid")
    sns.lineplot(data=df, x="iter", y="hv1", marker="o", markersize=6, dashes=False, label='I-greedy', lw=1)
    sns.lineplot(data=df, x="iter", y="hv2", marker="o", linestyle='--', markersize=6, dashes=True, label='I-random',
                 lw=1)
    sns.lineplot(data=df, x="iter", y="hv3", marker="s", markersize=6, dashes=False, label='II-greedy', lw=1)
    sns.lineplot(data=df, x="iter", y="hv4", marker="s", linestyle='--', markersize=6, dashes=True, label='II-random',
                 lw=1)
    plt.legend(prop={'size': 10.5})
    plt.tick_params(axis='both', which='major', labelsize=10.5, pad=0)
    plt.xlabel("iteration", fontsize=11, labelpad=0)
    plt.ylabel("hypervolume", fontsize=11, labelpad=0)
    plt.show()


def cal_so_metric(f_data: dict, t_data: dict):
    rpd_list = []
    cpu_list = []
    for case in f_data.keys():
        f_case = f_data[case]
        f_min = min([min(f_list) for f_list in f_case.values()])
        rpd_dict = {}
        for c, ff in f_case.items():
            a_rpd = sum([(f - f_min) * 100 / f_min for f in ff]) / len(ff)
            rpd_dict[c] = a_rpd
        t_case = t_data[case]
        cpu_dict = {}
        for c, tt in t_case.items():
            a_cpu = sum([t for t in tt]) / len(tt)
            cpu_dict[c] = a_cpu
        rpd_list.append(rpd_dict)
        cpu_list.append(cpu_dict)

    df_rpd = pd.DataFrame(rpd_list)
    df_cpu = pd.DataFrame(cpu_list)

    ANOVA(df_rpd, 'ARPD', 'schemes', x_tick=encoder_list)
    ANOVA(df_cpu, 'ACPU', 'schemes', x_tick=encoder_list)
    return df_rpd, df_cpu


def cal_mo_metric(f_data, t_data):
    ahv_list = []
    for case, pf_data in f_data.items():
        z_max = np.array([0, 0])
        z_min = np.array([1e4, 1e4])
        Z_obj = []

        for algo, pf_list in pf_data.items():
            pf_sum = [ff for pf in pf_list for ff in pf]
            pf_array = np.vstack((np.array(pf_sum), z_min))
            z_min = pf_array.min(axis=0)
            pf_array = np.vstack((np.array(pf_sum), z_max))
            z_max = pf_array.max(axis=0)
            print(z_min, z_max)
            Z_obj.extend(pf_sum)

        pf_ref = get_pareto_front(Z_obj)
        ahv_dict = {}
        for algo, pf_list in pf_data.items():
            hv_list = []
            for pfx in pf_list:
                hv = hv_indicator(z_obj=np.array(pfx), n_obj=2, max_pt=z_max, min_pt=z_min,
                                  ref_pt=[1.0, 1.0])
                hv_list.append(hv)
                # _range = np.array(z_max) - np.array(z_min)
                # z_norm = (np.array(pfx) - z_min) / _range
                # sp_list = sp_indicator(solution=z_norm)
                # sr_list = sr_indicator(np.array(pfx), pf_ref)
            ahv_dict[algo] = sum(hv_list) / len(hv_list)
        ahv_list.append(ahv_dict)

    acpu_list = []
    for case, cpu_data in t_data.items():
        acpu_dict = {}
        for algo, cpu_list in cpu_data.items():
            acpu = sum([sum(tt) / len(tt) for tt in cpu_list]) / len(cpu_list)
            acpu_dict[algo] = acpu
        acpu_list.append(acpu_dict)

    df_ahv = pd.DataFrame(ahv_list)
    df_acpu = pd.DataFrame(acpu_list)
    print(df_ahv)
    print(df_acpu)
    ANOVA(df_ahv, 'AHV', 'schemes', x_tick=encoder_list)
    ANOVA(df_acpu, 'ACPU', 'schemes', x_tick=encoder_list)

    return df_ahv, df_acpu


def plot_mols_data(file_name):
    f = open(file_name)

    pf_dict = {key: [] for key in ['LS_ET', 'LS_NT', 'NL_ET', 'NL_NT']}
    is_read = False
    line = f.readline()
    key = ''
    while line:
        if '#' in line:
            is_read = True
            x = line.split(',')
            key = x[1].strip()
            print(line)
        if line == '\n':
            is_read = False
        if is_read and '#' not in line:
            x = line.split(',')
            print(line)
            pf_dict[key].append([float(x[0].strip()), float(x[1].strip())])
        line = f.readline()
    f.close()

    for key in ['LS_ET', 'LS_NT', 'NL_ET', 'NL_NT']:
        pf_dict[key] = get_pareto_front(pf_dict[key])

    z_max = np.array([0, 0])
    z_min = np.array([1e4, 1e4])

    pf_sum = [ff for ff_list in pf_dict.values() for ff in ff_list]
    pf_array = np.vstack((np.array(pf_sum), z_min))
    z_min = pf_array.min(axis=0)
    pf_array = np.vstack((np.array(pf_sum), z_max))
    z_max = pf_array.max(axis=0)
    print(z_min, z_max)

    hv_dict = {}
    for algo, ff_list in pf_dict.items():
        hv = hv_indicator(z_obj=np.array(ff_list), n_obj=2, max_pt=z_max, min_pt=z_min,
                          ref_pt=[1.0, 1.0])
        hv_dict[algo] = hv

    print(hv_dict)

    sns.set_style("ticks")
    hv = hv_dict['LS_ET']
    sns.scatterplot(x=[d[0] for d in pf_dict['LS_ET']], y=[d[1] for d in pf_dict['LS_ET']],
                    color='r', marker='o', label=f'LS_ET,HV={hv:.2f}')
    hv = hv_dict['NL_ET']
    sns.scatterplot(x=[d[0] for d in pf_dict['NL_ET']], y=[d[1] for d in pf_dict['NL_ET']],
                    color='b', marker='o', label=f'NL_ET,HV={hv:.2f}')
    hv = hv_dict['LS_NT']
    sns.scatterplot(x=[d[0] for d in pf_dict['LS_NT']], y=[d[1] for d in pf_dict['LS_NT']],
                    color='r', marker='x', label=f'LS_NT,HV={hv:.2f}')
    hv = hv_dict['NL_NT']
    sns.scatterplot(x=[d[0] for d in pf_dict['NL_NT']], y=[d[1] for d in pf_dict['NL_NT']],
                    color='b', marker='x', label=f'NL_NT,HV={hv:.2f}')

    plt.legend(fontsize=9)
    plt.xlabel('Cmax', fontsize=11)
    plt.ylabel('Wtot', fontsize=11)
    plt.show()


def read_data(f_dim, e_cons):
    f = open(f'./results/{f_dim}-{e_cons}.txt')
    line = f.readline()
    f_dict = {}
    t_dict = {}
    for i in range(1, 21):
        if f_dim == 'SO':
            f_dict[str(i) + "#"] = {c: [0 for i in range(5)] for c in encoder_list}
            t_dict[str(i) + "#"] = {c: [0 for i in range(5)] for c in encoder_list}
        else:
            f_dict[str(i) + "#"] = {c: [[] for i in range(5)] for c in encoder_list}
            t_dict[str(i) + "#"] = {c: [[] for i in range(5)] for c in encoder_list}
    while line:
        line = f.readline()
        if '#' in line:
            str_list = line.split()
            inst_no = str_list[0]
            if inst_no not in f_dict.keys():
                break
            coder = str_list[1]
            rond = int(str_list[2]) - 1
            if f_dim == 'MO':
                f_list = str_list[3].split(',')
                f_val = (float(f_list[0]), float(f_list[1]))
                t_val = float(str_list[4])
                f_dict[inst_no][coder][rond].append(f_val)
                t_dict[inst_no][coder][rond].append(t_val)
            else:
                f_val = float(str_list[3])
                t_val = float(str_list[4])
                f_dict[inst_no][coder][rond] = f_val
                t_dict[inst_no][coder][rond] = t_val

    return f_dict, t_dict


if __name__ == "__main__":
    # writer = pd.ExcelWriter('results/results.xlsx')
    # for f_dim, e_con in itertools.product(f_dim_list, e_cons_list):
    #     f_data, t_data = read_data(f_dim, e_con)
    #
    #     if f_dim == 'SO':
    #         df_arpd, df_acpu = cal_so_metric(f_data, t_data)
    #         df_arpd.to_excel(writer, sheet_name=f'{f_dim}-{e_con}-RPD', index=False)
    #         df_acpu.to_excel(writer, sheet_name=f'{f_dim}-{e_con}-CPU', index=False)
    #     else:
    #         df_ahv, df_acpu = cal_mo_metric(f_data, t_data)
    #         df_ahv.to_excel(writer, sheet_name=f'{f_dim}-{e_con}-RPD', index=False)
    #         df_acpu.to_excel(writer, sheet_name=f'{f_dim}-{e_con}-CPU', index=False)
    # writer.close()

    # cal_mo_metric(f_data, t_data)

    plot_mols_data('./results/MOLS.txt')
