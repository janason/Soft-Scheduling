from typing import Any

import sys

from SoEA.utils import *
from model.entities import *
from model.problem import Problem

from enum import Enum


class CodeType(Enum):
    BBRL = 1
    BBRF = 2
    JBRF = 3
    JBRA = 4
    MBRA = 5


class EoIndividual:
    def __init__(self, prob: Problem, x_list: list):
        self._problem = prob
        self._x_list = x_list
        self._q_in_stage = prob.q_in_stage
        self._max_q = prob.Q_max
        self.objs = []
        self.fitness = 0
        self.x_UB = [10.0] * len(x_list)
        self.x_LB = [1.0] * len(x_list)
        self.coe_Cmax = 0.2
        self.coe_Wtot = 0.8
        self._has_machine = False
        return

    @property
    def x_list(self):
        return self._x_list

    def decode(self):
        raise NotImplementedError

    def __lt__(self, other):  # < 运算符
        is_dominated = False
        cnt = 0
        for i in range(len(self.objs)):
            if self.objs[i] < other.objs[i]:
                is_dominated = True
            if self.objs[i] == other.objs[i]:
                cnt = cnt + 1
        if is_dominated:
            return cnt < len(self.objs)
        else:
            return False

    def __gt__(self, other):  # 重载 > 运算符
        is_dominated = True
        for i in range(len(self.objs)):
            if other.objs[i] < self.objs[i]:
                is_dominated = False
        return is_dominated

    def __eq__(self, other):  # 重载 == 运算符
        is_eq = True
        for i in range(len(self.objs)):
            if other.objs[i] != self.obj[i]:
                is_eq = False
        return is_eq

    def __ne__(self, other):  # 重载 != 运算符
        is_ne = False
        for i in range(len(self.objs)):
            if other.objs[i] != self.objs[i]:
                is_ne = True
        return is_ne

    def _shift_load(self, q_dict: dict, op, xt):
        is_shift = True
        st = xt
        et = st + op.duration
        while is_shift:
            for t in range(st, et):
                if t not in q_dict.keys():
                    q_dict[t] = 0
                is_shift = False
                if q_dict[t] + self._q_in_stage[op.stage.id] > self._max_q:
                    st = t - op.duration
                    et = st + op.duration
                    is_shift = True
                    break

        for t in range(st, st + op.duration):
            q_dict[t] += self._q_in_stage[op.stage.id]
        return st

    def _fw_upstage_scheduling(self, job_list):
        stage_list = list(self._problem.stages.values())
        last_stage = stage_list.pop(-1)

        ma_EAT_dict = {ma: 0 for ma in self._problem.machines.values()}
        op_EST_dict = {op: 0 for op in self._problem.operations.values() if op.stage == stage_list[0]}

        for stage in stage_list:
            if stage == stage_list[0]:
                sorted_op_EST_list = [(job.operations[stage.id, job.id], 0) for job in job_list]
            else:
                op_EST_list = [(op, op_EST_dict[op]) for op in stage.operations.values()]
                sorted_op_EST_list = sorted(op_EST_list, key=lambda item: item[1])
            for op, est in sorted_op_EST_list:
                ma_EAT_list = [(ma, eat) for ma, eat in ma_EAT_dict.items() if ma.stage == op.stage]
                ma_min_EAT = min(ma_EAT_list, key=lambda x: x[1])
                ma = ma_min_EAT[0]
                EAT = ma_min_EAT[1]
                st = max(EAT, est)

                op.start_time = st
                op.machine = ma
                ma.add_operation(op)

                if op.next_oper is not None:
                    op_EST_dict[op.next_oper] = op.end_time + op.time_to_next
                ma_EAT_dict[ma] = op.end_time
        return op_EST_dict

    def _bw_ustage_scheduling(self, op_LFT_dict, q_dict, has_machine=False):
        # 1. prepare data
        stage_list = list(self._problem.stages.values())
        last_stage = stage_list.pop(-1)
        ma_LAT_dict = {ma: sys.maxsize for ma in self._problem.machines.values() if ma.stage != last_stage}
        for ma in self._problem.machines.values():
            if ma.stage != last_stage:
                ma.operations.clear()
        if not has_machine:
            for op in self._problem.operations.values():
                if op.stage != last_stage:
                    op.machine = None
        # 2. scheduling
        MIN_ST = sys.maxsize
        for stage in reversed(stage_list):
            op_LFT_list = [(op, op_LFT_dict[op]) for op in stage.operations.values()]
            sorted_op_LFT_list = sorted(op_LFT_list, key=lambda item: item[1], reverse=True)
            for op, LFT in sorted_op_LFT_list:
                if op.machine is None:
                    ma_LAT_list = [(ma, lat) for ma, lat in ma_LAT_dict.items() if ma.stage == op.stage]
                    ma_max_LAT = max(ma_LAT_list, key=lambda x: x[1])
                    ma = ma_max_LAT[0]
                else:
                    ma = op.machine
                LST = min(ma_LAT_dict[ma], op_LFT_dict[op]) - op.duration
                st = self._shift_load(q_dict, op, LST)

                op.start_time = st
                op.machine = ma
                ma.operations.append(op)
                if op.prev_oper is not None:
                    op_LFT_dict[op.prev_oper] = op.start_time - op.prev_oper.time_to_next
                ma_LAT_dict[ma] = op.start_time
                if op.start_time < MIN_ST:
                    MIN_ST = op.start_time

        # sorted_op_LFT_list1 = sorted(op_LFT_dict.items(), key=lambda item: item[1], reverse=True)
        # job_list = [op.job for op, dd in sorted_op_LFT_list1]
        # while len(job_list) > 0:
        #     job = job_list.pop(0)
        #     op = list(job.operations.values())[-1]
        #     while op.prev_oper is not None:
        #         op = op.prev_oper
        #         if op.machine is None:
        #             ma_LAT_list = [(ma, est) for ma, est in ma_LAT_dict.items() if ma.stage == op.stage]
        #             ma_max_LAT = max(ma_LAT_list, key=lambda x: x[1])
        #             ma = ma_max_LAT[0]
        #             LAT = ma_max_LAT[1]
        #         else:
        #             ma = op.machine
        #         LST = min(ma_LAT_dict[ma], op_LFT_dict[op]) - op.duration
        #         st = self._shift_load(q_dict, op, LST)
        #
        #         op.start_time = st
        #         op.machine = ma
        #         ma.operations.append(op)
        #         if op.prev_oper is not None:
        #             op_LFT_dict[op.prev_oper] = op.start_time - op.prev_oper.time_to_next
        #         ma_LAT_dict[ma] = op.start_time
        #         if op.start_time < MIN_ST:
        #             MIN_ST = op.start_time

        return MIN_ST

    def _fw_lstage_scheduling(self, ratios, op_EST_dict=None):

        last_stage = list(self._problem.stages.values())[-1]
        ma_EAT_dict = {ma: 0 for ma in last_stage.machines.values()}
        op_LFT_dict = {}
        Cmax = 0
        for b, batch in self._problem.batches.items():
            ma: Machine = batch.dest_machine
            ma_EAT_dict[ma] = ma_EAT_dict[ma] + round(batch.setup_time * ratios[b - 1])
            Cmax_b = 0
            for r in range(len(batch.jobs)):
                op: Operation = list(batch.jobs[r].operations.values())[-1]  # 连铸操作
                if op_EST_dict is not None:
                    op.start_time = max(ma_EAT_dict[ma], op_EST_dict[op])
                else:
                    op.start_time = ma_EAT_dict[ma]
                ma_EAT_dict[ma] = op.end_time
                op.machine = ma
                ma.operations.append(op)

                if Cmax_b < op.end_time:
                    Cmax_b = op.end_time

            if Cmax < Cmax_b:
                Cmax = Cmax_b
            for job in reversed(batch.jobs):  # 反向操作，保持连续加工
                op: Operation = list(job.operations.values())[-1]
                op.start_time = Cmax_b - op.duration
                Cmax_b = op.start_time
                op_LFT_dict[op.prev_oper] = op.start_time - op.prev_oper.time_to_next

        q_dict = {t: 0 for t in range(Cmax)}
        for op in last_stage.operations.values():
            for t in range(op.start_time, op.end_time):
                q_dict[t] += self._q_in_stage[op.stage.id]
        return op_LFT_dict, q_dict

    def calc_final_objective(self, gap):
        Cmax = 0
        Wtot = 0
        for op in self._problem.operations.values():
            op.start_time = op.start_time - gap
            if op.end_time > Cmax:
                Cmax = op.end_time
        for op in self._problem.operations.values():
            if op.next_oper is not None:
                wt = op.next_oper.start_time - op.end_time - op.time_to_next
                Wtot += wt
        if self._problem.f_dim == 1:
            self.objs = [Cmax * self.coe_Cmax + Wtot * self.coe_Wtot]
        else:
            self.objs = [Cmax, Wtot]


class BBRLIndividual(EoIndividual):

    def decode(self):
        self._problem.reset()
        # 1. 连铸调度
        op_LFT_dict, q_dict = self._fw_lstage_scheduling(self._x_list)
        # 2. 上游调度
        MIN_ST = self._bw_ustage_scheduling(op_LFT_dict, q_dict=q_dict)
        # 3. 计算目标函数
        self.calc_final_objective(gap=MIN_ST)
        # print('BBRL', self.objs)
        # self._problem.show_in_gantt()
        return


class JBRFIndividual(EoIndividual):

    def decode(self):
        self._problem.reset()
        # stage_list = list(self._problem.stages.values())
        # last_stage = stage_list[-1]
        # 1. 前向上游调度
        job_list = [self._problem.jobs[x] for x in self.x_list]
        op_EST_dict = self._fw_upstage_scheduling(job_list=job_list)
        # ma_EAT_dict = {ma: 0 for ma in self._problem.machines.values() if ma.stage != last_stage}
        # op_EST_dict = {list(job.operations.values())[0]: 0 for job in self._problem.jobs.values()}
        # while len(job_list) > 0:
        #     job = job_list.pop(0)
        #     op = list(job.operations.values())[0]
        #     while op.stage != last_stage:
        #         ma_EAT_list = [(ma, est) for ma, est in ma_EAT_dict.items() if ma.stage == op.stage]
        #         ma_min_EAT = min(ma_EAT_list, key=lambda x: x[1])
        #         ma = ma_min_EAT[0]
        #         EAT = ma_min_EAT[1]
        #         EST = max(EAT, op_EST_dict[op])
        #
        #         op.start_time = EST
        #         op.machine = ma
        #         ma.add_operation(op)
        #
        #         op_EST_dict[op.next_oper] = op.end_time + op.time_to_next
        #         ma_EAT_dict[ma] = op.end_time
        #         op = op.next_oper
        # 3. 前向连铸调度
        op_LFT_dict, q_list = self._fw_lstage_scheduling(ratios=[1.0] * len(self._problem.batches),
                                                         op_EST_dict=op_EST_dict)
        # 4. 反向上游调度
        MIN_ST = self._bw_ustage_scheduling(op_LFT_dict, q_list, has_machine=self._has_machine)
        # 5. 计算目标函数
        self.calc_final_objective(gap=MIN_ST)
        # print('JBRF', self.objs)
        # self._problem.show_in_gantt()
        return


class MBRAIndividual(EoIndividual):

    def __init__(self, prob: Problem, x_list):
        super(MBRAIndividual, self).__init__(prob, x_list)  # 不要忘记从Animal类引入属性
        self._j_list = []
        self.start_batch = {}

    def decode(self):
        self._problem.reset()
        ups_stages: list = list(self._problem.stages.values())
        last_stage = ups_stages[-1]
        ups_stages.remove(last_stage)
        # 1. 连铸调度
        op_LFT_dict, q_dict = self._fw_lstage_scheduling(ratios=[1.0] * len(self._problem.batches),
                                                         op_EST_dict=self.start_batch)
        # 2. 反向上游调度-指定机器
        for job in self._problem.jobs.values():
            j = job.id
            for stage in self._problem.stages.values():
                i = stage.id
                k = self.x_list[j - 1][i - 1]
                if k > 0:
                    ma = self._problem.machines[i, k]
                    op = self._problem.operations[i, j]
                    op.machine = ma

        # MIN_ST = sys.maxsize
        # ma_LAT_dict = {ma: sys.maxsize for ma in self._problem.machines.values() if ma.stage != last_stage}
        # for i in reversed(range(len(ups_stages))):
        #     stage: Stage = ups_stages[i]
        #     op_LFT_list = [(op, op_LFT_dict[op]) for op in stage.operations.values()]
        #     sorted_op_LFT_list = sorted(op_LFT_list, key=lambda item: item[1], reverse=True)
        #     while len(sorted_op_LFT_list) > 0:
        #         op, LFT = sorted_op_LFT_list.pop(0)
        #         ma = op.machine
        #         LST = min(ma_LAT_dict[ma], op_LFT_dict[op]) - op.duration
        #         st = self._shift_load(q_dict, op, LST)
        #         op.start_time = st
        #         if op.prev_oper is not None:
        #             op_LFT_dict[op.prev_oper] = op.start_time - op.prev_oper.time_to_next
        #         ma_LAT_dict[ma] = op.start_time
        #         ma.add_operation(op)
        #
        #         if op.start_time < MIN_ST:
        #             MIN_ST = op.start_time
        # 4. 反向上游调度
        MIN_ST = self._bw_ustage_scheduling(op_LFT_dict, q_dict, has_machine=True)
        # 3. 计算目标函数
        self.calc_final_objective(gap=MIN_ST)
        # print('MBRA', self.objs)
        # self._problem.show_in_gantt()
        return


class JBRAIndividual(EoIndividual):

    def decode(self):
        self._problem.reset()
        stage_list: list = list(self._problem.stages.values())
        last_stage = stage_list[-1]
        stage_list.remove(last_stage)
        # 1. 上游调度
        ma_EAT_dict = {ma: 0 for ma in self._problem.machines.values() if ma.stage != last_stage}
        op_EST_dict = {list(job.operations.values())[0]: 0 for job in self._problem.jobs.values()}
        for i in range(len(stage_list)):
            job_list = [self._problem.jobs[x] for x in self.x_list[i] if x != 0]
            stage: Stage = stage_list[i]
            while len(job_list) > 0:
                job = job_list.pop(0)
                op = self._problem.operations[stage.id, job.id]
                ma_EAT_list = [(ma, est) for ma, est in ma_EAT_dict.items() if ma.stage == op.stage]
                ma_min_EAT = min(ma_EAT_list, key=lambda x: x[1])
                ma = ma_min_EAT[0]
                EAT = ma_min_EAT[1]
                EST = max(EAT, op_EST_dict[op])

                op.start_time = EST
                op.machine = ma
                ma.add_operation(op)

                op_EST_dict[op.next_oper] = op.end_time + op.time_to_next
                ma_EAT_dict[ma] = op.end_time

        # 2. 连铸调度
        op_LFT_dict, q_dict = self._fw_lstage_scheduling(ratios=[1.0] * len(self._problem.batches),
                                                         op_EST_dict=op_EST_dict)
        # 3. 反向上游调度
        MIN_ST = self._bw_ustage_scheduling(op_LFT_dict, q_dict, has_machine=self._has_machine)
        # 4. 计算目标函数
        self.calc_final_objective(gap=MIN_ST)
        # print('JBRA', self.objs)
        # self._problem.show_in_gantt()
        return


class BBRFIndividual(EoIndividual):

    def __init__(self, prob: Problem, x_list):
        super(BBRFIndividual, self).__init__(prob, x_list)  # 不要忘记从Animal类引入属性
        self._j_list = []

    @property
    def j_list(self):
        return self._j_list

    def convert_x_to_jl(self):
        job_seq_in_batch = {b: 0 for b in self._problem.batches.values()}
        self._j_list.clear()
        for x in self.x_list:
            batch = self._problem.batches[x]
            seq = job_seq_in_batch[batch]
            job = batch.jobs[seq]
            job_seq_in_batch[batch] += 1
            self._j_list.append(job.id)
        return

    def convert_jl_to_x(self):

        self._x_list.clear()
        for j in self._j_list:
            job = self._problem.jobs[j]
            self.x_list.append(job.batch.id)
        return

    def decode(self):
        self._problem.reset()
        self.convert_x_to_jl()
        job_list = [self._problem.jobs[j] for j in self._j_list]
        # 1. 前向上游调度
        op_EST_dict = self._fw_upstage_scheduling(job_list=job_list)
        # 2. 前向连铸调度
        op_LFT_dict, q_dict = self._fw_lstage_scheduling(ratios=[1.0] * len(self._problem.batches),
                                                         op_EST_dict=op_EST_dict)
        # 3. 反向上游调度
        MIN_ST = self._bw_ustage_scheduling(op_LFT_dict, q_dict, has_machine=self._has_machine)
        # 4. 计算目标函数
        self.calc_final_objective(gap=MIN_ST)
        # print('BBRF', self.objs)
        # self._problem.show_in_gantt()
        return
