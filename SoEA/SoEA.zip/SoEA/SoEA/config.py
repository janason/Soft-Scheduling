stage_num_list = [3, 4]
f_dim_list = ['SO', 'MO']
e_cons_list = ['NT', 'ET']

encoder_list = ['BBRL', 'BBRF', 'JBRF', 'JBRA', 'MBRA']
has_intensifier = [False, True]

SCCSP_params = dict(
    stage_num=3,
    obj_num=1,
    eng_cons=False)

SoEA_params = dict(
    code_type='BBRL',
    f_dim='SO',
    e_cons='NT',
    pop_size=80,
    p_cr=0.8,
    p_mu=0.2,
    intensified=False
)
