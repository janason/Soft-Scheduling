import copy
import math
import operator
from datetime import datetime

import numpy

from SoEA.SoCrossover import *
from SoEA.SoIndividual import *
from SoEA.SoMutation import *
from SoEA.SoSelection import *
from model.algorithm import Algorithm
from model.problem import Problem
import seaborn as sns
import matplotlib.pyplot as plt
import numpy as np
import random


class SoEASolver(Algorithm):

    def __init__(self, name, problem: Problem, pop_size=50,
                 tfe_num=5000, p_cr=0.8, p_mu=0.2):
        super().__init__(name, problem)
        self.code_type = None
        self.mutation = None
        self.crossover = None
        self.selection = None

        self.POP_SIZE = int(pop_size)
        self.MAX_ITER = round(tfe_num / pop_size)
        self.best_obj = None
        self.population = []
        self.history_data = []
        self.pf_data = []
        self.has_local_search = False

        if name == 'BBRL':
            self.assign_components(CodeType.BBRL, MoTournamentSelection(self.POP_SIZE, k=2),
                                   BBRLCrossover(p_cr, problem), BBRLMutation(p_mu, problem))
        if name == 'BBRF':
            self.assign_components(CodeType.BBRF, MoTournamentSelection(self.POP_SIZE, k=2),
                                   BBRFCrossover(p_cr, problem), BBRFMutation(p_mu, problem))
        if name == 'JBRF':
            self.assign_components(CodeType.JBRF, MoTournamentSelection(self.POP_SIZE, k=2),
                                   JBRFCrossover(p_cr, problem), JBRFMutation(p_mu, problem))
        if name == 'JBRA':
            self.assign_components(CodeType.JBRA, MoTournamentSelection(self.POP_SIZE, k=2),
                                   JBRACrossover(p_cr, problem), JBRAMutation(p_mu, problem))
        if name == 'MBRA':
            self.assign_components(CodeType.MBRA, MoTournamentSelection(self.POP_SIZE, k=2),
                                   MBRACrossover(p_cr, problem), MBRAMutation(p_mu, problem))

    def assign_components(self, code_type, selection, crossover, mutation):
        self.code_type = code_type
        self.selection = selection
        self.crossover = crossover
        self.mutation = mutation

    def initialize(self):
        random.seed(datetime.now())
        temp_pop = [BBRLIndividual(self.problem, [1.0] * len(self.problem.batches)),
                    BBRLIndividual(self.problem, [3.0] * len(self.problem.batches)),
                    BBRLIndividual(self.problem, [5.0] * len(self.problem.batches))]
        while len(temp_pop) < self.POP_SIZE:
            code = []
            for b in range(len(self.problem.batches)):
                code.append(random.uniform(1, 10))
            indv = BBRLIndividual(self.problem, code)
            temp_pop.append(indv)
        if self.code_type == CodeType.BBRL:
            self.population = temp_pop

        if self.code_type == CodeType.BBRF:
            for indv in temp_pop:
                indv.decode()
                first_stage = self.problem.stages[1]
                opers_in_fstage = [op for op in first_stage.operations.values()]
                opers_in_fstage.sort(key=lambda x: x.start_time)
                code = [op.job.batch.id for op in opers_in_fstage]
                self.population.append(BBRFIndividual(self.problem, code))

        if self.code_type == CodeType.JBRF:
            for indv in temp_pop:
                indv.decode()
                first_stage = self.problem.stages[1]
                opers_in_fstage = [op for op in first_stage.operations.values()]
                opers_in_fstage.sort(key=lambda x: x.start_time)
                code = [op.job.id for op in opers_in_fstage]
                self.population.append(JBRFIndividual(self.problem, code))

        if self.code_type == CodeType.JBRA:
            for indv in temp_pop:
                indv.decode()
                stage_list = [stage for stage in self.problem.stages.values()]
                stage_list.pop(-1)
                code = []
                for stage in stage_list:
                    opers_in_stage = [op for op in stage.operations.values()]
                    opers_in_stage.sort(key=lambda x: x.start_time)
                    code.append([op.job.id for op in opers_in_stage])
                self.population.append(JBRAIndividual(self.problem, code))

        if self.code_type == CodeType.MBRA:
            for indv in temp_pop:
                indv.decode()
                start_batch = {}
                for batch in self.problem.batches.values():
                    for job in batch.jobs:
                        op = list(job.operations.values())[-1]
                        start_batch[op] = op.start_time
                stage_list = [stage for stage in self.problem.stages.values()]
                stage_list.pop(-1)
                code = []
                for job in self.problem.jobs.values():
                    mm = []
                    for stage in self.problem.stages.values():
                        i = stage.id
                        j = job.id
                        if (i, j) in self.problem.operations.keys():
                            mm.append(self.problem.operations[i, j].machine.id[1])
                        else:
                            mm.append(0)
                    code.append(mm)
                new_indv = MBRAIndividual(self.problem, code)
                new_indv.start_batch = start_batch
                self.population.append(new_indv)

        self.evaluate(self.population)
        if self.problem.f_dim > 1:
            fronts, ranks = fast_non_dominated_sorting(self.population)
            sort_idx = calculate_crowding_distance(fronts, ranks, self.population)
            for p in range(len(self.population)):
                self.population[p].fiteness = 1.0 / (1 + sort_idx.index(p))
            self.population = [self.population[i] for i in sort_idx[0:self.POP_SIZE]]
            elite = [self.population[i] for i in fronts[0]]
            self.pf_data = list(set([(p.objs[0], p.objs[1]) for p in elite]))
            print(f'iter={0}  PF-size = {len(fronts[0])}')
        else:
            for p in range(len(self.population)):
                self.population[p].fiteness = 1.0 / math.log(self.population[p].objs[0] + 2)
            pop = sorted(self.population, key=lambda x: x.objs[0], reverse=False)
            self.population = [indv for indv in pop[0:self.POP_SIZE]]
            self.history_data.append((0, self.population[0].objs[0]))
            self.best_obj = self.population[0].objs[0]
            print(f'iter={0}  Opt. = {self.population[0].objs[0]}')
        return

    def complete_random(self):
        random.seed(datetime.now())

        if self.code_type == CodeType.BBRL:
            self.population.append(BBRLIndividual(self.problem, [1.0] * len(self.problem.batches)))
            self.population[0].decode()
            self.population.append(BBRLIndividual(self.problem, [3.0] * len(self.problem.batches)))
            self.population.append(BBRLIndividual(self.problem, [5.0] * len(self.problem.batches)))
            while len(self.population) < self.POP_SIZE:
                code = []
                for b in range(len(self.problem.batches)):
                    code.append(random.uniform(1, 5))
                soln = BBRLIndividual(self.problem, code)
                self.population.append(soln)
        if self.code_type == CodeType.JBRF:
            self.population.append(JBRFIndividual(self.problem, [job.id for job in self.problem.jobs.values()]))
            while len(self.population) < self.POP_SIZE:
                code = [job.id for job in self.problem.jobs.values()]
                np.random.shuffle(code)
                indv = JBRFIndividual(self.problem, code)
                self.population.append(indv)
        if self.code_type == CodeType.JBRA:
            code0 = []
            for i in range(1, len(self.problem.stages)):
                xx = []
                for j in range(1, len(self.problem.jobs) + 1):
                    if (i, j) in self.problem.operations.keys():
                        xx.append(j)
                    else:
                        xx.append(0)
                code0.append(xx)
            self.population.append(JBRAIndividual(self.problem, code0))
            while len(self.population) < self.POP_SIZE:
                codex = copy.deepcopy(code0)
                for r in range(len(codex)):
                    if np.random.random() < 0.8:
                        np.random.shuffle(codex[r])
                indv = JBRAIndividual(self.problem, codex)
                self.population.append(indv)

        if self.code_type == CodeType.MBRA:
            code0 = []
            for j in range(1, len(self.problem.jobs) + 1):
                xx = []
                for i in range(1, len(self.problem.stages)):
                    stage = self.problem.stages[i]
                    if (i, j) in self.problem.operations.keys():
                        m = j % len(stage.machines)
                        xx.append(m + 1)
                    else:
                        xx.append(0)
                code0.append(xx)
            self.population.append(MBRAIndividual(self.problem, code0))
            while len(self.population) < self.POP_SIZE:
                codex = []
                for j in range(1, len(self.problem.jobs) + 1):
                    xx = []
                    for i in range(1, len(self.problem.stages)):
                        stage = self.problem.stages[i]
                        if (i, j) in self.problem.operations.keys():
                            m = np.random.randint(0, len(stage.machines))
                            xx.append(m + 1)
                        else:
                            xx.append(0)
                    codex.append(xx)
                indv = MBRAIndividual(self.problem, codex)
                self.population.append(indv)

        if self.code_type == CodeType.BBRF:
            code = [job for job in self.problem.jobs.values()]
            self.population.append(BBRFIndividual(self.problem, [job.batch.id for job in code]))
            while len(self.population) < self.POP_SIZE:
                np.random.shuffle(code)
                indv = BBRFIndividual(self.problem, [job.batch.id for job in code])
                self.population.append(indv)
        return

    def evaluate(self, population):
        for indv in population:
            indv.decode()

    def show_best_solution(self):
        obj = self.__best_so_far.save_to_problem()
        # self.problem.show_in_gantt()
        return obj

    def show_history(self):
        pass

    def local_search(self, x0: BBRLIndividual):
        xs: BBRLIndividual = copy.deepcopy(x0)
        d = len(xs.x_list)
        delta = 0.5
        n = 0

        xx = []
        while n < d * 5:
            for i in range(d):
                xt_1: BBRLIndividual = copy.deepcopy(xs)
                xt_2: BBRLIndividual = copy.deepcopy(xs)
                xr = random.sample(self.population, 2)
                xt_1.x_list[i] = max(min(x0.x_list[i] + delta * (xr[0].x_list[i] - xr[1].x_list[i]),
                                         x0.x_UB[i]), x0.x_LB[i])
                xt_2.x_list[i] = max(min(x0.x_list[i] - delta * (xr[0].x_list[i] - xr[1].x_list[i]),
                                         x0.x_UB[i]), x0.x_LB[i])
                xt_1.decode()
                xt_2.decode()
                if self.problem.f_dim > 1:
                    if xt_1 < xs:
                        xx.append(xt_1)
                    if xt_2 < xs:
                        xx.append(xt_2)
                else:
                    if xt_1 < xs:
                        xs = xt_1
                    if xt_2 < xs:
                        xs = xt_2
                n = n + 1
        if self.problem.f_dim > 1:
            return xx
        else:
            return xs

    def local_search1(self, x0: BBRLIndividual):
        xs: BBRLIndividual = copy.deepcopy(x0)
        d = len(xs.x_list)
        e_lite = [self.population[i] for i in range(int(self.POP_SIZE / 2))]
        mu = []
        sigma = []
        for i in range(d):
            xp = [x.x_list[i] for x in e_lite]
            mu.append(np.mean(xp))
            sigma.append(np.std(xp, ddof=1))
        xx = []
        n = 0
        while n < d * 5:
            xt: BBRLIndividual = copy.deepcopy(xs)
            for i in range(d):
                if np.random.rand() < 0.5:
                    vv = np.random.normal(mu[i], sigma[i], 1)
                    xt.x_list[i] = max(min(vv[0], x0.x_UB[i]), x0.x_LB[i])
            xt.decode()
            if xt < xs:
                xs = xt
            if self.problem.f_dim > 1:
                xx.append(xs)
            n = n + 1
        if self.problem.f_dim > 1:
            return xx
        else:
            return xs

    def execute(self):
        # solving process
        for n in range(1, self.MAX_ITER + 1):
            # select
            sel_pop = self.selection.select(self.population)
            # crossover
            new_pop = self.crossover.cross(sel_pop)
            # mutation
            self.mutation.mutate(new_pop)
            # evaluate
            self.evaluate(new_pop)
            # merge
            self.population.extend(new_pop)
            if self.problem.f_dim > 1:
                fronts, ranks = fast_non_dominated_sorting(self.population)
                sort_idx = calculate_crowding_distance(fronts, ranks, self.population)

                for p in range(len(self.population)):
                    self.population[p].fiteness = 1.0 / (1 + sort_idx.index(p))

                self.population = [self.population[i] for i in sort_idx[0:self.POP_SIZE]]
                print(f'iter={n}  PF-size = {len(fronts[0])}')

                if self.has_local_search and n % 10 == 0:
                    for i in range(int(0.1 * self.POP_SIZE)):
                        ls_pop = self.local_search(self.population[i])
                        self.population.extend(ls_pop)
                    fronts, ranks = fast_non_dominated_sorting(self.population)
                    sort_idx = calculate_crowding_distance(fronts, ranks, self.population)
                    for p in range(len(self.population)):
                        self.population[p].fiteness = 1.0 / (1 + sort_idx.index(p))
                    self.population = [self.population[i] for i in sort_idx[0:self.POP_SIZE]]
                    print(f'iter={n}  PF-size = {len(fronts[0])}')
            else:
                pop = sorted(self.population, key=lambda x: x.objs[0], reverse=False)
                self.population = [indv for indv in pop[0:self.POP_SIZE]]
                if self.has_local_search and n % 10 == 0:
                    for i in range(int(0.1 * self.POP_SIZE)):
                        self.population[i] = self.local_search(self.population[i])
                self.population = sorted(self.population, key=lambda x: x.objs[0], reverse=False)
                for p in range(len(self.population)):
                    self.population[p].fiteness = 1.0 / math.log(self.population[p].objs[0])
                self.history_data.append((n, self.population[0].objs[0]))
                self.best_obj = self.population[0].objs[0]
                print(f'iter={n}  Opt. = {self.population[0].objs[0]}')

        if self.problem.f_dim > 1:
            fronts, ranks = fast_non_dominated_sorting(self.population)
            elite = [self.population[i] for i in fronts[0]]
            self.pf_data = list(set([(p.objs[0], p.objs[1]) for p in elite]))
            # ax.scatter(x, y)
            # plt.show()
        # else:
        #     x = [h[0] for h in history_opt]
        #     y = [h[1] for h in history_opt]
        #     ax.plot(x, y)
        #     plt.show()
