from SoEA import SoIndividual

# PROB_NAME = 'DMOP_3423_6*[5-15]#1'
# OBJ_DIM = 1
# Q_MAX = 100

Pc = 0.9
Pm = 0.25


def fast_non_dominated_sorting(population=None):
    S = [[] for i in range(0, len(population))]
    front = [[]]
    n = [0 for i in range(0, len(population))]
    rank = [0 for i in range(0, len(population))]
    for p in range(0, len(population)):
        S[p] = []
        n[p] = 0
        pSol: SoIndividual = population[p]
        for q in range(0, len(population)):
            qSol: SoIndividual = population[q]
            if pSol < qSol:
                if q not in S[p]:
                    S[p].append(q)
            elif qSol < pSol:
                n[p] = n[p] + 1
        if n[p] == 0:
            rank[p] = 0
            if p not in front[0]:
                front[0].append(p)
    i = 0
    while len(front[i]) != 0:
        Q = []
        for p in front[i]:
            for q in S[p]:
                n[q] = n[q] - 1
                if n[q] == 0:
                    rank[q] = i + 1
                    if q not in Q:
                        Q.append(q)
        i = i + 1
        front.append(Q)
    del front[len(front) - 1]

    return front, rank


def calculate_crowding_distance(fronts, ranks, population):
    sort_ranks = [[ranks[i], -1, i] for i in range(len(ranks))]
    for front in fronts:
        fn = len(front)
        xlist = [population[i] for i in front]
        crowding_distance = [0] * fn
        for m in range(len(xlist[0].objs)):
            xlist.sort(key=lambda sol: sol.objs[m])
            crowding_distance[0] = 10 ** 6
            crowding_distance[fn - 1] = 10 ** 6
            m_values = [sol.objs[m] for sol in xlist]
            scale = max(m_values) - min(m_values)
            if scale == 0:
                scale = 1
            for i in range(1, fn - 1):
                crowding_distance[i] += (xlist[i + 1].objs[m] - xlist[i - 1].objs[m]) / scale
        for i, j in enumerate(front):
            sort_ranks[j][1] = crowding_distance[i]
    sort_ranks.sort(key=lambda x: (x[0], -x[1]))
    return [rd[2] for rd in sort_ranks]
