# MUTATION
import numpy as np


class Mutation:
    '''
    this operation is only available for Individual class defined in self._individual_class
    '''

    def __init__(self, rate, problem=None):
        self._rate = rate
        self._problem = problem
        self._M = [len(s.machines) for s in self._problem.stages.values()]

    def mutate(self, population):
        raise NotImplementedError


class JBRFMutation(Mutation):
    def mutate(self, population):

        for p in range(len(population)):
            indv = population[p]
            rnd = np.random.random()
            if rnd > self._rate:
                continue
            R = np.random.choice(len(indv.x_list), 2, replace=False)
            r1 = min(R)
            r2 = max(R)
            for j in range(r1, r2 + 1):
                k = np.random.randint(0, len(indv.x_list))
                indv.x_list[j], indv.x_list[k] = indv.x_list[k], indv.x_list[j]

        return population


class BBRLMutation(Mutation):
    def mutate(self, population):
        eta_m = 1.0
        for i in range(len(population)):
            indv = population[i]
            rnd = np.random.random()
            if rnd > self._rate:
                continue
            L = len(indv.x_list)
            R = np.random.choice(L, 2, replace=False)
            r1 = min(R)
            r2 = max(R)
            for j in range(r1, r2 + 1):
                y = indv.x_list[j]
                ylow = indv.x_LB[j]
                yup = indv.x_UB[j]
                delta1 = 1.0 * (y - ylow) / (yup - ylow)
                delta2 = 1.0 * (yup - y) / (yup - ylow)
                rx = np.random.random()
                mut_pow = 1.0 / (eta_m + 1.0)
                if rx <= 0.5:
                    xy = 1.0 - delta1
                    val = 2.0 * rx + (1.0 - 2.0 * rx) * (xy ** (eta_m + 1.0))
                    deltaq = val ** mut_pow - 1.0
                else:
                    xy = 1.0 - delta2
                    val = 2.0 * (1.0 - rx) + 2.0 * (rx - 0.5) * (xy ** (eta_m + 1.0))
                    deltaq = 1.0 - val ** mut_pow
                y = y + deltaq * (yup - ylow)
                if y < ylow or y > yup:
                    if np.random.random() < 0.5:
                        y = min(yup, max(y, ylow))
                    else:
                        y = np.random.uniform(ylow, yup)
                indv.x_list[j] = y

        return population


class JBRAMutation(Mutation):
    def mutate(self, population):
        eta_m = 1.0
        for i in range(len(population)):
            indv = population[i]
            rnd = np.random.random()
            if rnd > self._rate:
                continue
            L = len(indv.x_list)
            r = np.random.randint(0, L)
            C = np.random.choice(len(indv.x_list[r]), 2, replace=False)
            c1 = min(C)
            c2 = max(C)
            for j in range(c1, c2 + 1):
                k = np.random.randint(0, L)
                indv.x_list[r][j], indv.x_list[r][k] = indv.x_list[r][k], indv.x_list[r][j]
                # y = indv.x_list[r][j]
                # indv.x_list[r][j] = indv.x_list[r][k]
                # indv.x_list[r][k] = y

        return population


class MBRAMutation(Mutation):
    def mutate(self, population):

        for i in range(len(population)):
            indv = population[i]
            rnd = np.random.random()
            if rnd > self._rate:
                continue
            # i1 = np.random.randint(0, L)
            # I = np.random.choice(len(indv.x_list), 2, replace=False)
            # i1 = min(I)
            # i2 = max(I)
            for j in range(len(indv.x_list)):
                if np.random.random() < 0.5:
                    continue
                for i in range(len(indv.x_list[j])):
                    if indv.x_list[j][i] == 0:
                        continue
                    # while m == indv.x_list[i][j]:
                    #     m = np.random.randint(0, max(M)) + 1
                    indv.x_list[j][i] = self._M[i] + 1 - indv.x_list[j][i]

        return population


class BBRFMutation(Mutation):
    def mutate(self, population):

        for i in range(len(population)):
            indv = population[i]
            rnd = np.random.random()
            if rnd > self._rate:
                continue
            L = len(indv.x_list)
            j1 = np.random.randint(0, L)
            j2 = np.random.randint(0, L)
            while indv.x_list[j1] == indv.x_list[j2]:
                j2 = np.random.randint(0, L)
            indv.x_list[j1], indv.x_list[j2] = indv.x_list[j2], indv.x_list[j1]

        return population
