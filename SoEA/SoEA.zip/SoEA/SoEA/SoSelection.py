# ----------------------------------------------------------
# GAOperators.py: Selection, Crossover, Mutation
# ----------------------------------------------------------

import numpy as np
import copy


# ----------------------------------------------------------
# SELECTION
# ----------------------------------------------------------
class Selection:
    '''base class for selection'''

    def select(self, population):
        raise NotImplementedError


class SoRouletteSelection(Selection):
    '''
    select individuals by Roulette Wheel:
    individuals selected with a probability of its fitness
    '''

    def select(self, population):
        total = sum([p.objs[0] for p in population])
        fitness = np.array([p.objs[0] / total for p in population])

        selected_population = np.random.choice(population, population.size, p=fitness)
        # pay attention to deep copy these objects
        population.individuals = np.array([copy.deepcopy(I) for I in selected_population])


class SoTournamentSelection(Selection):
    '''
    select individuals by tournament: each time select the best individual from k candidates
    '''

    def __init__(self, pool_size, k=2):
        '''
        rate: probability ratio of the best individual to the worst
            it shows the relative probability of the best/worst individual to be selected
        '''
        if not isinstance(k, int) and k < 2:
            raise ValueError('the candinates number should be integer larger than 1')

        self.pool_size = pool_size
        self.k = k

    def select(self, population):
        total = sum([p.objs[0] for p in population])
        pop_fitness = np.array([(p.objs[0] / total) for p in population])

        count = 0
        selected_population = []
        while count < len(population):
            count += 1
            candidates = np.random.choice(population, self.k, replace=False)
            winner = max(candidates, key=lambda x: x.fitness)
            selected_population.append(winner)

        return np.array([copy.deepcopy(I) for I in selected_population])


class MoTournamentSelection(Selection):
    '''
    select individuals by tournament: each time select the best individual from k candidates
    '''

    def __init__(self, pool_size, k=2):
        '''
        rate: probability ratio of the best individual to the worst
            it shows the relative probability of the best/worst individual to be selected
        '''
        if not isinstance(k, int) and k < 2:
            raise ValueError('the candinates number should be integer larger than 1')

        self.k = k
        self.pool_size = pool_size

    def select(self, population):

        count = 0
        selected_population = []
        while count < self.pool_size:
            count += 1
            candidates = np.random.choice(population, self.k, replace=False)
            winner = max(candidates, key=lambda x: x.fitness)
            selected_population.append(winner)

        return [copy.deepcopy(p) for p in selected_population]
