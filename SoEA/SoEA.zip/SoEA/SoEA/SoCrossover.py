import copy
from random import random

import numpy as np

from SoEA.SoIndividual import EoIndividual, BBRLIndividual, BBRFIndividual
from model.problem import Problem


class Crossover:
    '''
    this operation is only available for Individual class defined in self._individual_class
    '''

    def __init__(self, rate=0.9, problem=None):
        self._rate = rate
        self._problem = problem

    def cross(self, population):
        raise NotImplementedError

    def PMX(self, p1, p2):
        c1 = copy.deepcopy(p1)
        c2 = copy.deepcopy(p2)
        p1_p2 = {}
        p2_p1 = {}
        # 选择：
        L = len(p1)
        I = np.random.choice(L, 2, replace=False)
        i1 = min(I)
        i2 = max(I)
        # 交换：
        for i in range(i1, i2 + 1):
            c1[i] = p2[i]
            c2[i] = p1[i]
        # 建立映射关系
        inner1 = c1[i1: i2 + 1]
        outer1 = c1[0:i1] + c1[i2 + 1:]
        inner2 = c2[i1: i2 + 1]
        outer2 = c2[0:i1] + c2[i2 + 1:]
        for k in range(i2 - i1 + 1):
            q1 = inner1[k]
            q2 = inner2[k]
            if q1 not in outer1: continue
            if q1 == q2: continue
            while q2 in inner1:
                qx = inner2[inner1.index(q2)]
                if qx == q2:
                    break
                q2 = qx
            p1_p2[q1] = q2
            p2_p1[q2] = q1
        # 消除重复
        sl = set(c1)

        for i in range(i1):
            if c1[i] in p1_p2.keys():
                c1[i] = p1_p2[c1[i]]
            if c2[i] in p2_p1.keys():
                c2[i] = p2_p1[c2[i]]
        for i in range(i2 + 1, L):
            if c1[i] in p1_p2.keys():
                c1[i] = p1_p2[c1[i]]
            if c2[i] in p2_p1.keys():
                c2[i] = p2_p1[c2[i]]

        # if len(c1) == len(set(c1)):
        #     print('无重复')
        # else:
        #     print('重复')
        #     sl = set(c1)
        #     for i in sl:
        #         if c1.count(i) > 1:
        #             print("元素{},重复{}次".format(i, c1.count(i)))
        #
        # if len(c2) == len(set(c2)):
        #     print('无重复')
        # else:
        #     print('重复')
        #     sl = set(c2)
        #     for i in sl:
        #         if c2.count(i) > 1:
        #             print("元素{},重复{}次".format(i, c2.count(i)))

        return c1, c2


# SBX
class BBRLCrossover(Crossover):
    def cross(self, population):
        new_population = []
        eta_c = 1.0
        for i in range(0, len(population), 2):
            p1 = population[i]
            p2 = population[i + 1]
            V = len(p1.x_list)
            rnd = np.random.random()
            if rnd < self._rate:
                bq = np.array([0] * V)
                randList = np.random.random(V)
                # 根据概率向量判断不同概率函数的选择
                orTF = (randList <= 0.5)
                # 计算不同决策变量的 不同概率选择 下的 系数
                for j in range(V):
                    if orTF[j]:
                        bq[j] = (2.0 * randList[j]) ** (1.0 / (eta_c + 1))
                    else:
                        bq[j] = (1.0 / (2.0 * (1 - randList[j]))) ** (1.0 / (eta_c + 1))

                new_p1 = 0.5 * ((1 + bq) * p1.x_list + (1 - bq) * p2.x_list)
                new_p2 = 0.5 * ((1 - bq) * p1.x_list + (1 + bq) * p2.x_list)

                child1 = BBRLIndividual(self._problem, new_p1)
                child2 = BBRLIndividual(self._problem, new_p2)

                for j in range(V):
                    if child1.x_list[j] < child1.x_LB[j] or child1.x_list[j] > child1.x_UB[j]:
                        if np.random.random() < 0.5:
                            child1.x_list[j] = min(max(child1.x_list[j], child1.x_LB[j]), child1.x_UB[j])
                        else:
                            child1.x_list[j] = np.random.uniform(child1.x_LB[j], child1.x_UB[j])
                    if child2.x_list[j] < child2.x_LB[j] or child2.x_list[j] > child2.x_UB[j]:
                        if np.random.random() < 0.5:
                            child2.x_list[j] = min(max(child2.x_list[j], child2.x_LB[j]), child2.x_UB[j])
                        else:
                            child2.x_list[j] = np.random.uniform(child2.x_LB[j], child2.x_UB[j])

                new_population.append(child1)
                new_population.append(child2)
            else:
                new_population.append(p1)
                new_population.append(p2)

        return new_population

    def cross1(self, population):
        new_population = []
        for i in range(0, len(population), 2):
            p1 = population[i]
            p2 = population[i + 1]
            c1 = copy.deepcopy(p1)
            c2 = copy.deepcopy(p2)
            rnd = np.random.random()
            if rnd < self._rate:
                # 选择：
                L = len(p1.x_list)
                I = np.random.choice(L, 2, replace=False)
                i1 = min(I)
                i2 = max(I)
                # 交换：
                for i in range(i1, i2 + 1):
                    c1.x_list[i] = p2[i]
                    c2.x_list[i] = p1[i]

                child1 = BBRLIndividual(self._problem, p1)
                child2 = BBRLIndividual(self._problem, p2)

                new_population.append(child1)
                new_population.append(child2)
            else:
                new_population.append(p1)
                new_population.append(p2)

        return new_population


class JBRFCrossover(Crossover):
    def cross(self, population):
        new_population = []
        for p in range(0, len(population), 2):
            par1 = population[p]
            par2 = population[p + 1]
            chd1 = copy.deepcopy(par1)
            chd2 = copy.deepcopy(par2)
            rnd = np.random.random()
            if rnd < self._rate:
                x1, x2 = self.PMX(chd1.x_list, chd2.x_list)
                for j in range(len(x1)):
                    chd1.x_list[j] = x1[j]
                    chd2.x_list[j] = x2[j]

            new_population.append(chd1)
            new_population.append(chd2)

        return new_population


class JBRACrossover(Crossover):
    def cross(self, population):
        new_population = []
        for p in range(0, len(population), 2):
            par1 = population[p]
            par2 = population[p + 1]
            chd1 = copy.deepcopy(par1)
            chd2 = copy.deepcopy(par2)
            rnd = np.random.random()
            if rnd < self._rate:
                i = np.random.randint(0, len(par1.x_list) - 1)
                x1, x2 = self.PMX(par1.x_list[i], par2.x_list[i])
                for j in range(len(x1)):
                    chd1.x_list[i][j] = x1[j]
                    chd2.x_list[i][j] = x2[j]

            new_population.append(chd1)
            new_population.append(chd2)

        return new_population


class MBRACrossover(Crossover):
    def cross(self, population):
        new_population = []
        for p in range(0, len(population), 2):
            par1 = population[p]
            par2 = population[p + 1]
            chd1 = copy.deepcopy(par1)
            chd2 = copy.deepcopy(par2)
            rnd = np.random.random()
            if rnd < self._rate:
                I = np.random.choice(len(chd1.x_list), 2, replace=False)
                i1 = min(I)
                i2 = max(I)
                j = np.random.randint(0, len(chd1.x_list[0]))
                for i in range(i1, i2 + 1):
                    chd1.x_list[i][j], chd2.x_list[i][j] = chd2.x_list[i][j], chd1.x_list[i][j]

            new_population.append(chd1)
            new_population.append(chd2)

        return new_population


class BBRFCrossover(Crossover):
    def cross(self, population):
        new_population = []
        for p in range(0, len(population), 2):
            par1 = population[p]
            par2 = population[p + 1]
            chd1: BBRFIndividual = copy.deepcopy(par1)
            chd2: BBRFIndividual = copy.deepcopy(par2)
            rnd = np.random.random()
            if rnd < self._rate:
                x1, x2 = self.PMX(chd1.j_list, chd2.j_list)
                for i in range(len(x1)):
                    chd1.j_list[i] = x1[i]
                    chd2.j_list[i] = x2[i]
                chd1.convert_jl_to_x()
                chd2.convert_jl_to_x()

            new_population.append(chd1)
            new_population.append(chd2)

        return new_population
