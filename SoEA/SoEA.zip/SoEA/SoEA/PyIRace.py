import itertools

import numpy as np
from scipy.optimize import dual_annealing

from irace import irace

from SoEA.PySoEA import SoEASolver
from SoEA.SoCrossover import *
from SoEA.SoIndividual import *
from SoEA.SoMutation import *
from SoEA.SoSelection import *
from model.problem import *
from SoEA.config import *


# This target_runner is over-complicated on purpose to show what is possible.
def target_runner(experiment, scenario):
    if scenario['debugLevel'] > 0:
        # Some configurations produced a warning, but the values are within the limits. That seems a bug in scipy.
        # TODO: Report the bug to scipy.
        print(f'{experiment["configuration"]}')
    id = experiment['id.instance']
    cfg = experiment['configuration']
    problem = Problem(f'SCC_3423_{id + 5}*[5-15]#1')
    print(problem.name)
    problem.read_instance()

    if f_dim == 'SO':
        problem.f_dim = 1
    else:
        problem.f_dim = 2
    problem.q_in_stage = {1: 20.0, 2: 4.0, 3: 8.0, 4: 5.0}
    if e_cons == 'NT':
        problem.Q_max = 1.e5
    else:
        problem.Q_max = 100

    print(cfg['pop_size'])
    solver = SoEASolver(encoder, problem, pop_size=int(cfg['pop_size']) * 10 + 30,
                        tfe_num=5000, p_cr=int(cfg['p_cr'])*0.05 + 0.7, p_mu=int(cfg['p_mu'])*0.05 + 0.1)
    solver.initialize()
    solver.execute()
    if f_dim == 'SO':
        return dict(cost=solver.best_fitness)
    else:
        return dict(cost=1/(len(solver.pf_data)+1))


parameters_table = '''
pop_size "" c (0, 1, 2, 3, 4, 5, 6 , 7)
p_cr "" c (0, 1, 2, 3, 4)
p_mu "" c (0, 1, 2, 3, 4)
'''

# print(parameters_table)

default_values = '''
pop_size    p_cr   p_mu
3  2    2
'''

# print(default_values)

# These are dummy "instances", we are tuning only on a single function.
instances = np.arange(5)

# See https://mlopez-ibanez.github.io/irace/reference/defaultScenario.html
scenario = dict(
    instances=instances,
    maxExperiments=100,
    debugLevel=3,
    digits=1,
    parallel=1,  # It can run in parallel !
    logFile="")

for _coder, _f_dim, _e_cons in itertools.product(encoder_list, f_dim_list, e_cons_list):
    encoder = _coder
    f_dim = _f_dim
    e_cons = _e_cons
    tuner = irace(scenario, parameters_table, target_runner)
    tuner.set_initial_from_str(default_values)
    best_confs = tuner.run()
    print(best_confs)

    file = open('results/irace_results.txt', 'a')
    file.write(f'\n{encoder}-{f_dim}-{e_cons}\n')
    file.write(best_confs.to_string())
    file.write('--------------------------------------------\n')
    file.close()
