import itertools

from SoEA.SoCrossover import *
from SoEA.SoIndividual import *
from SoEA.SoMutation import *
from SoEA.SoSelection import *
from SoEA.PySoEA import SoEASolver
from SoEA.utils import *
from model.problem import Problem
import time
import multiprocessing
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from SoEA.PySoMILP import *
from SoEA.config import *


def encoder_competing(problem, inst_no=1, round=5):
    f = open('./best_algo_confs.txt')
    line = f.readline()
    algo_confs = {}
    while line:
        line = f.readline()
        strs = line.split()
        if len(strs) > 2:
            key = f'{strs[0]}'
            algo_confs[key] = {'p_size': 30 + 10 * int(strs[1]), 'p_cr': 0.7 + 0.05 * int(strs[2]),
                               'p_mu': 0.1 + 0.05 * int(strs[3])}
    print(algo_confs)
    for f_dim, e_cons in itertools.product(f_dim_list, e_cons_list):
        if f_dim == 'SO':
            problem.f_dim = 1
        else:
            problem.f_dim = 2
        problem.q_in_stage = {1: 20.0, 2: 4.0, 3: 8.0, 4: 5.0}
        if e_cons == 'NT':
            problem.Q_max = 1.e5
        else:
            problem.Q_max = 100

        file = open(f'./results/{f_dim}-{e_cons}.txt', 'a')
        head = f'inst\tcoder\tno\tf_val\tcpu\n'
        file.write(head)
        round_list = [r + 1 for r in range(round)]
        for coder, r in itertools.product(encoder_list, round_list):
            problem.reset()
            scenario = f'{coder}-{f_dim}-{e_cons}'
            solver = SoEASolver(coder, problem, pop_size=algo_confs[scenario]['p_size'], tfe_num=5000,
                                p_cr=algo_confs[scenario]['p_cr'], p_mu=algo_confs[scenario]['p_mu'])
            start = time.perf_counter()
            solver.initialize()
            solver.execute()
            end = time.perf_counter()
            cpu = end - start
            if problem.f_dim > 1:
                for z in solver.pf_data:
                    log = f'{inst_no}#\t{coder}\t{r}\t{z[0]:.2f},{z[1]:.2f}\t{cpu:.0f}\n'
                    file.write(log)
            else:
                log = f'{inst_no}#\t{coder}\t{r}\t{solver.best_obj:.2f}\t{cpu:.0f}\n'
                file.write(log)

        file.close()


def mo_competing(problem, no, round):
    history_data = {'BBRL': [], 'BBRF': [], 'JBRF': [], 'JBRA': [], 'MBRA': []}
    cpu_data = {}
    keys = [key for key in history_data.keys()]
    for name in keys:
        solver = SoEASolver(name, problem)
        start = time.perf_counter()
        print('-----------------------------' + no + ' @' + name + '----------------------------')
        solver.initialize()
        solver.execute()
        history_data[name] = [z for z in solver.history_data]
        history_data[name + '_x'] = [z[0] for z in solver.history_data]
        history_data[name + '_y'] = [z[1] for z in solver.history_data]
        end = time.perf_counter()
        print(end - start)
        cpu_data[name] = end - start

    # sns.set_style("darkgrid")
    # sns.scatterplot(x=history_data['BBRL_x'], y=history_data['BBRL_y'], label='BBRL')
    # sns.scatterplot(x=history_data['BBRF_x'], y=history_data['BBRF_y'], label='BBRF')
    # sns.scatterplot(x=history_data['JBRF_x'], y=history_data['JBRF_y'], label='JBRF')
    # sns.scatterplot(x=history_data['JBRA_x'], y=history_data['JBRA_y'], label='JBRA')
    # sns.scatterplot(x=history_data['MBRA_x'], y=history_data['MBRA_y'], label='MBRA')
    #
    # plt.legend(fontsize=11)
    # plt.xlabel('Cmax')
    # plt.ylabel('Wtot')
    # plt.show()
    file = open('obj2' + '_' + str(problem.Q_max) + '_r' + str(round) + '.txt', 'a')
    for name in keys:
        T = cpu_data[name]
        file.write(f'{no}, {name}, {T:.0f} \n')
        f_set = set(history_data[name])
        for f1, f2 in f_set:
            file.write(f'{f1:.2f}, {f2:.2f} \n')

    file.write(f'\n')
    file.close()


def test_SOLS(problem: Problem):
    config = {'local': ['LS', 'NL'], 'threshold': ['ET', 'NT']}
    history_data = {ls + '_' + th: [] for ls, th in itertools.product(config['local'], config['threshold'])}
    for ls, th in itertools.product(config['local'], config['threshold']):
        if th == 'ET':
            problem.Q_max = 100
            solver = SoEASolver('BBRL', problem, pop_size=80, tfe_num=5600, p_cr=0.85, p_mu=0.25)
        else:
            problem.Q_max = 1000
            solver = SoEASolver('BBRL', problem, pop_size=80, tfe_num=5600, p_cr=0.75, p_mu=0.15)
        problem.f_dim = 1
        if ls == 'LS':
            solver.has_local_search = True
        else:
            solver.has_local_search = False

        solver.initialize()
        solver.execute()
        history_data[ls + '_' + th] = [z for z in solver.history_data]

    file = open('./results/SOLS.txt', 'a')
    sns.set_style('ticks')
    plt.figure(figsize=(8, 5))
    for key, data in history_data.items():
        x = [d[0] for d in data]
        y = [d[1] for d in data]
        if key == 'LS_ET':
            plt.plot(x, y, color='r', linewidth=0.8, marker='o', markersize=4, label=key)
        if key == 'NL_ET':
            plt.plot(x, y, color='b', linewidth=0.8, marker='o', markersize=4, label=key)
        if key == 'LS_NT':
            plt.plot(x, y, color='r', linewidth=0.8, marker='x', markersize=5, label=key)
        if key == 'NL_NT':
            plt.plot(x, y, color='b', linewidth=0.8, marker='x', markersize=5, label=key)

        file.write(f'{problem.name}, {key}, {0} \n')
        for t, f in data:
            file.write(f'{t:.0f}, {f:.2f} \n')
    file.write(f'\n')
    file.close()

    plt.legend(fontsize=9)
    plt.xlabel('iteration', fontsize=11)
    plt.ylabel('objective', fontsize=11)
    plt.show()


def test_MOLS(problem: Problem):
    config = {'local': ['LS', 'NL'], 'threshold': ['ET', 'NT']}
    history_data = {ls + '_' + th: [] for ls, th in itertools.product(config['local'], config['threshold'])}
    for ls, th in itertools.product(config['local'], config['threshold']):
        if th == 'ET':
            problem.Q_max = 100
            solver = SoEASolver('BBRL', problem, pop_size=90, tfe_num=5600, p_cr=0.85, p_mu=0.30)
        else:
            problem.Q_max = 1000
            solver = SoEASolver('BBRL', problem, pop_size=90, tfe_num=5600, p_cr=0.85, p_mu=0.25)
        problem.f_dim = 2

        if ls == 'LS':
            solver.has_local_search = True
        else:
            solver.has_local_search = False
        solver.initialize()
        solver.execute()
        history_data[ls + '_' + th] = [z for z in solver.pf_data]

    sns.set_style('ticks')
    file = open('./results/MOLS.txt', 'a')
    for key, data in history_data.items():
        f1 = [d[0] for d in data]
        f2 = [d[1] for d in data]
        if key == 'LS_ET':
            sns.scatterplot(x=f1, y=f2, color='r', marker='o', label=key)
        if key == 'NL_ET':
            sns.scatterplot(x=f1, y=f2, color='b', marker='o', label=key)
        if key == 'LS_NT':
            sns.scatterplot(x=f1, y=f2, color='r', marker='x', label=key)
        if key == 'NL_NT':
            sns.scatterplot(x=f1, y=f2, color='b', marker='x', label=key)
        file.write(f'{problem.name}, {key}, {0} \n')
        for f1, f2 in data:
            file.write(f'{f1:.2f}, {f2:.2f} \n')

    file.write(f'\n')
    file.close()

    plt.legend(fontsize=9)
    plt.xlabel('Cmax', fontsize=11)
    plt.ylabel('Wtot', fontsize=11)
    plt.show()


def test_MILP_solver(has_threshold=False, use_SoEA=False, batch_num=2, no=1):
    p_name = f'SCC_242_{batch_num}*[4-8]#{no}'
    problem = Problem(p_name)
    problem.f_dim = 1
    problem.q_in_stage = {1: 1.0, 2: 1.0, 3: 1.0}
    problem.read_instance()
    if use_SoEA:
        if has_threshold:
            problem.Q_max = 7
        else:
            problem.Q_max = 1.e5
        solver = SoEASolver(p_name, problem, tfe_num=500 * batch_num)
        start = time.perf_counter()
        solver.assign_components(CodeType.BBRL, SoTournamentSelection(solver.POP_SIZE, k=2),
                                 BBRLCrossover(Pc, problem), BBRLMutation(Pm, problem))
        solver.initialize()
        solver.execute()
        end = time.perf_counter()
        print(end - start)
        problem.show_in_gantt()
    else:
        if has_threshold:
            problem.Q_max = 7
            solve_et_by_optimizer(problem)
        else:
            problem.Q_max = 1.e5
            solve_nt_by_optimizer(problem)


def main():

    # for r, n, m, Q in itertools.product([r for r in range(1, 6)], [n for n in range(1, 21)],
    #                                     [1, 2], [100, 1000]):
    #     if n < 11:
    #         NAME = 'DMOP_3423_6*[5-15]#' + str(n)
    #     else:
    #         NAME = 'DMOP_3423_10*[5-15]#' + str(n - 10)
    #     problem = Problem(NAME)
    #     problem.read_instance()
    #     problem.reset()
    #     problem.Q_max = Q
    #     problem.f_dim = m
    #     if m == 1:
    #         so_competing(problem, '#' + str(n), r)
    #     else:
    #         mo_competing(problem, '#' + str(n), r)

    # idx = 1
    # for h, n in itertools.product([h for h in range(1, 6)], [n for n in range(1, 5)]):
    #     name = f'SCC_3423_{h + 5}*[5-15]#{n}'
    #     print(f'{idx}={name}')
    #     problem = Problem(name)
    #     problem.read_instance()
    #     if h == 1 and n == 1:
    #         pass
    #     else:
    #         encoder_competing(problem, idx, 5)
    #     idx = idx + 1

    # test_MILP_solver(has_threshold=True, use_SoEA=False, batch_num=4, no=5)

    name = f'SCC_3423_{10}*[5-15]#{1}'
    problem = Problem(name)
    problem.read_instance()
    test_MOLS(problem)

    return


if __name__ == '__main__':
    print('CPU:', multiprocessing.cpu_count())
    main()
