import pyomo.environ as pyo
import sqlite3
import matplotlib.pyplot as plt
import matplotlib as mpl
import pandas as pd
import math
from model.problem import *
from model.entities import *


def solve_et_by_optimizer(problem: Problem):
    model = pyo.ConcreteModel("ET-SCCP")
    Imax = len(problem.stages)
    if len(problem.batches) == 2:
        Tmax = 400
    elif len(problem.batches) == 3:
        Tmax = 640
    else:
        Tmax = 720
    # set of periods is constructed from a python set
    model.Periods = pyo.RangeSet(Tmax)
    x_list = []
    y_list = []
    z_list = []
    for stage in problem.stages.values():
        for op1 in stage.operations.values():
            if stage.id < Imax:
                for ma in stage.machines.values():
                    x_list.append((op1.id[0], op1.id[1], ma.id[1]))
                for op2 in stage.operations.values():
                    y_list.append((op1.id[0], op1.id[1], op2.id[1]))
            for t in range(Tmax):
                z_list.append((op1.id[0], op1.id[1], t))
    # variables
    model.z_var = pyo.Var(z_list, domain=pyo.Binary)
    model.w_var = pyo.Var(z_list, domain=pyo.Binary)
    model.x_var = pyo.Var(x_list, domain=pyo.Binary)
    model.y_var = pyo.Var(y_list, domain=pyo.Binary)
    model.s_var = pyo.Var(problem.operations.keys(), domain=pyo.NonNegativeReals)

    model.constr = pyo.ConstraintList()
    for stage in problem.stages.values():
        if stage.id == Imax:
            continue
        for op in stage.operations.values():
            x_cons = []
            i = stage.id
            j = op.job.id
            for ma in stage.machines.values():
                k = ma.id[1]
                x_cons.append(model.x_var[i, j, k])
            model.constr.add(sum(x_cons) == 1)

    for stage in problem.stages.values():
        if stage.id == Imax:
            continue
        for op1 in stage.operations.values():
            for op2 in stage.operations.values():
                i = stage.id
                j1 = op1.job.id
                j2 = op2.job.id
                if j1 != j2:
                    model.constr.add(model.y_var[i, j1, j2] + model.y_var[i, j2, j1] == 1)

    for op in problem.operations.values():
        prev_op = op.prev_oper
        if prev_op is None:
            continue
        i1 = prev_op.stage.id
        i2 = op.stage.id
        j = op.job.id
        model.constr.add(model.s_var[i2, j] - model.s_var[i1, j] >= prev_op.duration + prev_op.time_to_next)

    for stage in problem.stages.values():
        if stage.id == Imax:
            continue
        for op1 in stage.operations.values():
            for op2 in stage.operations.values():
                i = stage.id
                j1 = op1.id[1]
                j2 = op2.id[1]
                if j1 == j2:
                    continue
                for ma in stage.machines.values():
                    k = ma.id[1]
                    model.constr.add(model.s_var[i, j2] - model.s_var[i, j1] + 1.0e4 *
                                     (3 - model.x_var[i, j1, k] - model.x_var[i, j2, k] - model.y_var[
                                         i, j1, j2]) >= op1.duration)
    ma_bh_dict = {}
    for batch in problem.batches.values():
        job_num = len(batch.jobs)
        des_mach = batch.dest_machine
        j0 = batch.jobs[0].id
        if des_mach.id not in ma_bh_dict.keys():
            model.constr.add(model.s_var[Imax, j0] >= batch.setup_time)
            ma_bh_dict[des_mach.id] = [batch]
        else:
            last_batch = ma_bh_dict[des_mach.id][-1]
            jx = last_batch.jobs[-1].id
            last_oper = problem.operations[(Imax, jx)]
            model.constr.add(model.s_var[Imax, j0] - model.s_var[Imax, jx] >= batch.setup_time + last_oper.duration)
            ma_bh_dict[des_mach.id].append(batch)
        for l in range(1, job_num):
            j1 = batch.jobs[l - 1].id
            j2 = batch.jobs[l].id
            op1 = problem.operations[Imax, j1]
            model.constr.add(model.s_var[Imax, j2] - model.s_var[Imax, j1] == op1.duration)

    for op in problem.operations.values():
        z_cons = []
        z_conx = []
        i, j = op.id
        for t in range(0, Tmax):
            # model.constr.add(t + 1.0e4 * (1 - model.z_var[i, j, t]) >= model.s_var[i, j])
            # model.constr.add(t + 1.0e4 * (model.z_var[i, j, t] - 1) <= model.s_var[i, j] + op.duration)
            z_cons.append(model.z_var[i, j, t])
            z_conx.append(t * model.z_var[i, j, t])
        model.constr.add(model.s_var[i, j] == sum(z_conx))
        model.constr.add(sum(z_cons) == 1)

        for t in range(0, Tmax):
            st = max(0, t - op.duration)
            model.constr.add(model.w_var[i, j, t] == sum(model.z_var[i, j, tt] for tt in range(st, t + 1)))

    for t in range(0, Tmax):
        w_cons = []
        for op in problem.operations.values():
            i, j = op.id
            w_cons.append(model.w_var[i, j, t])
        model.constr.add(sum(w_cons) <= problem.Q_max)

    model.Cmax = pyo.Var(domain=pyo.NonNegativeReals)
    for j in problem.jobs.keys():
        op = problem.operations[Imax, j]
        model.constr.add(model.Cmax >= model.s_var[Imax, j] + op.duration)

    Wtot = 0
    for op in problem.operations.values():
        prev_op = op.prev_oper
        if prev_op is None:
            continue
        i1 = prev_op.stage.id
        i2 = op.stage.id
        j = op.job.id
        Wtot += model.s_var[i2, j] - model.s_var[i1, j] - prev_op.duration - prev_op.time_to_next
    model.obj = pyo.Objective(expr=0.2 * model.Cmax + 0.8 * Wtot, sense=pyo.minimize)

    print('NBV=', len(model.x_var) + len(model.y_var) + len(model.z_var) + len(model.w_var))
    print('NCV=', len(model.s_var))
    print('NCN=', len(model.constr))

    solver = pyo.SolverFactory('cplex')
    solver.options['timelimit'] = 600
    results = solver.solve(model)
    if results.solver.status != pyo.SolverStatus.ok:
        print('infeasible')
        return None
    print(results)
    print('problem is solved successfully....')
    print('obj=', model.obj())
    for stage in problem.stages.values():
        for op in stage.operations.values():
            i = stage.id
            j = op.job.id
            # for t in range(Tmax):
            #     if int(model.w_var[i, j, t].value) > 0:
            #         print(i, j, t, int(model.w_var[i, j, t].value))
            mx = None
            if i < Imax:
                for ma in stage.machines.values():
                    k = ma.id[1]
                    if int(model.x_var[i, j, k].value) > 0:
                        mx = ma
            else:
                mx = op.job.batch.dest_machine
            op.start_time = int(model.s_var[i, j].value)
            op.machine = mx
            # print(op.id, op.machine)
            # print(op.id, '=', op.start_time, '-', op.end_time, '@', op.machine.id)

    problem.show_in_gantt()
    # print(tasks_dict[i, j]['start'], tasks_dict[i, j]['finish'])


def solve_nt_by_optimizer(problem: Problem):
    model = pyo.ConcreteModel("NT-SCCSP")
    Imax = len(problem.stages)
    # set of periods is constructed from a python set
    x_list = []
    y_list = []
    for stage in problem.stages.values():
        for op1 in stage.operations.values():
            if stage.id < Imax:
                for ma in stage.machines.values():
                    x_list.append((op1.id[0], op1.id[1], ma.id[1]))
                for op2 in stage.operations.values():
                    y_list.append((op1.id[0], op1.id[1], op2.id[1]))
    # variables
    model.x_var = pyo.Var(x_list, domain=pyo.Binary)
    model.y_var = pyo.Var(y_list, domain=pyo.Binary)
    model.s_var = pyo.Var(problem.operations.keys(), domain=pyo.NonNegativeReals)

    model.constr = pyo.ConstraintList()
    for stage in problem.stages.values():
        if stage.id == Imax:
            continue
        for op in stage.operations.values():
            x_cons = []
            i = stage.id
            j = op.job.id
            for ma in stage.machines.values():
                k = ma.id[1]
                x_cons.append(model.x_var[i, j, k])
            model.constr.add(sum(x_cons) == 1)

    for stage in problem.stages.values():
        if stage.id == Imax:
            continue
        for op1 in stage.operations.values():
            for op2 in stage.operations.values():
                i = stage.id
                j1 = op1.job.id
                j2 = op2.job.id
                if j1 != j2:
                    model.constr.add(model.y_var[i, j1, j2] + model.y_var[i, j2, j1] == 1)

    for op in problem.operations.values():
        prev_op = op.prev_oper
        if prev_op is None:
            continue
        i1 = prev_op.stage.id
        i2 = op.stage.id
        j = op.job.id
        model.constr.add(model.s_var[i2, j] - model.s_var[i1, j] >= prev_op.duration + prev_op.time_to_next)

    for stage in problem.stages.values():
        if stage.id == Imax:
            continue
        for op1 in stage.operations.values():
            for op2 in stage.operations.values():
                i = stage.id
                j1 = op1.id[1]
                j2 = op2.id[1]
                if j1 == j2:
                    continue
                for ma in stage.machines.values():
                    k = ma.id[1]
                    model.constr.add(model.s_var[i, j2] - model.s_var[i, j1] + 1.0e4 *
                                     (3 - model.x_var[i, j1, k] - model.x_var[i, j2, k] - model.y_var[
                                         i, j1, j2]) >= op1.duration)
    ma_bh_dict = {}
    for batch in problem.batches.values():
        job_num = len(batch.jobs)
        des_mach = batch.dest_machine
        j0 = batch.jobs[0].id
        if des_mach.id not in ma_bh_dict.keys():
            model.constr.add(model.s_var[Imax, j0] >= batch.setup_time)
            ma_bh_dict[des_mach.id] = [batch]
        else:
            last_batch = ma_bh_dict[des_mach.id][-1]
            jx = last_batch.jobs[-1].id
            last_oper = problem.operations[(Imax, jx)]
            model.constr.add(model.s_var[Imax, j0] - model.s_var[Imax, jx] >= batch.setup_time + last_oper.duration)
            ma_bh_dict[des_mach.id].append(batch)
        for l in range(1, job_num):
            j1 = batch.jobs[l - 1].id
            j2 = batch.jobs[l].id
            op1 = problem.operations[Imax, j1]
            model.constr.add(model.s_var[Imax, j2] - model.s_var[Imax, j1] == op1.duration)

    model.Cmax = pyo.Var(domain=pyo.NonNegativeReals)
    for j in problem.jobs.keys():
        op = problem.operations[Imax, j]
        model.constr.add(model.Cmax >= model.s_var[Imax, j] + op.duration)

    Wtot = 0
    for op in problem.operations.values():
        prev_op = op.prev_oper
        if prev_op is None:
            continue
        i1 = prev_op.stage.id
        i2 = op.stage.id
        j = op.job.id
        Wtot += model.s_var[i2, j] - model.s_var[i1, j] - prev_op.duration - prev_op.time_to_next
    model.obj = pyo.Objective(expr=0.2 * model.Cmax + 0.8 * Wtot, sense=pyo.minimize)

    print('NBV=', len(model.x_var) + len(model.y_var))
    print('NCV=', len(model.s_var))
    print('NCN=', len(model.constr))

    solver = pyo.SolverFactory('cplex')
    solver.options['timelimit'] = 300
    results = solver.solve(model)
    if results.solver.status != pyo.SolverStatus.ok:
        print('infeasible')
        return None
    print(results.solver)
    print('problem is solved successfully....')
    print('obj=', model.obj())
    for stage in problem.stages.values():
        for op in stage.operations.values():
            i = stage.id
            j = op.job.id
            mx = None
            if i < Imax:
                for ma in stage.machines.values():
                    k = ma.id[1]
                    if round(model.x_var[i, j, k].value) > 0:
                        mx = ma
            else:
                mx = op.job.batch.dest_machine
            op.start_time = int(model.s_var[i, j].value)
            op.machine = mx
            # print(op.id, op.machine)
            print(op.id, '=', op.start_time, '-', op.end_time, '@', op.machine.id)

    problem.show_in_gantt()
