# LeHMOEA-for-EoHFSP
this repo uses learning-enhanced MOEA to solve energy-oriented hybrid flow shop scheduling problem
