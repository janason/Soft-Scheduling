#!/usr/bin/python
# # -*- coding:utf-8 -*-
import math
import random


def scalar_func(numObjectives, idealpoint, y_obj, namda, strFunctionType="_TCH1"):
    fvalue = 0;
    # Tchebycheff approach // 切比雪夫方法
    if strFunctionType == "_TCH1":
        max_fun = -1.0e+30;
        for n in range(numObjectives):
            diff = math.fabs(y_obj[n] - idealpoint[n])
            # if namda[n] == 0:
            #     feval = 0.00001 * diff
            # else:
            feval = diff * namda[n]
            if feval > max_fun:
                max_fun = feval
        fvalue = max_fun

    #  normalized Tchebycheff approach // 正则化切比雪夫方法
    if strFunctionType == "_TCH2":
        pass

    # * Boundary intersection approach  //插界法

    if strFunctionType == "_PBI":
        pass

    return fvalue


def minFastSort(x, idx, n, m):
    """
    x   : list of floats
    idx : list of integers (each an index)
    n   : integer
    m   : integer
    """
    for i in range(m):
        for j in range(i + 1, n):
            if x[i] > x[j]:
                temp = x[i]
                x[i] = x[j]
                x[j] = temp
                id_ = idx[i]
                idx[i] = idx[j]
                idx[j] = id_


def roulette(ratios):
    """
    轮盘赌选择算法
    :param ratios: 比例
    :return: 被选择的个体
    """
    # 计算总适应度
    tot_val = sum(ratios)

    # 生成一个随机数
    random_value = random.uniform(0, 1)

    # 选择个体
    cumulative_val = 0
    for i in range(len(ratios)):
        tot_val += ratios[i]
        if tot_val > random_value:
            return i


def fast_non_dominated_sorting(x_list=None):
    S = [[] for i in range(0, len(x_list))]
    front = [[]]
    n = [0 for i in range(0, len(x_list))]
    rank = [0 for i in range(0, len(x_list))]
    for p in range(0, len(x_list)):
        S[p] = []
        n[p] = 0
        pSol: TIndividual = x_list[p]
        for q in range(0, len(x_list)):
            qSol: TIndividual = x_list[q]
            if pSol < qSol:
                if q not in S[p]:
                    S[p].append(q)
            elif qSol < pSol:
                n[p] = n[p] + 1
        if n[p] == 0:
            rank[p] = 0
            if p not in front[0]:
                front[0].append(p)
    i = 0
    while len(front[i]) != 0:
        Q = []
        for p in front[i]:
            for q in S[p]:
                n[q] = n[q] - 1
                if n[q] == 0:
                    rank[q] = i + 1
                    if q not in Q:
                        Q.append(q)
        i = i + 1
        front.append(Q)
    del front[len(front) - 1]

    # self.EAP = [x_list[i] for i in front[0]]

    return front, rank


def calculate_convergence(POP, EAP):
    CV = 0
    for ind1 in POP:
        min_dis = 10 ** 6
        for ind2 in EAP:
            dis = (ind1.y_obj[0] - ind2.y_obj[0]) ** 2 + (ind1.y_obj[1] - ind2.y_obj[1]) ** 2
            if dis < min_dis:
                min_dis = dis
        CV += min_dis
    return math.sqrt(CV) / len(POP)


def calculate_diversity(POP):
    Q = sorted(POP, key=lambda x: (x.y_obj[0], -x.y_obj[1]))
    d_list = []
    for i in range(1, len(Q)):
        ind1 = Q[i - 1]
        ind2 = Q[i]
        d_list.append((ind1.y_obj[0] - ind2.y_obj[0]) ** 2 + (ind1.y_obj[1] - ind2.y_obj[1]) ** 2)
    d_avg = sum(d_list) *1.0 / len(d_list)
    dv = sum([math.fabs(d - d_avg) for d in d_list]) / (len(d_list) * d_avg+1)
    return dv


def calculate_crowding_distance(fronts, ranks, x_list=None):
    sort_ranks = [[ranks[i], -1, i] for i in range(len(ranks))]
    for front in fronts:
        fn = len(front)
        xlist = [x_list[i] for i in front]
        crowding_distance = [0] * fn
        for m in range(len(xlist[0].y_obj)):
            xlist.sort(key=lambda sol: sol.y_obj[m])
            crowding_distance[0] = 10 ** 6
            crowding_distance[fn - 1] = 10 ** 6
            m_values = [sol.y_obj[m] for sol in xlist]
            scale = max(m_values) - min(m_values)
            if scale == 0:
                scale = 1
            for i in range(1, fn - 1):
                crowding_distance[i] += (xlist[i + 1].y_obj[m] - xlist[i - 1].y_obj[m]) / scale
        for i, j in enumerate(front):
            sort_ranks[j][1] = crowding_distance[i]
    sort_ranks.sort(key=lambda x: (x[0], -x[1]))
    return [rd[2] for rd in sort_ranks]


def find_critical_path(indv, op):
    u_op = op
    path = [u_op]
    while True:
        vop1 = indv.prevs_of_op[u_op][0]
        vop2 = indv.prevs_of_op[u_op][1]
        if vop1 == (0, 0) and vop2 == (0, 0):
            break
        if vop2 != (0, 0):
            et_vop2 = indv.tminfo_of_op[vop2][3]  # endtime
        else:
            et_vop2 = -10
        st_uop = indv.tminfo_of_op[u_op][2]  # starttime
        if st_uop == et_vop2:
            path.append(vop2)
            u_op = vop2
        else:
            path.append(vop1)
            u_op = vop1
        if u_op == (0, 0):
            break
    path.reverse()
    return path


def calc_dist(vec1, vec2):
    sum = 0
    for n in range(len(vec1)):
        sum += (vec1[n] - vec2[n]) * (vec1[n] - vec2[n])
    return math.sqrt(sum)

def tour_select(pop, tour_size):
    xpop = [(i,idv) for i,idv in enumerate(pop)]
    pool = random.sample(xpop,k=tour_size)
    pool.sort(key=lambda row: row[0])
    return pool[0][1]