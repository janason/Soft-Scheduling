import copy
import itertools
import time

from abc import ABC
import random

import numpy as np

from hybrid_flow_shop.problem import Problem
from algorithm.MOEA import MOEA
from algorithm.individual import TIndividual
from common.utils import fast_non_dominated_sorting, calculate_crowding_distance


class MoEDA(MOEA, ABC):
    def __init__(self, problem: Problem, popsize, epochs):
        super().__init__(problem, popsize, epochs)
        self.pc = 1.0
        self.pm = 0.05

    def name(self):
        return 'NSGA-II'

    def initialize(self):
        super().initialize()
        fronts, ranks = fast_non_dominated_sorting(self.POP)
        sort_idx = calculate_crowding_distance(fronts, ranks, self.POP)
        self.POP = [self.POP[i] for i in sort_idx[0:self.P_size]]
        self.EAP = [self.POP[i] for i in fronts[0]]
        self.update_ideal_distance()
        print("epoch=", 0, " EAP size=", len(self.EAP))

    # ---- 构建位置概率模型 ----
    def build_prob_matrix(self, pop, n_jobs):
        matrix = np.ones((n_jobs, n_jobs))  # 初始为1避免0概率
        for ind in pop:
            for pos, job in enumerate(ind.x_var):
                matrix[pos][job-1] += 1
        matrix = matrix / matrix.sum(axis=1, keepdims=True)
        return matrix

    # ---- 基于概率矩阵采样 ----
    def sample_from_matrix(self, prob_matrix):
        n_jobs = prob_matrix.shape[0]
        selected = [0] * n_jobs
        available_jobs = list(range(n_jobs))
        for p in range(n_jobs):
            probs = np.array([prob_matrix[p][j] for j in available_jobs])
            probs /= probs.sum()
            job = np.random.choice(available_jobs, p=probs)
            selected[p] = job + 1
            available_jobs.remove(job)
        child = TIndividual(self.problem, selected)
        return child


    def execute(self):
        t1 = time.perf_counter()
        for ep in range(self.epochs):
            offspring = []
            # 按两个目标分别选出前半数精英
            n_elite = self.P_size//2
            n_jobs = len(self.problem.jobs)
            elite_tardiness = sorted(self.POP, key=lambda x: x.y_obj[0])[:n_elite]
            elite_idle = sorted(self.POP, key=lambda x: x.y_obj[1])[:n_elite]

            # 构建两个目标的概率模型
            M_tardiness = self.build_prob_matrix([x for x in elite_tardiness], n_jobs)
            M_idle = self.build_prob_matrix([x for x in elite_idle], n_jobs)

            # 混合采样（简单轮换采样）
            offspring = []
            for i in range(self.P_size):
                if i % 2 == 0:
                    new_ind = self.sample_from_matrix(M_tardiness)
                else:
                    new_ind = self.sample_from_matrix(M_idle)
                new_ind.decode()
                offspring.append(new_ind)
                self.update_archive(new_ind)

            self.POP.extend(offspring)
            fronts, ranks = fast_non_dominated_sorting(self.POP)
            sort_idx = calculate_crowding_distance(fronts, ranks, self.POP)
            self.POP = [self.POP[i] for i in sort_idx[0:self.P_size]]
            self.update_ideal_distance()
            print("epoch=", ep + 1, " EAP size=", len(self.EAP))
        t2 = time.perf_counter()
        print(f'cost= {t2 - t1:.8f}s')


