import copy
import itertools
import time

from abc import ABC
import random

from hybrid_flow_shop.problem import Problem
from algorithm.MOEA import MOEA
from algorithm.individual import TIndividual
from common.utils import fast_non_dominated_sorting, calculate_crowding_distance


class NSGA2(MOEA, ABC):
    def __init__(self, problem: Problem, popsize, epochs):
        super().__init__(problem, popsize, epochs)
        self.pc = 1.0
        self.pm = 0.05

    def name(self):
        return 'NSGA-II'

    def initialize(self):
        super().initialize()
        fronts, ranks = fast_non_dominated_sorting(self.POP)
        sort_idx = calculate_crowding_distance(fronts, ranks, self.POP)
        self.POP = [self.POP[i] for i in sort_idx[0:self.P_size]]
        self.EAP = [self.POP[i] for i in fronts[0]]
        self.update_ideal_distance()
        print("epoch=", 0, " EAP size=", len(self.EAP))

    def selectSol(self, sol_sols):
        p1 = random.randint(0, len(sol_sols) - 1)
        p2 = p1
        while p1 == p2:
            p2 = random.randint(0, len(sol_sols) - 1)
        return p1, p2

    def execute(self):
        t1 = time.perf_counter()
        for ep in range(self.epochs):
            offspring = []
            while len(offspring) < self.P_size:
                # 1.选择个体
                p1, p2 = random.sample(range(0, self.P_size), 2)
                chd1, chd2 = self.PMX_operator(self.POP[p1], self.POP[p2])
                offspring.append(chd1)
                offspring.append(chd2)
            for ind in offspring:
                self.mutate(ind, self.pm, size=2)
                ind.decode()
                self.update_archive(ind)

            self.POP.extend(offspring)
            fronts, ranks = fast_non_dominated_sorting(self.POP)
            sort_idx = calculate_crowding_distance(fronts, ranks, self.POP)
            self.POP = [self.POP[i] for i in sort_idx[0:self.P_size]]
            self.update_ideal_distance()
            print("epoch=", ep + 1, " EAP size=", len(self.EAP))
        t2 = time.perf_counter()
        print(f'cost= {t2 - t1:.8f}s')


