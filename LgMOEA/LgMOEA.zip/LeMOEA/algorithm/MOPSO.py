import time
from abc import ABC
import random
from algorithm.MOEA import MOEA
from algorithm.individual import TIndividual
from common.utils import fast_non_dominated_sorting, calculate_crowding_distance


class MOPSO(MOEA, ABC):
    def __init__(self, problem, popsize, epochs):
        super().__init__(problem, popsize, epochs)
        self.x_list = []
        self.p_best = []
        self.g_best = []
        self.v = []
        self.Vmax = 0.5
        self.Vmin = -0.5
        self.w = 0.5
        self.c1 = 0.15
        self.c2 = 0.15
        self.LZ = 3
        self.GZ = 8

    def name(self):
        return 'MOPSO'

    def initialize(self):
        super().initialize()
        self.ptcl_list = []
        self.p_best = []
        self.g_best = []
        self.v = []
        for p in range(self.P_size):
            indv: TIndividual = self.POP[p]
            N = len(indv.x_var)
            x = [(0, 0)] * N
            for j, s in enumerate(indv.x_var):
                x[s - 1] = j / N
            self.x_list.append(x)
            self.p_best.append([(x, indv)])
            self.v.append([self.Vmax] * N)
            self.update_archive(indv)

        fronts, ranks = fast_non_dominated_sorting(self.POP)
        sort_idx = calculate_crowding_distance(fronts, ranks, self.POP)
        for i in sort_idx[0: self.GZ]:
            self.g_best.append((self.x_list[i], self.POP[i]))
        print("epoch=", 0, " EAP size=", len(self.EAP))

        # self.pg = best_sol.slab_no_seq

    def update_position(self):
        gb = random.choice(self.g_best)
        g_x = []
        g_s = []
        for p in range(self.P_size):
            x = self.x_list[p]
            indv = self.POP[p]
            v = self.v[p]
            pb = random.choice(self.p_best)
            new_v = []
            new_x = []
            r1 = random.random()
            r2 = random.random()
            for i in range(len(v)):
                v_ = self.w * v[i] + self.c1 * r1 * (pb[0][i] - x[i]) + self.c2 * r2 * (gb[0][i] - x[i])
                new_v.append(min(v_, self.Vmax))
                new_x.append(max(x[i] + new_v[i], 0))

            new_indv: TIndividual = self.trans_x2sol(new_x)
            self.v[p] = new_v
            self.POP[p] = new_indv
            self.x_list[p] = new_x
            self.update_archive(new_indv)

            pareto_set = [(x, s) for (x, s) in self.p_xs[p] if not new_parc < s]
            if not any(s < new_parc for (x, s) in pareto_set):
                pareto_set.append((new_x, new_parc))
            if len(pareto_set) > self.LZ:
                self.p_xs[p] = random.sample(pareto_set, self.LZ)
            else:
                self.p_xs[p] = pareto_set

            for j in range(len(self.p_xs[p])):
                xx = self.p_xs[p][j]
                g_x.append(xx[0])
                g_s.append(xx[1])

        fronts, ranks = fast_non_dominated_sorting(g_s)
        sort_idx = calculate_crowding_distance(fronts, ranks, g_s)
        for i in sort_idx[0: self.GZ]:
            self.g_xs.append((g_x[i], g_s[i]))

    def trans_x2sol(self, x):
        sorted_x = sorted(enumerate(x), key=lambda x: x[1])
        seq = [i[0] + 1 for i in sorted_x if i[1] > 0]
        indv = TIndividual(self.problem, x_list=seq)
        indv.decode()
        return indv

    def execute(self):
        t1 = time.perf_counter()
        for ep in range(self.epochs):
            gb = random.choice(self.g_best)
            g_x_list = []
            g_p_list = []
            for p in range(self.P_size):
                x = self.x_list[p]
                indv = self.POP[p]
                v = self.v[p]
                pb = random.choice(self.p_best[p])
                new_v = []
                new_x = []
                r1 = random.random()
                r2 = random.random()
                for i in range(len(v)):
                    v_ = self.w * v[i] + self.c1 * r1 * (pb[0][i] - x[i]) + self.c2 * r2 * (gb[0][i]  - x[i])
                    new_v.append(min(v_, self.Vmax))
                    new_x.append(max(x[i] + new_v[i], 0))

                new_indv: TIndividual = self.trans_x2sol(new_x)
                self.v[p] = new_v
                self.POP[p] = new_indv
                self.x_list[p] = new_x
                self.update_archive(new_indv)

                pareto_set = [(x, s) for (x, s) in self.p_best[p] if not new_indv < s] # 不被new支配的保留
                if not any(s < new_indv for (x, s) in pareto_set): # 没人支配 new，加入
                    pareto_set.append((new_x, new_indv))
                if len(pareto_set) > self.LZ:
                    self.p_best[p] = random.sample(pareto_set, self.LZ)
                else:
                    self.p_best[p] = pareto_set
                for j in range(len(self.p_best[p])):
                    g_x_list.append(self.p_best[p][j][0])
                    g_p_list.append(self.p_best[p][j][1])

            fronts, ranks = fast_non_dominated_sorting(g_p_list)
            sort_idx = calculate_crowding_distance(fronts, ranks, g_p_list)
            for i in sort_idx[0: self.GZ]:
                self.g_best.append((g_x_list[i], g_p_list[i]))

            self.update_ideal_distance()
            print("epoch=", ep + 1, " EAP size=", len(self.EAP))

        t2 = time.perf_counter()
        print(f'cost= {t2 - t1:.8f}s')
