import time

from abc import ABC
import random

from hybrid_flow_shop.problem import Problem
from algorithm.MOEA import MOEA
from algorithm.individual import TIndividual

from common.utils import *


class EagMOEAd(MOEA, ABC):
    def __init__(self, problem: Problem, popsize, epochs):
        super().__init__(problem, popsize, epochs)
        self.pc = 1.0
        self.pm = 0.05
        self.T_size = max(int(0.1 * self.P_size), 5)
        self.lambda_ = [[0, 0] for _ in range(self.P_size)]
        self.Neigh = [[] for _ in range(self.P_size)]
        self.z = [10 ** 4, 10 ** 4]
        self._Sg = []

    def name(self):
        return 'MOEA/d'

    def init_weight(self):
        for n in range(self.P_size):
            a = 1.0 * float(n) / (self.P_size - 1)
            self.lambda_[n][0] = a
            self.lambda_[n][1] = 1 - a

    def init_Neigh(self):
        for i in range(self.P_size):
            x = [[-1, -1] for _ in range(self.P_size)]
            for j in range(self.P_size):
                x[j][0] = calc_dist(self.lambda_[i], self.lambda_[j])
                x[j][1] = j
            x.sort(key=lambda x: x[0])
            self.Neigh[i] = [x[k][1] for k in range(self.T_size)]

    def update_ref_point(self, ind):
        if ind.y_obj[0] < self.z[0]:
            self.z[0] = ind.y_obj[0]
        if ind.y_obj[1] < self.z[1]:
            self.z[1] = ind.y_obj[1]

    def update_neighborhood(self, indiv, t):
        for i in range(self.T_size):  # 对正在操作中的向量的每一个领域中的向量进行遍历
            k = self.Neigh[t][i]  # k代表正在操作的向量的领域中的每一个向量（随着迭代分别代表 第1，2。。。niche个向量）
            f1 = scalar_func(TIndividual.n_obj, self.z, indiv.y_obj, self.lambda_[i])
            f2 = scalar_func(TIndividual.n_obj, self.z, self.POP[k].y_obj, self.lambda_[i])
            if f1 < f2:
                self.POP[k] = indiv  # 见MOEA/D的第2.4步

    def initialize(self):
        self.init_weight()
        self.init_Neigh()
        super().initialize()
        for ind in self.POP:
            self.update_ref_point(ind)
            self.update_archive(ind)
        self.update_ideal_distance()
        print("epoch=", 0, " EAP size=", len(self.EAP))

    def get_ratio_vec(self, Sg, L):
        if len(Sg) < L:
            P = []
        else:
            S = [0] * self.P_size
            D = [0] * self.P_size
            P = [0] * self.P_size
            G = len(Sg)
            for i in range(self.P_size):
                for g in range(G - L, G):
                    S[i] += Sg[g][i]
            for i in range(self.P_size):
                D[i] = S[i] / (sum(S) + 1) + 0.02
            for i in range(self.P_size):
                P[i] = D[i] / sum(D)
        return P

    def execute(self):
        t1 = time.perf_counter()
        ASet = []
        for ep in range(self.epochs):
            s = [0] * self.P_size
            Psel = self.get_ratio_vec(self._Sg, 5)
            YSet = []
            for i in range(self.P_size):
                if ep < 5:
                    p = random.randint(0, self.P_size - 1)
                else:
                    p = roulette(Psel)
                p1, p2 = random.sample(self.Neigh[p], 2)
                child, _ = self.PMX_operator(self.POP[p1], self.POP[p2])
                self.mutate(child, self.pm)
                child.decode()
                self.update_ref_point(child)
                self.update_neighborhood(child, p)
                self.update_archive(child)
                YSet.append(child)

            ASet.extend(YSet)
            fronts, ranks = fast_non_dominated_sorting(ASet)
            sort_idx = calculate_crowding_distance(fronts, ranks, ASet)
            ASet = [ASet[i] for i in sort_idx[0:self.P_size]]

            S = [0] * self.P_size
            for i in range(self.P_size):
                for p in self.Neigh[i]:
                    if YSet[p] in ASet:
                        S[i] += 1
            self._Sg.append(S)
            self.update_ideal_distance()
            print("epoch=", ep + 1, " EAP size=", len(self.EAP))

        t2 = time.perf_counter()
        print(f'cost= {t2 - t1:.8f}s')

        # self.find_best_soln()
        # self.plot_frontier(2)
        # self.output()
        # self.plotSoln(self.best_soln)
