import copy
import itertools
import math
from abc import ABC
import random
from collections import defaultdict

import numpy as np
import matplotlib.pyplot as plt
from algorithm.base import Algorithm
from algorithm.individual import TIndividual
from common.topsis import Topsis
from common.utils import find_critical_path


class MOEA(Algorithm, ABC):
    def __init__(self, problem, popsize, epochs):
        self.pc = 1.0
        self.pm = 0.05
        self.best_soln = None
        self.problem = problem

        self.epochs = epochs
        self.P_size = popsize
        self.epoch = 0
        self.EAP = []
        self.POP = []
        self.ideal_distance = []

        self.frontier = []

    def initialize(self):

        self.epoch = 0
        self.EAP = []
        self.ideal_distance = []
        self.POP = []

        # mst 规则
        mst_list = []
        lpt_list = []
        edd_list = []
        for job in self.problem.jobs.values():
            tpt = sum([op.duration for op in job.operations.values()])
            mst_list.append([job.id, job.duedate - tpt])
            lpt_list.append([job.id, tpt])
            edd_list.append([job.id, job.duedate])
        mst_list.sort(key=lambda x: x[1])
        lpt_list.sort(key=lambda x: x[1], reverse=True)
        edd_list.sort(key=lambda x: x[1])

        indv1 = TIndividual(self.problem, [_[0] for _ in mst_list])
        indv1.decode()
        self.POP.append(indv1)
        indv2 = TIndividual(self.problem, [_[0] for _ in lpt_list])
        indv2.decode()
        self.POP.append(indv2)
        indv3 = TIndividual(self.problem, [_[0] for _ in edd_list])
        indv3.decode()
        self.POP.append(indv3)

        seed = int(random.randint(0, 10))
        random.seed(seed)
        while len(self.POP) < self.P_size:
            p = random.choice(range(3))
            tmp_list = [x for x in self.POP[p].x_var]
            random.shuffle(tmp_list)
            indv = TIndividual(self.problem, [j for j in tmp_list])
            indv.decode()
            self.POP.append(indv)

    def swap_operator(self, indv, nb_size=5):
        tardy_list = []
        early_list = []

        for op in self.problem.operations.values():
            if op.next_oper is None:
                end_time = indv.tminfo_of_op[op.id][3]
                if end_time > op.job.duedate:
                    tardy_list.append(op.id[1])
                else:
                    early_list.append(op.id[1])

        pairs = []
        if len(tardy_list) > 0 and len(early_list) > 0:
            while len(pairs) < nb_size:
                j1 = random.choice(early_list)
                j2 = random.choice(tardy_list)
                pairs.append((j1, j2))
        else:
            r1, r2 = random.sample(early_list + tardy_list, 2)
            pairs.append((r1, r2))

        child_list = []
        for j1, j2 in pairs:
            new_x_var = [x for x in indv.x_var]
            r1 = new_x_var.index(j1)
            r2 = new_x_var.index(j2)
            new_x_var[r1], new_x_var[r2] = new_x_var[r2], new_x_var[r1]
            child = TIndividual(self.problem, new_x_var)
            child_list.append(child)

        return child_list



    def insert_operator(self, indv, nb_size=5):
        slack_list = []
        for op in self.problem.operations.values():
            if op.next_oper is None:
                end_time = indv.tminfo_of_op[op.id][3]
                slack_list.append((op.id[1], end_time - op.job.duedate))

        slack_list.sort(key=lambda x: x[1])
        pairs = []
        while len(pairs) < nb_size:
            j1 = slack_list.pop(0)[0]
            i1 = indv.x_var.index(j1)
            if i1 < nb_size - len(pairs):
                for j2 in indv.x_var[0: i1]:
                    pairs.append((j1, j2))
            else:
                js = random.sample(indv.x_var[0:i1], nb_size-len(pairs))
                for j2 in js:
                    pairs.append((j1, j2))

        child_list = []
        for j1, j2 in pairs:
            new_x_var = [x for x in indv.x_var]
            new_x_var.remove(j1)
            r2 = new_x_var.index(j2)
            new_x_var.insert(r2, j1)
            child = TIndividual(self.problem, new_x_var)
            child_list.append(child)

        return child_list


    def swap_in_CP(self, indv, nb_size=5):
        tardy_list = []
        for op in self.problem.operations.values():
            if op.next_oper is None:
                end_time = indv.tminfo_of_op[op.id][3]
                tardy_list.append((op.id, end_time - op.job.duedate))

        tardy_list.sort(key=lambda x: x[1], reverse=True)
        pairs = []
        for op, Td in tardy_list:
            path = find_critical_path(indv, op)
            blocks = defaultdict(list)
            for item in path:
                blocks[item[0]].append(item)
            for stage, block in blocks.items():
                if len(block) >= 2:
                   if (block[0][1], block[1][1]) not in pairs:
                       pairs.append((block[0][1], block[1][1]))
                   if (block[-2][1], block[-1][1]) not in pairs:
                       pairs.append((block[-2][1], block[-1][1]))

            if len(pairs) >= nb_size:
                break

        while len(pairs) < nb_size:
            j1, j2 = random.sample(range(1, len(indv.x_var) + 1), 2)
            pairs.append((j1, j2))

        child_list = []
        for j1, j2 in pairs[0:nb_size]:
            new_x_var = [x for x in indv.x_var]
            r1 = new_x_var.index(j1)
            r2 = new_x_var.index(j2)
            new_x_var[r1], new_x_var[r2] = new_x_var[r2], new_x_var[r1]
            child = TIndividual(self.problem, new_x_var)
            child_list.append(child)

        return child_list

    def plot_frontier(self, show_fig=True, obj_num=2):
        self.frontier = []

        if obj_num != 2:
            return
        plt.rcParams['font.sans-serif'] = ['SimHei']  # show chinese
        plt.rcParams['axes.unicode_minus'] = False  # Show minus sign
        x = []
        y = []
        for sol in self.EAP:
            x.append(sol.y_obj[0])
            y.append(sol.y_obj[1])
            self.frontier.append([sol.y_obj[0], sol.y_obj[1]])

        plt.scatter(x, y)
        plt.xlabel('obj-1')
        plt.ylabel('obj-2')
        plt.show()

    def plotObj(self, obj_list):
        plt.rcParams['font.sans-serif'] = ['SimHei']  # show chinese
        plt.rcParams['axes.unicode_minus'] = False  # Show minus sign
        plt.plot(np.arange(1, len(obj_list) + 1), obj_list)
        plt.xlabel('Iterations')
        plt.ylabel('Obj Value')
        plt.grid()
        plt.xlim(1, len(obj_list) + 1)
        plt.show()

    def update_archive(self, input):  # 更新外部归档种群
        p = 0
        dele_idx = []  # 需要被删除的索引集合
        for i, indv in enumerate(self.EAP):  # 支配前沿集合
            if input < indv:  # 如果北输入个体支配
                dele_idx.append(i)  # 列入被删除的集合
            if indv < input:  # 它有被别人支配！！记下来能支配它的个数
                p += 1
        new_EAP = [self.EAP[i] for i in range(len(self.EAP)) if i not in dele_idx]  # 不需要被删除，那就保存

        self.EAP = new_EAP
        for sol in self.EAP:
            if sol.x_var == input.x_var:
                p = p + 1
        if p == 0:  # 如果p==0，意味着没人支配id_Y, 没人支配id_Y？太好了，加进支配前沿呗
            self.EAP.append(input)
            return True
        return False


    def PMX_operator(self, ind1, ind2):
        old_seq1 = ind1.x_var
        old_seq2 = ind2.x_var
        # 2.交换片段
        left = int(random.randint(0, int(len(self.problem.jobs) * 0.8)))
        right = int(random.randint(left + 1, len(self.problem.jobs)))
        new_seq1 = copy.deepcopy(old_seq1)
        new_seq2 = copy.deepcopy(old_seq2)

        new_seq1[left:right] = old_seq2[left:right]
        new_seq2[left:right] = old_seq1[left:right]

        # 3.消除重复基因
        map1 = dict(zip(new_seq1[left:right], new_seq2[left:right]))
        map2 = dict(zip(new_seq2[left:right], new_seq1[left:right]))

        for i in range(0, left):
            s1 = new_seq1[i]
            if s1 not in map1.keys():
                continue
            while s1 in map1.keys():
                d1 = map1[s1]
                s1 = d1
            new_seq1[i] = d1
        for i in range(0, left):
            s2 = new_seq2[i]
            if s2 not in map2.keys():
                continue
            while s2 in map2.keys():
                d2 = map2[s2]
                s2 = d2
            new_seq2[i] = d2

        for i in range(right, len(self.problem.jobs)):
            s1 = new_seq1[i]
            if s1 not in map1.keys():
                continue
            while s1 in map1.keys():
                d1 = map1[s1]
                s1 = d1
            new_seq1[i] = d1
        for i in range(right, len(self.problem.jobs)):
            s2 = new_seq2[i]
            if s2 not in map2.keys():
                continue
            while s2 in map2.keys():
                d2 = map2[s2]
                s2 = d2
            new_seq2[i] = d2

        child1 = TIndividual(self.problem, new_seq1)
        child2 = TIndividual(self.problem, new_seq2)

        return child1, child2

    def mutate(self, ind, rate, size=3):
        if random.random() > rate:
            return
        # size = int(len(ind.x_var) * 0.1)
        block = []
        # 1. 随机选择两个连续元素的起始索引
        i = random.randint(0, len(ind.x_var) - size)
        for _ in range(size):
            block.append(ind.x_var.pop(i))
        # 2. 随机生成不同的插入位置
        for j in block:
            ix = random.randint(0, len(ind.x_var))
            ind.x_var.insert(ix, j)

    def update_ideal_distance(self):
        ideal_point = (0, 0)
        dist = 0
        min_dist = math.inf
        for sol in self.EAP:
            x = math.sqrt((sol.y_obj[0] - ideal_point[0]) ** 2 + (sol.y_obj[1] - ideal_point[1]) ** 2)
            if min_dist > x:
                min_dist = x
        self.ideal_distance.append(min_dist)

    def find_best_soln(self):
        results = []
        for sol in self.EAP:
            results.append(list(sol.y_obj))

        evaluation_matrix = np.array(results)

        weights = [1.0] * len(results[0])

        '''
        if higher value is preferred - True
        if lower value is preferred - False
        '''
        criterias = np.array([False] * len(results[0]))

        t = Topsis(evaluation_matrix, weights, criterias)

        t.calc()

        # print("best_distance\t", t.best_distance)
        # print("worst_distance\t", t.worst_distance)

        # print("weighted_normalized",t.weighted_normalized)

        # print("worst_similarity\t", t.worst_similarity)
        # print("rank_to_worst_similarity\t", t.rank_to_worst_similarity())

        # print("best_similarity\t", t.best_similarity)
        # print("rank_to_best_similarity\t", t.rank_to_best_similarity())

        seq = t.rank_to_best_similarity()
        self.best_soln = self.EAP[seq[0] - 1]

    def output(self):
        self.plot_frontier(2)
        self.find_best_soln()
        if self.best_soln is None:
            return
        self.best_soln.decode()
        self.problem.show_in_gantt()
