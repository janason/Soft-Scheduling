from abc import ABC, abstractmethod

from hybrid_flow_shop.problem import Problem


class Algorithm(ABC):

    def __init__(self, problem: Problem):
        self.__problem = problem

    @abstractmethod
    def initialize(self):
        pass

    @abstractmethod
    def execute(self):
        pass

    @abstractmethod
    def output(self):
        pass

    @abstractmethod
    def name(self):
        pass
