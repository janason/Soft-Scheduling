import copy
import math
import time

from abc import ABC
import random
from collections import defaultdict
import numpy as np
from hybrid_flow_shop.problem import Problem
from algorithm.MOEA import MOEA
from algorithm.individual import TIndividual
from common.utils import calculate_convergence, fast_non_dominated_sorting, \
    calculate_crowding_distance, calculate_diversity, find_critical_path

class KAB:
    # type 0= uniform , 1=epsilon-greedy, 2 = UCBx, 3= Thompson sampling
    def __init__(self, K, type=0):
        self.type = type
        self.n_arms = K
        self.sel_arms = []  # 记录选择的臂
        self.rwds_arm = [[] for _ in range(K)]  # 记录获得的奖励
        self.avg_rwd_arm = [0] * K  # 记录获得的奖励
        self.sel_cnt_arm = [0] * K
        self.alpha = [1] * K  # 每个臂的alpha参数
        self.beta = [1] * K  # 每个臂的beta参数
        self.gamma = 1.0

    def select_arm(self):
        if self.type == 0:
            return len(self.sel_arms) % self.n_arms
        if self.type == 1:
            return self.greedy()
        if self.type == 2:
            return self.UCB1x()
        if self.type == 3:
            return self.Thompson()

    def greedy(self):
        if random.random() < 0.1:
            return random.choice(range(4))
        else:
            return int(np.argmax(self.avg_rwd_arm))

    def Thompson(self):

        theta = [random.betavariate(self.alpha[k], self.alpha[k]) for k in range(self.n_arms)]
        sel_arm = np.argmax(theta)  # 选择最大的采样值对应的臂

        return int(sel_arm)

    def UCB1x(self):
        ep = len(self.sel_arms)
        if ep < self.n_arms * 5:
            sel_arm = ep % self.n_arms
        else:
            UCB_val = [0] * self.n_arms
            for k in range(self.n_arms):
                # UCB_val[k] = self.avg_rwd_arm[k] + math.sqrt(2 * math.log(ep + 1) / self.sel_cnt_arm[k]) \
                #              * min(1, np.var(self.rwds_arm[k]) / (self.avg_rwd_arm[k] * self.avg_rwd_arm[k]))
                UCB_val[k] = self.avg_rwd_arm[k] + self.gamma * math.sqrt(math.log(ep + 1) / self.sel_cnt_arm[k])
            sel_arm = int(np.argmax(UCB_val))
        return sel_arm

    def update_reward(self, k, rwd):
        self.sel_arms.append(k)
        self.rwds_arm[k].append(rwd)
        self.avg_rwd_arm[k] = (self.avg_rwd_arm[k] * self.sel_cnt_arm[k] + rwd) / (self.sel_cnt_arm[k] + 1)  # 记录获得的奖励
        self.sel_cnt_arm[k] += 1
        if rwd == 1:
            self.alpha[k] += 1
        else:
            self.beta[k] += 1

class LeMOEAk(MOEA, ABC):
    def __init__(self, problem: Problem, popsize, epochs):
        super().__init__(problem, popsize, epochs)
        self.learn_type = 2  # UCB
        self.pc = 1.0
        self.pm = 0.05
        self.nb_size = 4
        self.nv_size = 2
        self.gamma = 0.5

    def name(self):
        return 'LeMOEAk'

    def initialize(self):
        super().initialize()
        for ind in self.POP:
            self.update_archive(ind)
        self.update_ideal_distance()
        print("epoch=", 0, " EAP size=", len(self.EAP))

    def guided_PMX(self, ind1:TIndividual, ind2:TIndividual, is_tardy):
        # 1.交换片段
        left = int(random.randint(0, int(len(self.problem.jobs) * 0.8)))
        right = int(random.randint(left + 1, len(self.problem.jobs)))
        f1 = 0
        f2 = 0
        for i in range(left,right):
            if is_tardy:
                f1 += ind1.tardiness[ind1.x_var[i]]
                f2 += ind2.tardiness[ind2.x_var[i]]
            else:
                f1 += ind1.blocktime[ind1.x_var[i]]
                f2 += ind2.blocktime[ind2.x_var[i]]
        if f1<=f2: # 保留1
            x_seq = [j for j in ind1.x_var]
            y_seq = [j for j in ind2.x_var]
        else: # 保留2
            x_seq = [j for j in ind2.x_var]
            y_seq = [j for j in ind1.x_var]
        # 2. 将交叉区间直接从x复制到子代
        new_seq = [x_seq[i] if left <= i < right else 0 for i in range(len(x_seq))]
        # 3. 构建映射关系（y -> x）交叉片段
        mapping = dict(zip(x_seq[left:right], y_seq[left:right]))
        # 4. 填充剩余位置
        for i in list(range(0, left)) + list(range(right, len(x_seq))):
            s = y_seq[i]
            if s in mapping.keys():
                d = s
                while d in mapping.keys():
                    s = mapping[d]
                    d = s
            new_seq[i] = s
        child = TIndividual(self.problem, new_seq)
        return child


    def swap_in_CP(self, indv, is_tardy=True, nb_size=5):
        job_dict = {job: 0 for job in self.problem.jobs.values()}
        if is_tardy:
            for op in self.problem.operations.values():
                if op.next_oper is None:
                    end_time = indv.tminfo_of_op[op.id][3]
                    job_dict[op.job] = end_time - op.job.duedate
        else:
            for op in self.problem.operations.values():
                job_dict[op.job] += op.leave_time - op.end_time

        sorted_jobs = sorted(job_dict, key=lambda k: job_dict[k], reverse=True)
        # sorted_jobs.sort(key=lambda x: x[1], reverse=True)
        pairs = []
        for job in sorted_jobs:
            path = find_critical_path(indv, job.get_tail_op().id)
            blocks = defaultdict(list)
            for item in path:
                blocks[item[0]].append(item)
            for stage, block in blocks.items():
                if len(block) >= 2:
                   if (block[0][1], block[1][1]) not in pairs:
                       pairs.append((block[0][1], block[1][1]))
                   if (block[-2][1], block[-1][1]) not in pairs:
                       pairs.append((block[-2][1], block[-1][1]))

            if len(pairs) >= nb_size:
                break

        while len(pairs) < nb_size:
            j1, j2 = random.sample(range(1, len(indv.x_var) + 1), 2)
            pairs.append((j1, j2))

        child_list = []
        for j1, j2 in pairs[0:nb_size]:
            new_x_var = [x for x in indv.x_var]
            r1 = new_x_var.index(j1)
            r2 = new_x_var.index(j2)
            new_x_var[r1], new_x_var[r2] = new_x_var[r2], new_x_var[r1]
            child = TIndividual(self.problem, new_x_var)
            child_list.append(child)

        return child_list

    def reproduction(self, indv, explorer, nb_size):
        children = []
        if explorer == 0:
            lst = random.sample([p for p in self.POP if p is not indv], nb_size)
            lst.sort(key=lambda item: item.y_obj[0])
            children = [self.guided_PMX(indv, lst[0], is_tardy=True) for _ in range(nb_size)]
        if explorer == 1:
            lst = random.sample([p for p in self.POP if p is not indv], nb_size)
            lst.sort(key=lambda item: item.y_obj[1])
            children = [self.guided_PMX(indv, lst[0], is_tardy=False) for _ in range(nb_size)]
        elif explorer == 2:
            children = self.swap_in_CP(indv, is_tardy=True, nb_size=nb_size)
        elif explorer == 3:
            children = self.swap_in_CP(indv, is_tardy=False, nb_size=nb_size)
        return children


    def check_visited(self, target, arm):
        if arm not in target.explor_list: # 可以修改判断标准，比如限制访问次数
            target.explor_list.append(arm)
            is_visited = False
        else:
            is_visited = True
        return is_visited

    def execute(self):
        t1 = time.perf_counter()
        kab = KAB(K=4, type=self.learn_type)
        kab.gamma = self.gamma
        old_cv = calculate_convergence(self.POP, self.EAP)
        old_dv = calculate_diversity(self.POP)
        for ep in range(self.epochs):
            offspring = []
            sel_arm = kab.select_arm()
            self.epoch = ep
            p = 0
            while len(offspring) < self.P_size:
                target = random.choice(self.POP) # 这个选择机制可以修改，可以按照不同目标的排序进行选择
                if self.check_visited(target, sel_arm): # 这个地方也可以修改判断标准
                    child = TIndividual(problem=self.problem, x_list=[x for x in target.x_var])
                    self.mutate(ind=child, rate=1.0, size=self.nv_size)
                    offspring.append(child)
                else:
                    offspring += self.reproduction(target, sel_arm, self.nb_size)
                p = p+1
            for indv in offspring:
                indv.decode()
                self.update_archive(indv)

            self.POP.extend(offspring)
            fronts, ranks = fast_non_dominated_sorting(self.POP)
            sort_idx = calculate_crowding_distance(fronts, ranks, self.POP)
            self.POP = [self.POP[i] for i in sort_idx[0:self.P_size]]
            self.update_ideal_distance()

            new_cv = calculate_convergence(self.POP, self.EAP)
            new_dv = calculate_diversity(self.POP)
            if new_cv - old_cv <old_cv and new_dv - old_dv > old_dv:
                rwd = 3
            elif new_cv - old_cv <old_cv or new_dv - old_dv > old_dv:
                rwd = 1
            else:
                rwd = 0
            old_cv = new_cv
            old_dv = new_dv
            kab.update_reward(sel_arm, rwd)
            print("epoch=", ep + 1, " EAP size=", len(self.EAP))
        t2 = time.perf_counter()
        print(f'cost= {t2 - t1:.8f}s')
        print(kab.sel_arms)
        print(kab.sel_cnt_arm)

