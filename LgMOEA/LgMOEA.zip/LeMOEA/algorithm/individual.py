#!/usr/bin/python
# # -*- coding:utf-8 -*-
import bisect
import heapq
import random
import sys
import time

from matplotlib import pyplot as plt

from hybrid_flow_shop.entities import OpStatus, Buffer
from hybrid_flow_shop.problem import Problem


def find_earliest_available_machine(stage, mEAT_dict):
    ma_sel = None
    ma_eat = 1.0e10
    for ma in stage.machines.values():
        if mEAT_dict[ma] < ma_eat:
            ma_sel = ma
            ma_eat = mEAT_dict[ma]
    return ma_sel, ma_eat


class TIndividual:  # 定义个体类
    n_obj = 2

    # 构造函数
    def __init__(self, problem: Problem, x_list):
        self.problem = problem
        self.prevs_of_op = {}
        self.tminfo_of_op = {}

        self.x_var = x_list
        self.y_obj = [0, 0]
        self.rank = 0
        self.explored = False
        self.explor_list = []
        self.tardiness = {}
        self.blocktime = {}

    def forward_scheduling(self):
        self.problem.reset()
        mEAT_dict = {ma: 0 for ma in self.problem.machines.values()}  # earliest available time for each machine
        # self.x_var = [i + 1 for i in range(len(self.problem.jobs))]
        # 2. sorted operations
        op_list = [self.problem.jobs[x].get_head_op() for x in self.x_var]
        job_idx = [self.x_var.index(j + 1) for j in range(len(self.problem.jobs))]
        evt_list = [(op, 0, 0, job_idx[op.job.id - 1]) for op in op_list]  # event list: op, time, type
        while len(evt_list) > 0:
            e_op, e_tm, e_tp, idx = evt_list.pop(0)
            if e_tp == 0:  # from buffer to machine
                xMA, EAT = find_earliest_available_machine(e_op.stage, mEAT_dict)
                if EAT > e_tm:  # continue to wait
                    evt_list.append((e_op, EAT, 0, idx))
                    continue
                buffer = e_op.stage.prev_buffer
                if buffer is not None:
                    opx = buffer.job_out()  # 出缓冲，这个地方可能出错
                    if opx is not e_op:
                        print('buffer_out is error......')
                if e_op.prev_oper is None:
                    e_op.start_time = max(EAT, e_tm)
                else:
                    e_op.start_time = max(EAT, e_tm, e_op.arrival_time + Buffer.MIN_WAITING)
                e_op.machine = xMA
                mEAT_dict[xMA] = e_op.end_time
                evt_list.append((e_op, e_op.end_time, 1, idx))

            if e_tp == 1:  # from machine to buffer
                if e_op.next_oper is not None:
                    buffer = e_op.stage.next_buffer
                    if buffer.job_in(e_op.next_oper):  # can enter into buffer
                        e_op.leave_time = e_tm
                        e_op.status = OpStatus.LEAVED
                        e_op.next_oper.status = OpStatus.WAITING
                        e_op.next_oper.arrival_time = e_tm
                        evt_list.append((e_op.next_oper, e_tm + Buffer.MIN_WAITING, 0, idx))
                    else:
                        evt_list.append((e_op, e_tm + 1, 1, idx))  # waiting on machine
                        mEAT_dict[e_op.machine] += 1
                else:  # the job in the last stage can leave directly
                    e_op.leave_time = e_tm
                    e_op.status = OpStatus.LEAVED
            evt_list.sort(key=lambda x: (x[1], x[3]))

    def fast_forward_scheduling(self):
        self.problem.reset()
        mEAT_dict = {ma: 0 for ma in self.problem.machines.values()}  # earliest available time for each machine
        # self.x_var = [i + 1 for i in range(len(self.problem.jobs))]
        # 2. sorted operations
        op_list = [self.problem.jobs[x].get_head_op() for x in self.x_var]
        priority = [self.x_var.index(j + 1) / len(self.problem.jobs) for j in range(len(self.problem.jobs))]
        evt_list = []
        for _ in range(len(self.problem.stages[1].machines)):
            op = op_list.pop(0)
            heapq.heappush(evt_list, (0 + priority[op.job.id - 1], 0, op))
        while evt_list:
            e_tmp, e_tp, e_op = heapq.heappop(evt_list)
            e_tm = int(e_tmp)
            e_pr = e_tmp - e_tm
            # print(e_op.id, e_tp, evt.time)
            if e_tp == 0:  # from buffer to machine
                xMA, EAT = find_earliest_available_machine(e_op.stage, mEAT_dict)
                if EAT > e_tm:  # continue to wait
                    heapq.heappush(evt_list, (EAT + e_pr, 0, e_op))
                    continue
                buffer = e_op.stage.prev_buffer
                if buffer is not None:
                    opx = buffer.job_out()  # 出缓冲，这个地方可能出错
                    # if opx is not e_op:
                    #     print('buffer_out is error......')
                if e_op.prev_oper is None:
                    e_op.start_time = max(EAT, e_tm)
                else:
                    e_op.start_time = max(EAT, e_tm, e_op.arrival_time + Buffer.MIN_WAITING)
                e_op.machine = xMA
                mEAT_dict[xMA] = e_op.end_time
                heapq.heappush(evt_list, (e_op.end_time + e_pr, 1, e_op))

            if e_tp == 1:  # from machine to buffer
                if e_op.next_oper is not None:
                    buffer = e_op.stage.next_buffer
                    if buffer.job_in(e_op.next_oper):  # can enter into buffer
                        e_op.leave_time = e_tm
                        e_op.status = OpStatus.LEAVED
                        e_op.next_oper.status = OpStatus.WAITING
                        e_op.next_oper.arrival_time = e_tm
                        heapq.heappush(evt_list, (e_tm + Buffer.MIN_WAITING + e_pr, 0, e_op.next_oper))
                        if e_op.prev_oper is None:
                            if len(op_list) > 0:
                                xop = op_list.pop(0)
                                heapq.heappush(evt_list, (e_tm + + priority[xop.job.id - 1], 0, xop))
                    else:
                        heapq.heappush(evt_list, (e_tm + 1 + e_pr, 1, e_op))  # waiting on machine
                        mEAT_dict[e_op.machine] += 1
                        # print('wait.....')
                else:  # the job in the last stage can leave directly
                    e_op.leave_time = e_tm
                    e_op.status = OpStatus.LEAVED
            # evt_list.sort(key=lambda x: (x[1], x[3]))

    def reverse_compression(self):
        stage_list = list(self.problem.stages.values())
        for stage in reversed(stage_list):
            oper_list = list(stage.operations.values())
            oper_list.sort(key=lambda p: p.leave_time, reverse=True)
            buff_load = [0] * oper_list[0].leave_time
            while len(oper_list) > 0:  # only reset leave time
                op = oper_list.pop(0)
                if op is op.machine.operations[-1]:  # 不动，只需要更新上游负载
                    for t in range(op.arrival_time, op.start_time):
                        buff_load[t] += 1
                    continue
                # 先看前方的
                idx_of_ma = op.machine.operations.index(op)
                xop_of_ma = op.machine.operations[idx_of_ma + 1]
                xLST_m = xop_of_ma.start_time - op.duration
                if op.next_oper is None:  # 工序后继
                    xLST_g = max(op.start_time, op.job.duedate - op.duration)
                else:
                    xLST_g = op.leave_time - op.duration  # arrival time ?
                xLST = min(xLST_g, xLST_m)

                # 然后看上游工序，确定arrival time
                if op.prev_oper is not None:
                    xLAT = xLST - Buffer.MIN_WAITING
                    flag = False
                    while not flag:
                        flag = True
                        for t in range(xLAT, xLST):
                            if buff_load[t] + 1 > stage.prev_buffer.capacity:
                                flag = False
                                break
                        xLST = t
                        xLAT = xLST - Buffer.MIN_WAITING
                else:
                    xLAT = -1
                # 更新数据
                op.start_time = xLST
                op.arrival_time = xLAT
                op.leave_time = min(xLST_m + op.duration, xLST_g + op.duration)
                if op.next_oper is not None:
                    op.leave_time = op.end_time
                else:
                    op.prev_oper.leave_time = op.arrival_time

                for t in range(op.arrival_time, op.start_time):
                    buff_load[t] += 1
        # for op in self.problem.operations.values():
        #     print(op, op.arrival_time, op.start_time, op.end_time, op.leave_time)
        # print('-----------------')

    def decode(self):
        #t0 = time.perf_counter()  # 返回高精度时间（秒）
        # self.forward_scheduling()
        # print('forward:', self.calc_obj_vals())
        # self.problem.show_in_gantt()
        self.fast_forward_scheduling()
        # print('forward:', self.calc_obj_vals())
        # self.problem.show_in_gantt()
        # t1 = time.perf_counter()  # 返回高精度时间（秒）
        self.reverse_compression()
        # print('backward:', self.calc_obj_vals())
        # t2 = time.perf_counter()  # 返回高精度时间（秒）
        # print(f'{(t1 - t0) * 1000:.2f}ms --- {(t2 - t1) * 1000:.2f}ms')
        # # self.problem.show_in_gantt()
        self.calc_obj_vals()

    # 计算目标函数
    def decodex(self):
        # 1. prepare data
        stage_list = list(self.problem.stages.values())
        for ma in self.problem.machines.values():
            ma.operations.clear()
        for op in self.problem.operations.values():
            op.machine = None
        # 2. scheduling
        job_list = [self.problem.jobs[x] for x in self.x_var]
        op_EAT_dict = {}
        for op in self.problem.operations.values():
            op_EAT_dict[op] = 0
        for ids, stage in enumerate(stage_list):
            ma_LAT_dict = {ma: 0 for ma in stage.machines.values()}
            if ids == 0:
                op_list = [(job.get_head_op(), 0) for job in job_list]
            else:
                op_list = [(op, op_EAT_dict[op]) for op in stage.operations.values()]
                op_list.sort(key=lambda x: x[1])
            for op, EAT in op_list:
                ma = min(ma_LAT_dict, key=ma_LAT_dict.get)
                op.start_time = max(ma_LAT_dict[ma], EAT)
                op.machine = ma
                ma_LAT_dict[ma] = op.end_time
                ma.operations.append(op)
                if op.next_oper is not None:
                    op_EAT_dict[op.next_oper] = op.end_time + op.time_to_next
        # self.y_obj = self.calc_obj_vals()

    def calc_obj_vals(self):
        TWT, NPE = 0, 0
        self.tardiness = {j:0 for j in self.problem.jobs.keys()}
        self.blocktime = {j:0 for j in self.problem.jobs.keys()}
        for op in self.problem.operations.values():
            self.tminfo_of_op[op.id] = [op.machine.id, op.arrival_time, op.start_time, op.end_time, op.leave_time]
            self.prevs_of_op[op.id] = [(0, 0), (0, 0)]
            if op.prev_oper is not None:
                self.prevs_of_op[op.id][0] = op.prev_oper.id
            if op.next_oper is None:
                w = max(op.start_time + op.duration - op.job.duedate, 0)
                TWT += w
                self.tardiness[op.job.id] = w
        # print(self.tardiness)
        NPE = 0
        for ma in self.problem.machines.values():
            for i in range(len(ma.operations)):
                uop = ma.operations[i]
                block = uop.leave_time - uop.end_time
                if i > 0:
                    vop = ma.operations[i - 1]
                    self.prevs_of_op[uop.id][1] = vop.id
                NPE += block
                self.blocktime[uop.job.id] += block

        self.y_obj = [TWT, NPE]
        return [TWT, NPE]

    # 对"<"号重载，重新赋予意义，使"<"能在个体之间比较, 表示支配关系
    def __lt__(self, ind2):
        dominated = True
        for n in range(0, self.n_obj):
            if ind2.y_obj[n] < self.y_obj[n]:
                return False
        if ind2.y_obj == self.y_obj:
            return False
        return dominated

    # 实现"=="运算符重载，实现每个个体的目标函数值的比较
    def __eq__(self, ind2):
        if ind2.y_obj == self.y_obj:
            return True
        else:
            return False

    # 实现对象的赋值操作，相当于重载"="操作符的实现
    def assignment(self, ind2):
        self.x_var = ind2.x_var
        self.y_obj = ind2.y_obj
        self.rank = ind2.rank

    #  显示目标变量的值
    def show_objective(self):
        print(self.y_obj)

    # 显示个体的值
    def show_variable(self):

        print(self.x_var)


class TSOP:  # 定义一个子问题的类
    def show(self):
        pass

    # strTestInstance = ""
    # numVariables = 30
    # numObjectives = 2
    # 定义函上下界
    # lowBound = 0
    # uppBound = 1

    def __init__(self, strTestInstance, numVariables=30, numObjectives=2, lowBound=0, uppBound=1):
        self.strTestInstance = strTestInstance
        self.numVariables = numVariables
        self.numObjectives = numObjectives
        # 传入测试函数定义域的上下界信息
        self.lowBound = lowBound
        self.uppBound = uppBound

        self.indiv = TIndividual(strTestInstance, numVariables, numObjectives, lowBound, uppBound)
        self.namda = []
        # 定义子问题的领域表
        self.table = []
        # 距离最近的领域数量的向量索引值
        self.array = []

    #  相当于"="的运算符重载，实现子问题的直接赋值的操作
    def assignment(self, sub2):
        self.indiv = sub2.namda
        self.table = sub2.namda
        self.namda = sub2.namda
        self.array = sub2.array
