import math
import random
import sqlite3

import numpy as np


def generate_flowsheet(stage_nums=[2, 3, 4], mach_per_stage=[3, 4], total=5):
    dname = f".//instances.db"
    conn = sqlite3.connect(dname)
    # pt_per_stage = [10, 20, 30]
    cursor = conn.cursor()
    # 清空数据
    cursor.execute(f"DELETE FROM mbd_flow_info;")
    cursor.execute(f"DELETE FROM mbd_stage_info;")
    cursor.execute(f"DELETE FROM mbd_machine_info;")
    conn.commit()
    # 插入数据
    for i in range(total):
        stage_num = random.choice(stage_nums)
        cursor.execute(f'INSERT INTO mbd_flow_info (flow_id, stage_num) VALUES ({i + 1},{stage_num})')
        for g in range(stage_num):
            mach_num = random.choice(mach_per_stage)
            pt_stage = random.randint(2, 4)*10
            delta = 10
            cursor.execute(f'insert into mbd_stage_info (stage_id, stage_name, pm_count, pt_min, pt_max, flow_id) '
                           f'values '
                           f"({g + 1},'G-{g + 1}' , {mach_num},{pt_stage - delta}, {pt_stage + delta}, {i + 1})")
            for k in range(mach_num):
                cursor.execute(f'insert into mbd_machine_info (machine_id, machine_name, stage_id, flow_id) VALUES'
                               f"('{g + 1}{k + 1}','M-{g + 1}{k + 1}', {g + 1},{i + 1})")

    conn.commit()
    conn.close()


def generate_instances(job_nums):
    dname = f".//instances.db"
    conn = sqlite3.connect(dname)
    cursor = conn.cursor()
    # 清空数据
    cursor.execute(f"DELETE FROM sch_instance_info;")
    cursor.execute(f"DELETE FROM sch_job_info;")
    cursor.execute(f"DELETE FROM sch_operation_info;")
    conn.commit()

    stage_dict = {}
    ds = cursor.execute(f"select flow_id, stage_id,  pt_min, pt_max from mbd_stage_info")
    for row in ds:
        key = f'{row[0]},{row[1]}'
        if key not in stage_dict.keys():
            stage_dict[key] = []
        stage_dict[key] = [row[2], row[3]]
    mach_dict = {}
    ds = cursor.execute(f"select flow_id, stage_id, machine_id from mbd_machine_info")
    for row in ds:
        key = f'{row[0]},{row[1]}'
        if key not in mach_dict.keys():
            mach_dict[key] = []
        mach_dict[key].append(row[2])

    flow_list = []
    ds = cursor.execute(f"select flow_id, stage_num from mbd_flow_info")
    for row in ds:
        flow_list.append((row[0], row[1]))

    # 插入数据
    for row in flow_list:
        flow_id = str(row[0])
        stage_num = int(row[1])
        # 插入数据
        for i in range(len(job_nums)):
            job_num = job_nums[i]
            pt_np = np.zeros((stage_num, job_num))
            inst_id = f'{flow_id}#{i + 1}'
            cursor.execute(f'insert into sch_instance_info (instance_id, job_num, flow_id) VALUES '
                           f"('{inst_id}',{job_num}, {flow_id})")
            for j in range(job_num):
                job_id = f'J_{j + 1:03}'
                print(job_id, inst_id)
                cursor.execute(f'insert into sch_job_info (job_id, instance_id, due_time, release_time) VALUES '
                               f"('{job_id}','{inst_id}', 0,0)")

                for g in range(1, stage_num + 1):
                    param = stage_dict[f'{flow_id},{g}']
                    pt_min = int(param[0])
                    pt_max = int(param[1])
                    oper_id = f'O_{g}_{j + 1:03}'
                    oper_prev_stage = f'O_{g - 1}_{j + 1:03}'
                    oper_next_stage = f'O_{g + 1}_{j + 1:03}'
                    if g == 1:
                        oper_prev_stage = ''
                    if g == stage_num:
                        oper_next_stage = ''
                    ma_pt_list = ''
                    ma_list = mach_dict[f'{flow_id},{g}']
                    pt = random.randint(pt_min, pt_max)
                    pt_np[g - 1, j - 1] = pt
                    for ma in ma_list:
                        ma_pt_list += f'{ma}:{pt},{pt_min},{pt_max}|'
                    ma_pt_list = ma_pt_list[:-1]
                    # print(ma_pt_list)
                    cursor.execute(f'insert into sch_operation_info (operation_id, instance_id, job_id, stage_id, '
                                   f'oper_prev_stage, oper_next_stage, tt_next_stage, ma_pt_list) values'
                                   f"('{oper_id}','{inst_id}','{job_id}','{g}', '{oper_prev_stage}', '{oper_next_stage}', "
                                   f" 0, '{ma_pt_list}')")
            pt_sum = np.sum(pt_np, axis=1)
            pt_avg = [pt_sum[i] / len(mach_dict[f'{flow_id},{i + 1}']) for i in range(stage_num)]
            max_pt_avg = np.max(pt_avg)
            btn_stage = np.argmax(pt_avg)
            r_list = np.array([0] * job_num)
            q_list = np.array([0] * job_num)
            for j in range(job_num):
                for i in range(0, btn_stage):
                    r_list[j] += pt_np[i, j]
                for i in range(btn_stage + 1, stage_num):
                    q_list[j] += pt_np[i, j]
            r_min = np.min(r_list)
            q_min = np.min(q_list)
            LB = max_pt_avg + r_min + q_min
            eta_t = 0.4
            eta_d = 0.6
            for j in range(job_num):
                job_id = f'J_{j + 1:03}'
                dd = int(np.random.uniform(math.floor(LB * (1-(eta_t+eta_d)/2)), math.floor(LB * (1-(eta_t-eta_d)/2))))
                cursor.execute(
                    f"update sch_job_info set due_time={dd} where job_id='{job_id}' and instance_id='{inst_id}'")

    conn.commit()
    conn.close()


generate_flowsheet([3, 4], [2, 3, 4], 5)
generate_instances([20, 60, 80, 100, 120])
