import itertools
import pandas as pd
import seaborn as sns
import statsmodels.api as sm
from statsmodels.formula.api import ols
import numpy as np
import matplotlib.pyplot as plt
from statsmodels.sandbox.stats.multicomp import MultiComparison

from common.indicators import hv_indicator, sp_indicator, get_pareto_front, sr_indicator

algo_list = [ 'LeMOEAk','NSGA2', 'NSGA2LS',  'MOEAd', 'EagMOEAd',  'MOPSO']


def ANOVA(df, key, x_tick=[]):
    # mpl.rcParams['font.sans-serif'] = ['SimHei']
    sns.set_theme(font_scale=0.8)
    plt.figure(figsize=(4.8, 6.0))
    sns.set(style='ticks')

    df_melt = pd.melt(df.reset_index(), id_vars=['index'])
    df_melt.columns = ['index', 'Algorithms', key]

    model = ols(key + ' ~ C(Algorithms)', data=df_melt).fit()
    anova_table = sm.stats.anova_lm(model, typ=1)
    print(anova_table)

    mc = MultiComparison(df_melt[key], df_melt['Algorithms'])
    tukey_result = mc.tukeyhsd(alpha=0.05)
    print(tukey_result)

    sns.boxplot(x='Algorithms', y=key, data=df_melt, width=0.40,
                fliersize=2, linewidth=1, palette='deep')
    sns.swarmplot(x='Algorithms', y=key, data=df_melt, size=4, palette='deep')
    plt.xticks(range(len(x_tick)), x_tick, fontsize=10)
    plt.tick_params(labelsize=10)
    plt.show()

    # 提取各组之间的p值
    summay = tukey_result.summary().data
    df_sum = pd.DataFrame(summay[1:], columns=summay[0])
    # 获取组的名字
    groups = tukey_result.groupsunique.tolist()
    # 创建一个空的矩阵用于存储p值
    p_matrix = np.ones((len(groups), len(groups)))
    # 将p值填入矩阵
    for _, row in df_sum.iterrows():
        g1 = row['group1']
        g2 = row['group2']
        pvalue = row['p-adj']
        i = groups.index(g1)
        j = groups.index(g2)
        p_matrix[i, j] = pvalue
        p_matrix[j, i] = pvalue

    p_df = pd.DataFrame(p_matrix, index=groups, columns=groups)
    plt.figure(figsize=(8, 6))
    sns.heatmap(p_df, annot=True, cmap='coolwarm', cbar=True, fmt='.3f')
    plt.show()


def cal_mo_metric(algos, df):
    z_max = [df['f1'].max(), df['f2'].max()]
    z_min = [df['f1'].min(), df['f2'].min()]
    Z_obj = df[['f1', 'f2']].drop_duplicates().values.tolist()
    pf_all = get_pareto_front(Z_obj)
    indi_dict = {}
    for a in algos:
        dfx = df[df['algo'] == a]
        z_obj = dfx[['f1', 'f2']].drop_duplicates().values
        _range = np.array(z_max) - np.array(z_min)
        z_norm = (z_obj - z_min) / _range
        hv = hv_indicator(z_obj=z_obj, n_obj=2, max_pt=z_max, min_pt=z_min, ref_pt=[1.0, 1.0])
        sp = sp_indicator(solution=z_norm)
        sr = sr_indicator(z_obj, pf_all)
        indi_dict[a] = [hv, sp, sr]
    return indi_dict


def comparison():
    hv_dict = {a:[] for a in algo_list}
    sp_dict = {a:[] for a in algo_list}
    sr_dict = {a:[] for a in algo_list}
    for fid, iid in itertools.product(range(1, 6), range(1, 6)):
        file_path = '../data/' + f'{fid}#{iid}.txt'
        data = []
        try:
            with open(file_path, 'r') as f:
                lines = f.readlines()
                for r in range(len(lines)):
                    xx = lines[r].split()
                    x = xx[0].split(',')
                    if x[0] in algo_list:
                        data.append([x[0], float(x[1]), float(x[2])])
        except FileNotFoundError:
            print(f"文件 {file_path} 不存在")
            continue

        df = pd.DataFrame(data, columns=['algo', 'f1', 'f2'])
        indi_vals = cal_mo_metric(algo_list, df)
        for a in algo_list:
            hv_dict[a].append(indi_vals[a][0])
            sp_dict[a].append(indi_vals[a][1])
            sr_dict[a].append(indi_vals[a][2])
    df_hv = pd.DataFrame(hv_dict, columns=algo_list)
    df_sp = pd.DataFrame(sp_dict, columns=algo_list)
    df_sr = pd.DataFrame(sr_dict, columns=algo_list)
    print(df_hv)
    print(df_sp)
    print(df_sr)


if __name__ == "__main__":
    # ---------------------------------------------------
    comparison()
    # component()
