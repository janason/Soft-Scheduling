import itertools
import multiprocessing
import random

from algorithm.LeMOEAk import LeMOEAk
from hybrid_flow_shop.problem import Problem

# 可以使用拉丁均方设计

# 生成一个3因素，每个因素5水平的正交设计
levels = 3  # 每个因素的水平数
factors = 4  # 因素数量

factor_level = {'P_size': [0.50, 1.00, 1.50, 2.00],
               'nb_size': [4, 6, 8, 10],
               'nv_size': [2, 3, 4, 5],
               'gamma': [0.5, 1, 1.5, 2]}
orthogonal_table  = [
    [1, 1, 1, 1], [1, 2, 2, 2], [1, 3, 3, 3], [1, 4, 4, 4],
    [2, 1, 2, 3], [2, 2, 1, 4], [2, 3, 4, 1], [2, 4, 3, 2],
    [3, 1, 3, 4], [3, 2, 4, 3], [3, 3, 1, 2], [3, 4, 2, 1],
    [4, 1, 4, 2], [4, 2, 3, 1], [4, 3, 2, 4], [4, 4, 1, 3]]


# 定义子进程要执行的任务
def worker(pid):
    for i in range(pid*4, (pid+1)*4):
        dsg = orthogonal_table [i]
        # 获取每个设计参数
        ins_list = [f'{x}#{y}' for x, y in itertools.product(range(1, 6), range(1, 6))]
        samples = random.sample(ins_list, 5)
        for ins in samples:
            for _ in range(5):
                problem = Problem(ins)
                problem.read_instance()
                problem.reset()
                algo = LeMOEAk(problem, 50, 100)
                maxTFE = len(problem.jobs) * len(problem.stages) * 100
                algo.P_size = int(factor_level['P_size'][dsg[0] - 1] * len(problem.jobs))
                algo.nb_size = int(factor_level['nb_size'][dsg[1] - 1])
                algo.nv_size = int(factor_level['nv_size'][dsg[2] - 1])
                algo.gamma = float(factor_level['gamma'][dsg[3] - 1])
                algo.epochs = int(maxTFE/algo.P_size )

                algo.initialize()
                algo.execute()
                with open(f"./DOE/EX-{i}.txt", "a") as file:
                    for sol in algo.EAP:
                        str = f'{ins},{sol.y_obj[0]:.3f},{sol.y_obj[1]:.3f}\n'
                        file.write(str)



if __name__ == "__main__":
    #1. 常规模式
    # for i in range(16):
    #     worker(i)
    #2. 多进程模式
    processes = []
    for i in range(4):
        p = multiprocessing.Process(target=worker, args=(i,))
        processes.append(p)
        p.start()
    for p in processes:
        p.join()
    print("所有进程执行完毕")


