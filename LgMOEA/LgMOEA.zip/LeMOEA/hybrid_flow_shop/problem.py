import sqlite3
import matplotlib.pyplot as plt
import seaborn as sns
import matplotlib as mpl
import pandas as pd
import networkx as nx
from hybrid_flow_shop.entities import *

class Problem:
    BUF_SIZE = 1

    def __init__(self, name):
        self.name = name
        self.jobs = {}
        self.operations = {}
        self.stages = {}
        self.machines = {}
        self.buffers = {}
        return

    def __repr__(self):
        return f"instance: {self.name}"

    def read_instance(self):
        dname = f".//data//instances.db"
        conn = sqlite3.connect(dname)
        print("Opened database successfully")
        cur = conn.cursor()
        ds = cur.execute(f"select flow_id from sch_instance_info where instance_id = '{self.name}'")
        flow_id = ''
        for row in ds:
            flow_id = str(row[0])

        ds = cur.execute(f"select stage_id from mbd_stage_info where flow_id='{flow_id}' order by rowid asc")
        for row in ds:
            idx = int(row[0])
            stage = Stage(idx)
            self.stages[idx] = stage

        cur = conn.cursor()
        ds = cur.execute(f"select machine_id, stage_id from mbd_machine_info where flow_id='{flow_id}' order by rowid "
                         "asc")
        for row in ds:
            idx = int(int(row[0]) / 10), int(row[0]) % 10
            idy = int(row[1])
            machine = Machine(idx, self.stages[idy])
            self.machines[idx] = machine

        ds = cur.execute(
            "select job_id, due_time, release_time from sch_job_info where instance_id = '"
            + self.name + "' order by rowid asc")

        for row in ds:
            idx = int(row[0].split('_')[1])
            job = Job(idx)
            job.duedate = int(row[1])
            self.jobs[idx] = job

        ds = cur.execute(
            "select operation_id, stage_id, job_id, ma_pt_list  from sch_operation_info where instance_id = '"
            + self.name + "' order by operation_id")
        for row in ds:
            print(row)
            idx = int(row[0].split('_')[1]), int(row[0].split('_')[2])
            stage = self.stages[int(row[1])]
            job = self.jobs[int(row[2].split('_')[1])]
            pt = 0
            ma_pt_list = row[3].split('|')
            for ma_pt in ma_pt_list:
                item = ma_pt.split(':')
                pt += int(item[1].split(',')[0])
            pt = int(pt / len(ma_pt_list))
            oper = Operation(idx, pt, 0, stage, job)
            # if len(row[4]) > 1:
            #     idm = int(int(row[4]) / 10), int(row[4]) % 10
            #     oper.machine = self.machines[idm]
            #     oper.start_time = row[5]
            self.operations[idx] = oper

        ds = cur.execute(
            "select operation_id, oper_prev_stage, oper_next_stage from sch_operation_info where instance_id = '" + self.name
            + "' order by operation_id")
        for row in ds:
            ido = int(row[0].split('_')[1]), int(row[0].split('_')[2])
            oper = self.operations[ido]

            if row[1].strip() != '':
                idv = int(row[1].split('_')[1]), int(row[1].split('_')[2])
                oper.prev_oper = self.operations[idv]
            if row[2].strip() != '':
                idx = int(row[2].split('_')[1]), int(row[2].split('_')[2])
                oper.next_oper = self.operations[idx]

        stage_list = list(self.stages.values())
        for i in range(1, len(stage_list)):
            buffer = Buffer((i, i + 1))
            buffer.prev_stage = stage_list[i - 1]
            buffer.next_stage = stage_list[i]
            buffer.capacity = Problem.BUF_SIZE
            self.buffers[(i, i + 1)] = buffer

        print('Reading problem is OK')

    def reset(self):
        for mach in self.machines.values():
            mach.reset()
        for buf in self.buffers.values():
            buf.reset()
        for oper in self.operations.values():
            oper.reset()

    def get_btn_stage(self):
        flow_ratio = {}
        for g, stage in self.stages.items():
            TPT = 0
            for op in stage.operations.values():
                TPT += op.duration
            flow_ratio[g] = TPT * 1.0 / len(stage.machines)

        min_g = min(flow_ratio, key=flow_ratio.get)
        return self.stages[min_g]

    def get_in_graph(self):
        G = nx.DiGraph()
        nodes = [op.tag for op in self.operations.values()]
        nodes.insert(0, (0, 0))
        G.add_nodes_from(nodes)

        I = len(self.stages)
        for ma in self.machines.values():
            for r, op in enumerate(ma.operations):
                i, j = op.tag
                if i == 1:
                    G.add_edge((0, 0), (i, j), w=0)  # 到达时间暂时默认为 0
                elif i < I:
                    ix, j = op.next_oper.tag
                    G.add_edge((i, j), (ix, j), w=op.duration + op.time_to_next)
                if i < I and r < len(ma.operations) - 1:
                    i, jx = ma.operations[r + 1].tag
                    G.add_edge((i, j), (i, jx), w=op.duration)
                else:
                    bh = op.job.batch.tag

        print(G)

    def save_to_db(self):
        conn = sqlite3.connect(".//data1//DMOP_3423.db")
        print("Opened database successfully")
        cur = conn.cursor()
        for op in self.operations.values():
            sql = 'update sch_operation_info set start_time={} ,end_time= {}  where instance_id = \'{}\' ' \
                  'and  operation_id = \'{}\''.format(op.start_time, op.end_time, self.name, op.id)
            cur.execute(sql)
        conn.commit()
        conn.close()
        print("Update database successfully")

    def show_in_gantt(self):

        # 1. 绘图参数
        HKeys = list(sorted(self.jobs.keys()))
        MKeys = list(reversed(sorted(self.machines.keys())))

        bar_style = {'alpha': 1.0, 'lw': 15, 'solid_capstyle': 'butt'}
        text_style = {'color': 'white', 'weight': 'bold', 'ha': 'center', 'va': 'center', 'fontsize': 8}
        clr_list1 = mpl.cm.tab10.colors

        # 2. 绘图布局
        sns.set_theme(style="darkgrid")
        rect1 = [0.04, 0.31, 0.96, 0.68]  # [左, 下, 宽, 高] 规定的矩形区域 （全部是0~1之间的数，表示比例）
        rect2 = [0.04, 0.05, 0.96, 0.25]
        ax1 = plt.axes(rect1)
        ax2 = plt.axes(rect2)

        # 2. 绘图数据
        Tmax = 0
        for oper in self.operations.values():
            if oper.machine is None:
                continue
            mid = oper.machine.id
            ym = MKeys.index(mid) + 1
            xs = oper.start_time
            xf = oper.end_time
            hi = HKeys.index(oper.job.id)
            txt = str(oper.job.id) + ' :' + str(xs) + '-' + str(xf)
            ax1.plot([xs, xf], [ym] * 2, c=clr_list1[hi % 10], **bar_style)
            ax1.text((xs + xf) / 2, ym - 0.03, txt, **text_style)
            if oper.end_time > Tmax:
                Tmax = oper.end_time
        WLoad = []
        for x, buf in enumerate(self.buffers.values()):
            WLoad.append([0] * Tmax)
            for oper in buf.oper_list:
                xs = oper.arrival_time
                xf = oper.start_time - 1
                for t in range(xs, xf, 1):
                    WLoad[x][t] += 1


        # 3. 坐标轴
        ax1.set_ylabel('machine')
        ax1.set_ylim(0.5, len(MKeys) + 0.5)
        ax1.set_yticks(range(1, 1 + len(MKeys)))
        MLbls = []
        for i, k in MKeys:
            lbl = '$M_{' + str(i) + ',' + str(k) + '}$'
            MLbls.append(lbl)
        ax1.set_yticklabels(MLbls)

        ax1.text(Tmax, ax1.get_ylim()[0] + 6.6, "{0:0.0f}".format(Tmax), ha='center', va='top')
        ax1.plot([Tmax] * 2, ax1.get_ylim(), 'r--')
        ax1.grid(True)
        ax1.set_xlim(0, (round(Tmax / 10) + 1) * 10)
        ax2.set_xticklabels([])

        clr_list2 = mpl.cm.Set2.colors
        ax2.set_ylabel('WLoad')
        max_WLoad = 0
        for i in range(len(WLoad)):
            ax2.plot(WLoad[i], label=str(i + 1), c=clr_list2[i])
            if max(WLoad[i]) > max_WLoad:
                max_WLoad = max(WLoad[i])

        ax2.plot([Tmax] * 2, [0, round(max(WLoad[0]) + 1)], 'r--')

        ax2.grid(True)
        ax2.set_xlim(0, (round(Tmax / 10) + 1) * 10)
        ax2.set_ylim(0, max_WLoad + 1)
        # ax2.set_yticks(range(0, round(max(WLoad) + 1), 1))
        # ax2.set_yticklabels(range(0, round(max(WLoad) + 1), 1))

        # 4.显示
        plt.get_current_fig_manager().window.showMaximized()
        plt.show()
