from enum import Enum


# 定义一个枚举类型表示任务状态
class OpStatus(Enum):
    WAITING = 0
    IN_PROGRESS = 1
    COMPLETED = 2
    LEAVED = 3


# 定义一个枚举类型表示任务状态
class MaStatus(Enum):
    IDLE = 0
    BUSY = 1


class Entity(object):
    def __init__(self, idx):
        self.__idx = idx

    @property
    def id(self):
        return self.__idx

    @property
    def problem(self):
        return self.__problem

    def __repr__(self):
        return f": {self.__idx}"


class Buffer(Entity):
    MIN_WAITING = 5

    def __init__(self, idx):
        super(Buffer, self).__init__(idx)
        self.__prev_stage = None
        self.__next_stage = None
        self.__capacity = 1
        self.__waiting_list = []
        self.__oper_list = []

    def job_in(self, oper):
        if len(self.__waiting_list) >= self.__capacity:
            return False
        else:
            self.__waiting_list.append(oper)
            self.__oper_list.append(oper)
            return True

    def job_out(self):
        if len(self.__waiting_list) == 0:
            return None
        else:
            return self.__waiting_list.pop(-1)

    @property
    def prev_stage(self):
        return self.__prev_stage

    @prev_stage.setter
    def prev_stage(self, value):
        self.__prev_stage = value
        self.__prev_stage.next_buffer = self

    @property
    def next_stage(self):
        return self.__next_stage

    @next_stage.setter
    def next_stage(self, value):
        self.__next_stage = value
        self.__next_stage.prev_buffer = self

    @property
    def capacity(self):
        return self.__capacity

    @capacity.setter
    def capacity(self, value):
        self.__capacity = value

    @property
    def oper_list(self):
        return self.__oper_list

    def reset(self):
        self.__waiting_list.clear()
        self.__oper_list.clear()


class Job(Entity):
    def __init__(self, idx):
        # tag = (int(idx.split('_')[1]), batch.id, len(batch.jobs) + 1)
        super(Job, self).__init__(idx)
        self.__duedate = 0
        self.__operations = {}

    @property
    def operations(self):
        return self.__operations

    def get_head_op(self):
        if len(self.__operations) == 0:
            return None
        else:
            return list(self.__operations.values())[0]

    def get_tail_op(self):
        if len(self.__operations) == 0:
            return None
        else:
            return list(self.__operations.values())[-1]

    def add_operation(self, operation):
        self.__operations[operation.id] = operation

    @property
    def duedate(self):
        return self.__duedate

    @duedate.setter
    def duedate(self, value):
        self.__duedate = value


class Operation(Entity):
    def __init__(self, idx, pt, mt, stage, job):
        # tag = int(idx.split('_')[1]), int(idx.split('_')[2])
        super(Operation, self).__init__(idx)
        self.__job = job
        self.__PT = pt
        self.__stage = stage
        self.__time_to_next = mt
        self.__prev_oper = None
        self.__next_oper = None
        self.__machine = None
        self.__arrival_time = -1
        self.__start_time = -1
        self.__end_time = -1
        self.__leave_time = -1
        self.__status = 0
        self.__job.add_operation(self)
        self.__stage.add_operation(self)

    @property
    def job(self):
        return self.__job

    @property
    def stage(self):
        return self.__stage

    @property
    def prev_oper(self):
        return self.__prev_oper

    @property
    def next_oper(self):
        return self.__next_oper

    @property
    def machine(self):
        return self.__machine

    @machine.setter
    def machine(self, value):
        self.__machine = value
        if value is not None:
            self.__machine.add_operation(self)

    @property
    def duration(self):
        return self.__PT

    @property
    def arrival_time(self):
        return self.__arrival_time

    @arrival_time.setter
    def arrival_time(self, value):
        self.__arrival_time = value

    @property
    def start_time(self):
        return self.__start_time

    @start_time.setter
    def start_time(self, value):
        self.__start_time = value

    @property
    def status(self):
        return self.__status

    @status.setter
    def status(self, value):
        self.__status = value

    @property
    def end_time(self):
        return self.__start_time + self.__PT

    @property
    def leave_time(self):
        return self.__leave_time

    @leave_time.setter
    def leave_time(self, value):
        self.__leave_time = value

    @property
    def time_to_next(self):
        return self.__time_to_next

    @prev_oper.setter
    def prev_oper(self, value):
        self.__prev_oper = value

    @next_oper.setter
    def next_oper(self, value):
        self.__next_oper = value

    def reset(self):
        self.__machine = None
        self.__arrival_time = -1
        self.__start_time = -1
        self.__end_time = -1
        self.__leave_time = -1
        self.__status = 0


class Machine(Entity):
    def __init__(self, idx, stage):
        # tag = int(int(idx) / 10), int(idx) % 10
        super(Machine, self).__init__(idx)
        self.__operations = []
        self.__stage = stage
        self.__status = 0
        self.__stage.add_machine(self)

    @property
    def operations(self):
        self.__operations.sort(key=lambda x: x.start_time)
        return self.__operations

    @property
    def stage(self):
        return self.__stage

    @property
    def status(self):
        return self.__status

    @status.setter
    def status(self, value):
        self.__status = value

    def add_operation(self, operation: Operation):
        self.__operations.append(operation)

    def reset(self):
        self.__operations.clear()
        self.__status = 0


class Stage(Entity):

    def __init__(self, idx):
        tag = int(idx),
        super(Stage, self).__init__(idx)
        self.__machines = {}
        self.__transfers = {}
        self.__operations = {}
        self.__prev_buffer = None
        self.__next_buffer = None
        return

    @property
    def machines(self):
        return self.__machines

    @property
    def transfers(self):
        return self.__transfers

    @property
    def operations(self):
        return self.__operations

    @property
    def prev_buffer(self):
        return self.__prev_buffer

    @property
    def next_buffer(self):
        return self.__next_buffer

    @prev_buffer.setter
    def prev_buffer(self, value):
        self.__prev_buffer = value

    @next_buffer.setter
    def next_buffer(self, value):
        self.__next_buffer = value

    def add_machine(self, machine: Machine):
        self.__machines[machine.id] = machine

    def add_transfer(self, sid, time):
        self.__transfers[sid] = time

    def add_operation(self, oper):
        self.__operations[oper.id] = oper
