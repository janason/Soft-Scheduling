import itertools
import pandas as pd
import seaborn as sns
import statsmodels.api as sm
from statsmodels.formula.api import ols
import numpy as np
import matplotlib.pyplot as plt
from statsmodels.sandbox.stats.multicomp import MultiComparison

from common.indicators import hv_indicator, sp_indicator, get_pareto_front, sr_indicator

design_table = [
    [1, 1, 1, 1], [1, 2, 2, 2], [1, 3, 3, 3], [1, 4, 4, 4],
    [2, 1, 2, 3], [2, 2, 1, 4], [2, 3, 4, 1], [2, 4, 3, 2],
    [3, 1, 3, 4], [3, 2, 4, 3], [3, 3, 1, 2], [3, 4, 2, 1],
    [4, 1, 4, 2], [4, 2, 3, 1], [4, 3, 2, 4], [4, 4, 1, 3]]

param_table = {'P_size': [0.50, 1.00, 1.50, 2.00],
               'nb_size': [0.05, 0.10, 0.15, 0.20],
               'nv_size': [2, 3, 4, 5],
               'gamma': [0.5, 1, 1.5, 2]}


def calc_response(ex, df):
    df_exp = df[df['ex'] == ex]
    ins_list = df_exp['ins'].unique()
    hv_list = []
    for ins in ins_list:
        df_ins = df[df['ins'] == ins]
        z_max = [df_ins['f1'].max(), df_ins['f2'].max()]
        z_min = [df_ins['f1'].min(), df_ins['f2'].min()]
        dfx = df_ins[df_ins['ex'] == ex]
        z_vec = dfx[['f1', 'f2']].drop_duplicates().values
        hv = hv_indicator(z_obj=z_vec, n_obj=2, max_pt=z_max, min_pt=z_min, ref_pt=[1.0, 1.0])
        hv_list.append(hv)

    hv_avg = sum(hv_list)*1.0/len(hv_list)
    return  hv_avg

def comparison(result):
    data = []
    for i in range(16):
        file_path = '../DOE/EX-' + f'{i}.txt'
        with open(file_path, 'r') as f:
            lines = f.readlines()
            for r in range(len(lines)):
                xx = lines[r].split()
                x = xx[0].split(',')
                data.append([i, x[0], float(x[1]), float(x[2])])
    df_PF = pd.DataFrame(data, columns=['ex', 'ins', 'f1', 'f2'])
    result['response'] = []
    for i in range(16):
        y = calc_response(i, df_PF)
        result['response'].append(y)


if __name__ == "__main__":
    data = {}
    factors = []
    for factor in param_table.keys():
        data[factor] = []
        factors.append(factor)
    for dsg in design_table:
        for i in range(len(dsg)):
            data[factors[i]].append(dsg[i])
    comparison(data)
    df = pd.DataFrame(data)
    print(df)

    results = {}

    print("极差分析结果：")
    for factor in factors:
        means = df.groupby(factor)['response'].mean()
        R = means.max() - means.min()
        results[factor] = means
        print(f"\n因子 {factor} 各水平平均值:\n{means}")
        print(f"极差 R = {R:.2f}")

    # 3. 主效应排序（因素重要性排序）
    r_values = {f: v.max() - v.min() for f, v in results.items()}
    sorted_r = sorted(r_values.items(), key=lambda x: x[1], reverse=True)

    print("\n因子影响程度排序（极差法）：")
    for factor, r in sorted_r:
        print(f"{factor}: R = {r:.2f}")

    # 4. 推荐最优水平（平均响应最大）
    optimal_levels = {f: results[f].idxmax() for f in factors}
    print("\n推荐最优组合（使Y最大）：")
    print(optimal_levels)

    # 3. 方差分析（ANOVA）
    model = ols('response ~ C(P_size) + C(nb_size) + C(nv_size) + + C(gamma)', data=df).fit()
    anova_table = sm.stats.anova_lm(model, typ=2)
    print("\n方差分析结果:")
    print(anova_table)

    # 4. 可视化主效应图
    import seaborn as sns
    sns.set(style="ticks", palette="colorblind", font_scale=1.0)
    fig, axes = plt.subplots(1, len(results), figsize=(10, 5), sharey=True)
    for i, (factor, means) in enumerate(results.items()):
        axes[i].plot([_+1 for _ in range(4)], means, marker='s')
        axes[i].set_title(f'{factor}')
        axes[i].set_xlabel('Level')
        axes[i].set_xticks([_+1 for _ in range(4)])
        if i == 0:
            axes[i].set_ylabel('Response')

    plt.suptitle('Main Effects Plot')
    plt.tight_layout()
    plt.show()