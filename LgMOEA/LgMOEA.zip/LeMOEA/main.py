import importlib
import itertools
import multiprocessing
import time
import numpy as np
from hybrid_flow_shop.problem import Problem
from algorithm.EagMOEAd import EagMOEAd
from algorithm.MOEAd import MOEAd
from algorithm.NSGA2 import NSGA2
from algorithm.MOPSO import MOPSO

# An improved particle swarm optimization algorithm to solve
# hybrid flow shop scheduling problems with the effect of human factors – A case study

def param_tuning():
    pass


def comparison_test(fid, iid):
    inst = f'{fid}#{iid}'
    problem = Problem(inst)
    problem.read_instance()
    problem.reset()
    algo_list = ['LeMOEAk', 'NSGA2', 'NSGA2LS', 'MOEAd', 'EagMOEAd', 'MOPSO']
    # algo_list = ['LeMOEAk', 'NSGA2', 'NSGA2LS']
    for name, _ in itertools.product(algo_list, [_ for _ in range(5)]):
        print('algorithm: ---------' + name + '---------------')
        maxTFE = len(problem.jobs)*len(problem.stages)*100
        modl = importlib.import_module('algorithm.' + name)
        ALGO = getattr(modl, name)
        start = time.perf_counter()
        Psize = int(1.0 * len(problem.jobs))
        algo = ALGO(problem, Psize, int(maxTFE/Psize))
        algo.initialize()
        algo.execute()
        end = time.perf_counter()
        cpu = end - start
        print(f'{inst} is solved by {name} within {cpu} seconds \n')
        with open(f"./data/{inst}.txt", "a") as file:
            for sol in algo.EAP:
                str = f'{name},{sol.y_obj[0]:.3f},{sol.y_obj[1]:.3f}\n'
                file.write(str)

# 定义子进程要执行的任务
def worker(pid):
    print(f"进程 {pid} 启动")
    for sid in range(3,6):
        comparison_test(pid+1, sid)
    print(f"进程 {pid} 结束")



if __name__ == "__main__":
    #1. 常规模式，
    # for fid, iid in itertools.product(range(1, 6), range(1, 6)):
    #     comparison_test(fid, iid)
    #2. 多进程模式，
    processes = []
    for i in range(5):
        p = multiprocessing.Process(target=worker, args=(i,))
        processes.append(p)
        p.start()
    for p in processes:
        p.join()
    print("所有进程执行完毕")