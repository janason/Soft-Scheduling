 #include "jaMOSSoln.h"



jaMOSSoln::jaMOSSoln(double init_ke)
{
	this->m_rtype = REACTION_TYPE::NONE;
	this->MIN_HIT_NUM = 0;
	this->HIT_NUM = 0;
	this->PE = 0;
	this->KE = init_ke;
	this->num_repc = 0;
	this->ASF_value = 8888.0;
	
}
 
jaMOSSoln::~jaMOSSoln()
{

}


/************************************************************************/
/* ͳ�ƾ�ֵ������ͼ�����������                                                                
/************************************************************************/
void jaMOSSoln::statistics()
{
	if (num_repc==0)
	{
		return ;
	}
	//��ֵ
	//mean = make_tuple(0.0, 0.0, 0.0);
	double sumx[3] = {0.0,0.0,0.0};
	for (int i = 0; i < num_repc; i++)
	{
		sumx[0] += objs[0][i];
		sumx[1] += objs[1][i];
		sumx[2] += objs[2][i];
	}
	means[0] = sumx[0] / num_repc;
	means[1] = sumx[1] / num_repc;
	means[2] = sumx[2] / num_repc;

	//����
	double sumy[3] = { 0.0,0.0,0.0 };
	for (int i = 0; i < num_repc; i++)
	{
		sumy[0] += (objs[0][i] - means[0])*(objs[0][i] - means[0]);
		sumy[1] += (objs[1][i] - means[1])*(objs[1][i] - means[1]);
		sumy[2] += (objs[2][i] - means[2])*(objs[2][i] - means[2]);
	}
	vars[0] = sumy[0] / (num_repc - 1);
	vars[1] = sumy[1] / (num_repc - 1);
	vars[2] = sumy[2] / (num_repc - 1);

	//3.��������
	//std::get<0>(CI).first = std::get<0>(mean) - 1.96*sqrt(std::get<0>(var) / num_repc);
	//std::get<0>(CI).second = std::get<0>(mean) + 1.96*sqrt(std::get<0>(var) / num_repc);

	//std::get<1>(CI).first = std::get<1>(mean) - 1.96*sqrt(std::get<1>(var) / num_repc);
	//std::get<1>(CI).second = std::get<1>(mean) + 1.96*sqrt(std::get<1>(var) / num_repc);

	//std::get<2>(CI).first = std::get<2>(mean) - 1.96*sqrt(std::get<2>(var) / num_repc);
	//std::get<2>(CI).second = std::get<2>(mean) + 1.96*sqrt(std::get<2>(var) / num_repc);
	return ;
}

void jaMOSSoln::setReactionType(REACTION_TYPE type)
{
	this->m_rtype = type;
}

REACTION_TYPE jaMOSSoln::getReactionType()
{
	return this->m_rtype;
}

void jaMOSSoln::setParent(jaMOSSoln* p1,jaMOSSoln* p2)
{
	this->m_parents.first = p1;
	this->m_parents.second = p2;
}

pair<jaMOSSoln*, jaMOSSoln*>& jaMOSSoln::getParent()
{
	return this->m_parents;
}

bool jaMOSSoln::wall_reaction(jaMOSSoln* in, jaMOSSoln* out)
{
	std::normal_distribution<double> dist(0.0,1.0);
	std::default_random_engine eng(time(0)); //����  
	
	out->m_code = in->m_code;
	for (size_t i = 0; i < m_code.size() / 2; i++)
	{
		double rnd = CRORandDouble();
		if (rnd > 0.5)
		{
			out->m_code[i] += dist(eng);
			if (out->m_code[i] > 1.0)  //�߽紦��
				out->m_code[i] = 2.0 - out->m_code[i];
			if (out->m_code[i] < 0.0)  //�߽紦�� 
				out->m_code[i] = 0.0 - out->m_code[i];
		}
	}
	out->setReactionType(REACTION_TYPE::WALL);
	out->setParent(in);
	return true;
}

bool jaMOSSoln::dec_reaction(jaMOSSoln* in, jaMOSSoln* out1, jaMOSSoln* out2)
{
	out1->m_code = in->m_code;
	out2->m_code = in->m_code;
	int N=(int)m_code.size();
	for (size_t i = 0; i < m_code.size()/2; i++)
	{
		int r1 = CRORandInt(N);
		int r2 = r1;
		while (r1==r2)
		{
			r2 = CRORandInt(N);
		}
		std::swap(out1->m_code[r1], out2->m_code[r2]);
	}
	out1->setReactionType(REACTION_TYPE::DEC);
	out2->setReactionType(REACTION_TYPE::DEC);
	out1->setParent(in);
	out2->setParent(in);
	return true;
}

bool jaMOSSoln::syn_reaction(jaMOSSoln* in1, jaMOSSoln* in2, jaMOSSoln* out)
{
	out->m_code = in1->m_code;
	for (size_t i = 0; i < m_code.size();i++)
	{
		double rnd = CRORandDouble();
		if (rnd>0.5)
		{
			out->m_code[i] = in2->m_code[i];
		}
	}
	out->setReactionType(REACTION_TYPE::SYNC);
	out->setParent(in1, in2);
	return true;
}

bool jaMOSSoln::inter_reaction(jaMOSSoln* in1, jaMOSSoln* in2, jaMOSSoln* out1, jaMOSSoln* out2)
{
	out1->m_code = in1->m_code;
	out2->m_code = in2->m_code;
	for (size_t i = 0; i < m_code.size(); i++)
	{
		double rnd = CRORandDouble();
		if (rnd > 0.5)
		{
			out1->m_code[i] = in1->m_code[i];
			out2->m_code[i] = in2->m_code[i];
		}
		else {
			out1->m_code[i] = in2->m_code[i];
			out2->m_code[i] = in1->m_code[i];
		}
	}	
	out1->setReactionType(REACTION_TYPE::INTER);
	out2->setReactionType(REACTION_TYPE::INTER);
	out1->setParent(in1, in2);
	out2->setParent(in1, in2);
	return true;
}

