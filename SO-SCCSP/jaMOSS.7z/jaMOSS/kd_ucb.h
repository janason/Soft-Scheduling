#pragma once

#ifndef _JA_KDUCB_H_
#define _JA_KDUCB_H_

#include "jaMOSSMacro.h"

class jaKDUCB
{
	const unsigned int K;   //�ϻ�������
	std::vector<int> Ni;    //ѡ�������¼
	std::vector<double> Gi; //ÿ���ϻ��۵�����
	
public:
	jaKDUCB(int K) : K(K){
		reset();
	}
	void reset() {
		Ni = std::vector<int>(K, 0);
		Gi = std::vector<double>(K, 0.0);
	}
	
	int selectNextArm() {
		
		return 0;
	}
	
	void updateState(int k, int n, double r)
	{
		Ni[k] = n;
		Gi[k] = r;
	}
	
};

#endif