#include "jaMOSPSO.h"
#include "student_t.h"


jaMOSPSO::jaMOSPSO(string algo_name):jaAlogrithm(algo_name)
{
	C1 = 0.1;
	C2 = 0.1;
	W = 1.0;
}


jaMOSPSO::~jaMOSPSO()
{
}

bool jaMOSPSO::initialize()
{

	//0. ��ʼ��������¯�ε�˳��
	for (auto bah_pair : m_pProblem->getBatchMap())
	{
		jaBatch* pBatch = bah_pair.second;
		for (auto op_pair : pBatch->getOperMap())
		{
			pBatch->getOperSequence().push_back(op_pair.second);
		}
	}
	//1. ��ʼ���㷨����
	NDIM = (int)this->m_pProblem->getBatchMap().size() * 2;
	POP_SIZE = NDIM * POP_UNIT;
	this->ideal_point = make_tuple(1.0e6, 1.0e6, 1.0e6);
	this->ndir_point = make_tuple(-1.0e6, -1.0e6, -1.0e6);

	//2. ��ʼ����������һ��ƽ���������棬����ʽ����Ⱥ����������û������
	this->m_pScher = new jaDispatcher(m_pProblem);
	for (unsigned i = 0; i < POP_SIZE; i++)
	{
		jaMOSSoln* pSoln = new jaMOSSoln(INIT_KE);
		for (int r = 0; r < NDIM / 2; r++)
		{
			pSoln->m_code.push_back(CRORandDouble());
		}
		for (int r = 0; r < NDIM / 2; r++)
		{
			pSoln->m_code.push_back(CRORandDouble()*0.5);
		}
		pSoln->KE = INIT_KE;
		pSoln->cur_repc = AVG_REPC;
		this->round_simulation(pSoln);
		this->update_ideal_point(pSoln);
		
		//��ʼ������
		Particle* particle = new Particle(pSoln);
		particle->m_BestFit = pSoln->PE;
		particle->m_BestPos = pSoln->m_code;
		for (int r = 0; r < NDIM; r++)
		{
			particle->m_Velocity.push_back(CRORandDouble()*0.5);
		}
		this->m_population.push_back(particle);

		DbgPrint("[%d] num=%d, PE=%.4f, mean1=%.2f, mean2=%.2f,mean3=%.2f \n", i
			, pSoln->num_repc, pSoln->PE, pSoln->means[0], pSoln->means[1], pSoln->means[2]);
		
	}
	//3. ����ο����Ȩ��������
	this->update_weights_point();
	//4. ��ʼ������	
	for (unsigned i = 0; i < POP_SIZE; i++)
	{
		jaMOSSoln* pSoln = m_population[i]->m_pSoln;
		for (int k = 0; k < pSoln->num_repc; k++)
		{
			this->calc_asf_value(pSoln, k);
		}
		this->estimate_asf_value(pSoln);
		DbgPrint("[%d] num=%d, PE=%.4f, mean1=%.2f, mean2=%.2f,mean3=%.2f \n", i
			, pSoln->num_repc, pSoln->PE, pSoln->means[0], pSoln->means[1], pSoln->means[2]);
		m_population[i]->m_BestFit = pSoln->PE;	
	}	
	return true;
}

bool jaMOSPSO::reset()
{
	return true;
}

bool jaMOSPSO::run()
{
	const time_t start = time(NULL);
	//1.ѡ����Ѹ���
	std::sort(begin(m_population), end(m_population), [](Particle* a, Particle* b)
	{
		return a->m_pSoln->PE < b->m_pSoln->PE;
	});
	vector<double> gbest_pos = m_population.front()->m_pSoln->m_code;
	double gbest_fit = m_population.front()->m_pSoln->PE;
	int it = 0;
	while (1) //�����ײ�����
	{
		//1. ѡ�� gbest position
		it++;
		for (unsigned i = 0; i < m_population.size(); i++)
		{
			Particle* particle = m_population[i];
			vector<double> X = particle->m_pSoln->m_code;
			for (int j = 0; j < NDIM;j++)
			{				
				double v = W*particle->m_Velocity[j]
					+ C1*CRORandDouble()*(particle->m_BestPos[j] - X[j]) + C2*CRORandDouble()*(gbest_pos[j] - X[j]);
				if (v > 2.0) v = 1.0; 
				if (v < -2.0) v = -1.0;
				particle->m_Velocity[j] = v;
				double x = X[j] + v;
				if (x > 1.0) x = 1.0;
				if (x < 0.0) x = 0.0;
				particle->m_pSoln->m_code[j] = x;
			}
			//����
			particle->m_pSoln->soft_decisions.clear();
			particle->m_pSoln->num_repc = 0;
			particle->m_pSoln->cur_repc = AVG_REPC; //ƽ�����䣬��ʱ
			this->round_simulation(particle->m_pSoln);
			particle->m_pSoln->statistics();
			particle->m_pSoln->PE = 0.0;
			DbgPrint("[%d] id=%d, PE=%.4f, mean1=%.2f, mean2=%.2f,mean3=%.2f \n", it
				, i, particle->m_pSoln->PE, particle->m_pSoln->means[0], particle->m_pSoln->means[1], particle->m_pSoln->means[2]);
			m_population[i]->m_BestFit = particle->m_pSoln->PE;
		}		
		for (unsigned i = 0; i < m_population.size(); i++)
		{
			Particle* particle = m_population[i];			
			this->estimate_asf_value(particle->m_pSoln);
			if (particle->m_pSoln->PE < particle->m_BestFit)
			{
				particle->m_BestFit = particle->m_pSoln->PE;
				particle->m_BestPos = particle->m_pSoln->m_code;
			}
			if (particle->m_pSoln->PE < gbest_fit)
			{
				gbest_fit = particle->m_pSoln->PE;
				gbest_pos = particle->m_pSoln->m_code;
			}
			DbgPrint("[%d] id=%d, PE=%.4f, mean1=%.2f, mean2=%.2f,mean3=%.2f \n", it
				, i, particle->m_pSoln->PE, particle->m_pSoln->means[0], particle->m_pSoln->means[1], particle->m_pSoln->means[2]);
			m_population[i]->m_BestFit = particle->m_pSoln->PE;
		}
		const time_t end = time(NULL);
		if (end - start >= 90)
			break;
	}

	jaMOSSoln* pBestSoln = new jaMOSSoln(INIT_KE);
	pBestSoln->m_code = gbest_pos;
	pBestSoln->cur_repc = 1000;
	this->round_simulation(pBestSoln);
	pBestSoln->statistics();
	this->estimate_asf_value(pBestSoln);
	DbgPrint("#[%d] best ASF=%.4f recs=%d \n", 0, pBestSoln->PE, pBestSoln->num_repc);
	DbgPrint("#[%d] best output [%.2f %.2f %.2f %.2f %.2f %.2f] \n", 0,
		pBestSoln->means[0], sqrt(pBestSoln->vars[0]),
		pBestSoln->means[1], sqrt(pBestSoln->vars[1]),
		pBestSoln->means[2], sqrt(pBestSoln->vars[2]));
	return true;
}

void jaMOSPSO::update_ideal_point(jaMOSSoln* pSoln)
{

	//confidence_limits_on_mean(pSoln->means[0], pSoln->vars[0],pSoln->num_repc);
	double T1 = get_quantile(pSoln->num_repc, 1 - 0.99);
	pSoln->statistics();
	double ideal_0 = pSoln->means[0] - T1*std::sqrt(pSoln->vars[0] / pSoln->num_repc);
	double ideal_1 = pSoln->means[1] - T1*std::sqrt(pSoln->vars[1] / pSoln->num_repc);
	double ideal_2 = pSoln->means[2] - T1*std::sqrt(pSoln->vars[2] / pSoln->num_repc);
	if (ideal_0 < std::get<0>(ideal_point))
	{
		std::get<0>(ideal_point) = ideal_0;
	}
	if (ideal_1 < std::get<1>(ideal_point))
	{
		std::get<1>(ideal_point) = ideal_1;
	}
	if (ideal_2 < std::get<2>(ideal_point))
	{
		std::get<2>(ideal_point) = ideal_2;
	}

	double T2 = get_quantile(pSoln->num_repc, 1 - 0.9);
	double ndir_0 = pSoln->means[0] - T2*std::sqrt(pSoln->vars[0] / pSoln->num_repc);
	double ndir_1 = pSoln->means[1] - T2*std::sqrt(pSoln->vars[1] / pSoln->num_repc);
	double ndir_2 = pSoln->means[2] - T2*std::sqrt(pSoln->vars[2] / pSoln->num_repc);
	if (ndir_0 > std::get<0>(ndir_point))
	{
		std::get<0>(ndir_point) = ndir_0;
	}
	if (ndir_1 > std::get<1>(ndir_point))
	{
		std::get<1>(ndir_point) = ndir_1;
	}
	if (ndir_2 > std::get<2>(ndir_point))
	{
		std::get<2>(ndir_point) = ndir_2;
	}

}

void jaMOSPSO::update_weights_point()
{
	//m_weights.resize(3,0.001);
	WEIGHTS[0] = 1.0 / (std::get<0>(ndir_point) - std::get<0>(ideal_point));
	WEIGHTS[1] = 1.0 / (std::get<1>(ndir_point) - std::get<1>(ideal_point));
	if (std::get<2>(ndir_point) - std::get<2>(ideal_point) != 0)
		WEIGHTS[2] = 1.0 / (std::get<2>(ndir_point) - std::get<2>(ideal_point));
	//�ο������ʹ��ѧϰ�ķ����õ���RBF������Ŀǰ���þ�ֵ
	ref_point = make_tuple(0.0, 0.0, 0.0);
	for (int i = 0; i < (int)m_population.size(); i++)
	{
		jaMOSSoln* pSoln = m_population[i]->m_pSoln;
		pSoln->statistics();
		std::get<0>(ref_point) += (pSoln->means[0] - 1.65*sqrt(pSoln->vars[0]));
		std::get<1>(ref_point) += (pSoln->means[1] - 1.65*sqrt(pSoln->vars[1]));
		std::get<2>(ref_point) += (pSoln->means[2] - 1.65*sqrt(pSoln->vars[2]));
	}
	std::get<0>(ref_point) = std::get<0>(ref_point) / m_population.size();
	std::get<1>(ref_point) = 0.0;
	std::get<2>(ref_point) = 0.0;
}

double jaMOSPSO::round_simulation(jaMOSSoln* pSoln)
{
	this->m_pScher->construct_soft_solution(pSoln);

	for (int i = 0; i < pSoln->cur_repc; i++)
	{
		m_pProblem->sampling(nullptr);
		m_pScher->initialize();
		m_pScher->runSimu();
		std::tuple<double, double, double> objx = m_pScher->calcSimuObj();
		pSoln->objs[0][pSoln->num_repc] = std::get<0>(objx);
		pSoln->objs[1][pSoln->num_repc] = std::get<1>(objx);
		pSoln->objs[2][pSoln->num_repc] = std::get<2>(objx);
		pSoln->num_repc++;
	}
	return 0.0;
}

double jaMOSPSO::estimate_asf_value(jaMOSSoln* pSoln)
{
	double T = get_quantile(pSoln->num_repc, 1 - BETA);
	double v0 = (pSoln->means[0] - T*std::sqrt(pSoln->vars[0] / pSoln->num_repc)
		- std::get<0>(ref_point))*WEIGHTS[0];
	double v1 = (pSoln->means[1] - T*std::sqrt(pSoln->vars[1] / pSoln->num_repc)
		- std::get<1>(ref_point))*WEIGHTS[1];
	double v2 = (pSoln->means[2] - T*std::sqrt(pSoln->vars[2] / pSoln->num_repc)
		- std::get<2>(ref_point))*WEIGHTS[2];
	double max_v = std::max(v0, std::max(v1, v2));
	double sum_v = SCALARIZING*(v0 + v1 + v2);
	pSoln->ASF_value = max_v + sum_v;
	pSoln->PE = pSoln->ASF_value;
	return pSoln->ASF_value;
}

double jaMOSPSO::calc_asf_value(jaMOSSoln* pSoln, int no)
{
	double v0 = (pSoln->objs[0][no]
		- std::get<0>(ref_point))*WEIGHTS[0];
	double v1 = (pSoln->objs[1][no]
		- std::get<1>(ref_point))*WEIGHTS[1];
	double v2 = (pSoln->objs[2][no]
		- std::get<1>(ref_point))*WEIGHTS[2];
	double max_v = std::max(v0, std::max(v1, v2));
	double sum_v = SCALARIZING*(v0 + v1 + v2);
	pSoln->asf_vals[no] = max_v + sum_v;
	return pSoln->asf_vals[no];
}
