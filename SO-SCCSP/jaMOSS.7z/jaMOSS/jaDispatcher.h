#ifndef _JA_OLSCHER_H_
#define _JA_OLSCHER_H_

/************************************************************************/
/* ���ַ��򻯵ķ���Ҫ�ȳ����ٶ�Ҫ��Щ��                                                              
/************************************************************************/
#include <jaSimulation/entity/jaSimuMsg.h>
#include <jaSimulation/util/jaCommon.h>
#include "jaMOSSMacro.h"
#include "jaMOSSoln.h"
#include <jaSimulation/entity/jaResource.h>

class jaDispatcher
{
public:
	jaDispatcher(jaProblem* pProblem);
	~jaDispatcher(void);

	bool runSimu();
	bool initialize();

	std::tuple<double,double,double> calcSimuObj();	
	void construct_soft_solution(jaMOSSoln* pSoln);
	//jaBatch* m_pClosedBatch;
	int m_nSimuTime;//��ǰ����ʱ��	
private:	
	list<jaOperation*> m_OperList; //�����ȵ��������񣬿�ʼʱ���Ѿ�ȷ��
	vector<jaStage*> m_StageList; //�����б�
	vector<jaResource*> m_RescList;// ��Դ�б�������ʱ��
	vector<jaBatch*> m_BatchList;
	list<jaSimuMsg*> m_MsgList; //��Ϣ�б�
	jaProblem* m_pProblem;
	jaMOSSoln* m_pSimuSoln;
	jaStage* m_pLStage;
	jaStage* m_pFStage;
	
	int m_nBCursor;
	int m_nJCursor;	
	void release_jobs(int batch_num);

	void printMsgList();
	void handleSimuMsg(jaSimuMsg* pMsg);
	void sendSimuMsg(int nSimuTime, jaStage* pSend, jaStage* pRecv, SIMULATION_MSG msg, void* pObj);
	void insertMsg2List(jaSimuMsg* pMsg,int flag=0);
	bool handleOperArriveMsg(jaOperation* pOper);
	bool handleMachReleaseMsg(jaMachine* pMach);
	
	jaOperation* select_operation(jaMachine* pMach);
	jaOperation* release_operation(jaMachine* pMach);

	void start_operation(jaOperation* pOper, jaMachine* pMach);
	void finsih_operation(jaOperation* pOper, jaMachine* pMach);

	void update_batch_CT(jaOperation* pOper);

	bool select_resource(jaOperation* pOper);
};

#endif