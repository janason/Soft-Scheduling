#ifndef _JA_MOSS_MACRO_H_
#define _JA_MOSS_MACRO_H_

#ifdef JAMOSS_EXPORTS
#define JA_MOSS_DLL __declspec(dllexport)
#else
#define JA_MOSS_DLL __declspec(dllimport)
#endif

#include <jaSimulation/jaProblem.h>

#include <stdlib.h>
#include <time.h>

#define MOSS_COE_BK 1.0;
#define MOSS_COE_WT 1.0;
#define MOSS_COE_OW 1.0;
#define MAX_QT 20.0

static unsigned OBJ_DIM=3;
static unsigned POP_SIZE=50;
static double INIT_BUFFER=0.0;
static double LOSS_RATE=0.2;
static double INIT_KE =0.0;
static double SCALARIZING=1.0e-3; //�ο����� a multimodal 
static double WEIGHTS[3] = {0.0};

static unsigned POP_UNIT = 5*1; // n*5
static double COLL_RATE = 0.1*2; // n*0.1
static unsigned AVG_REPC = 5+5*1; // (n+1)*5
static double LOCAL_RATE = 0.025 + 0.025 * 4;  // (n+1)*0.025
static double LOCAL_COUNT = 10*1; //0.5*n*POP.SIZE

static double BETA = 0.95;

inline void CRORandSeed(unsigned seed = 0)
{
	if (seed == 0)
		srand(static_cast<unsigned int>(time(0)));
	else
		srand(seed);
}

inline double CRORandDouble()
{
	return (double)rand() / ((double)RAND_MAX + 1.0);
}

inline int CRORandInt(int high)
{
	return (int)(CRORandDouble() * (double)high);
}

template<class T>
T vectorSum(const std::vector<T> &elems) {
	T s = 0;
	for (unsigned int i = 0; i < elems.size(); ++i) {
		s += elems[i];
	}
	return s;
}

template<class T>
int vectorMaxIndex(const std::vector<T> &elems) {
	int m = 0;
	T mv = elems[0];
	for (unsigned int i = 0; i < elems.size(); ++i) {
		if (elems[i] > mv) {
			mv = elems[i];
			m = i;
		}
	}
	return m;
}


enum REACTION_TYPE{	NONE,WALL, DEC, INTER, SYNC};

#endif