#ifndef _JA_MOSPSO_H_
#define _JA_MOSPSO_H_

#include <jaSimulation/entity/jaAlogrithm.h>
#include "jaMOSSMacro.h"
#include "jaDispatcher.h"

class Particle
{
public:
	
	Particle(jaMOSSoln* pSoln) {
		this->m_pSoln = pSoln;
	}
	~Particle() {}	
	
	jaMOSSoln* m_pSoln; //position �� fitness ����¼�� soln��

	vector<double> m_Velocity;	
	vector<double> m_BestPos;	
	double m_BestFit;		
};

class JA_MOSS_DLL jaMOSPSO: public jaAlogrithm
{
public:
	jaMOSPSO(string algo_name);
	~jaMOSPSO();

	bool initialize();
	bool reset();
	bool run();

private:
	
	double C1, C2, W;
	int NDIM;

	void update_ideal_point(jaMOSSoln* pSoln);
	void update_weights_point();
	std::tuple<double, double, double> ideal_point;
	std::tuple<double, double, double> ndir_point;
	std::tuple<double, double, double> ref_point;

	vector<Particle*> m_population;
	jaDispatcher* m_pScher;


	double round_simulation(jaMOSSoln* pSoln);
	double estimate_asf_value(jaMOSSoln* pSoln);
	double calc_asf_value(jaMOSSoln* pSoln, int no);

};

#endif // !_JA_MOSPSO_H_