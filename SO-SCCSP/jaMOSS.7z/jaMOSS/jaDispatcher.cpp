#include "jaDispatcher.h"


jaDispatcher::jaDispatcher(jaProblem* pProblem)
{
	this->m_pProblem=pProblem;
	this->m_nSimuTime=0;
	this->m_pLStage=pProblem->getStageMap().rbegin()->second; //stage�����������
	this->m_pFStage = pProblem->getStageMap().begin()->second;

	for (auto stg_pair : m_pProblem->getStageMap())
	{
		this->m_StageList.push_back(stg_pair.second);
	}
	for (auto res_pair : m_pProblem->getRescMap())
	{
		this->m_RescList.push_back(res_pair.second);
	}
}


jaDispatcher::~jaDispatcher(void)
{
	
}

bool jaDispatcher::initialize()
{	
	//1.�����Ϣ�б�
	while (!this->m_MsgList.empty())
	{
		jaSimuMsg* pMsg=m_MsgList.front();
		m_MsgList.pop_front();
		delete pMsg;
		pMsg=nullptr;
	}
	//2.��ʼ��ʱ���
	for (auto it=begin(m_pProblem->getOperMap());
		it!=end(m_pProblem->getOperMap());++it)
	{
		jaOperation* pOper=it->second;
		pOper->setStatus(OPERATION_STATUS::OPER_UNARRIVED);	
		pOper->getJob()->setStatus(JOB_STATUS::JOB_UNARRIVED);
		pOper->setStartTime(0);
		pOper->setFinishTime(0);
		pOper->setMachine(nullptr);		
	}
	//3.��ʼ�ӹ�����
	for (auto it=begin(m_pProblem->getMachineMap());
		it!=end(m_pProblem->getMachineMap());++it)
	{
		jaMachine* pMach=it->second;
		pMach->setStatus(MACH_LOCK);
		pMach->setReleaseTime(0);
		pMach->getProcessList().clear();	
		pMach->getBreakList().clear();
		pMach->getWaittingList().clear();
		pMach->getStage()->getWaittingList().clear();
	}		
	//4.��ʼ����Դ�б�
	this->m_RescList.clear();
	for (auto it = begin(m_pProblem->getRescMap());
	it != end(m_pProblem->getRescMap()); it++)
	{
		jaResource* pResc = it->second;
		this->m_RescList.push_back(pResc);
	}
	//5.��ʼ�������б�
	this->m_BatchList.clear();
	for (auto it = begin(m_pProblem->getBatchMap());
	it != end(m_pProblem->getBatchMap()); it++)
	{
		m_BatchList.push_back(it->second);
	}
	this->m_nSimuTime = 0;	
	this->m_nBCursor = 0;
	this->m_nJCursor = 0;	
	return true;
}

bool jaDispatcher::runSimu()
{
	//DbgPrint("--------------------------------------\n");		
	this->release_jobs(m_pLStage->getMachineMap().size()); //�ͷŸ����ε�¯�Σ�
	//2. �����¼��ķ���
	this->m_nSimuTime=0;
	m_MsgList.sort([](jaSimuMsg* pMsg1,jaSimuMsg* pMsg2)
	{
		return pMsg1->m_TimeStamp<pMsg2->m_TimeStamp;
	});		
	while(!m_MsgList.empty())
	{
		jaSimuMsg* pMsg=m_MsgList.front();	
		this->m_nSimuTime=pMsg->m_TimeStamp;	
		m_MsgList.pop_front();
		handleSimuMsg(pMsg);
		delete pMsg;
		pMsg = nullptr;
	}	
	return m_MsgList.empty();
}

/************************************************************************/
/* �����������ʹ�ý����ͷ�ʱ����½����
/************************************************************************/
void jaDispatcher::construct_soft_solution(jaMOSSoln* pSoln)
{
	this->m_pSimuSoln = pSoln;
	if (!pSoln->soft_decisions.empty())
	{
		return ;
	}
	//0.��ʼ�������ͷ�ʱ��
	map<jaMachine*, int> ma_rlts;
	jaStage* pLastage = m_StageList.back();
	for (auto ma_pair : m_pProblem->getMachineMap())
	{
		jaMachine* pMach = ma_pair.second;
		if (pMach->getStage() != pLastage)
		{
			ma_rlts[pMach] = INT_MAX;
		}
		else {
			ma_rlts[pMach] = 0;
		}
	}
	//1.�������ȣ��������ȼ�����
	vector<jaBatch*> batch_list; int l = 0;
	int NH = m_pProblem->getBatchMap().size();
	for (auto batch_pair : m_pProblem->getBatchMap())
	{
		jaBatch* pBatch = batch_pair.second;
		pBatch->setSlackRatio(pSoln->m_code[NH + l]);
		pBatch->setPriority(pSoln->m_code[l++]);		
		pBatch->setReleaseTime(0);
		batch_list.push_back(pBatch);
	}
	std::sort(batch_list.begin(), batch_list.end(),  //���ȼ��ߵ�����
		[](jaBatch* a, jaBatch* b) {return a->getPriority() > b->getPriority(); });
	for (unsigned int l = 0; l < batch_list.size(); l++)
	{
		jaBatch* pBatch = batch_list[l];
		jaMachine* pSelMA = nullptr;
		int EAT = INT_MAX;
		for (auto ma_pair : pLastage->getMachineMap())
		{
			jaMachine* pMA = ma_pair.second;
			if (ma_rlts[pMA] < EAT)
			{
				EAT = ma_rlts[pMA]; pSelMA = pMA;
			}
		}
		EAT += pBatch->getSetupTime();
		pBatch->setReleaseTime(EAT); 
		pBatch->setAssignedMA(pSelMA);
		for (unsigned int r = 0; r < pBatch->getOperSequence().size(); r++)
		{

			jaOperation* pOper = pBatch->getOperSequence()[r];
			pOper->setStartTime(EAT);			
			jaOperation* pPrev = pOper->getPrevOper();
			pPrev->setLFinishTime(EAT -pPrev->getTransTime());
			int npt = pOper->getNoise()->getStdValue();
			EAT += npt;
			pOper->setFinishTime(EAT);
			//pSelMA->getProcessList().push_back(pOper); //test
		}
		ma_rlts[pSelMA] = EAT;
	}
	//2. ����&ת¯����
	int s0 = INT_MAX;
	int TC = 0;
	for (int i = m_StageList.size() - 2; i >= 0; i--)
	{
		jaStage* pStage = m_StageList[i];
		vector<jaOperation*> oper_list(pStage->getOperMap().size());
		int j = 0;
		for (auto op_pair : pStage->getOperMap())
		{
			oper_list[j++] = op_pair.second;
		}
		std::sort(oper_list.begin(), oper_list.end(),
			[](jaOperation* a, jaOperation* b) {return a->getLFinishTime() > b->getLFinishTime(); });
		int N = static_cast<int>(oper_list.size());
		for (int j = 0; j < N; j++)
		{
			jaMachine* pSelMA = nullptr;
			int LAT = INT_MIN;
			for (auto ma_pair : pStage->getMachineMap())
			{
				jaMachine* pMA = ma_pair.second;
				if (ma_rlts[pMA] > LAT)
				{
					LAT = ma_rlts[pMA]; pSelMA = pMA;
				}
			}
			jaOperation* pOper = oper_list[j];
			jaBatch* pBatch = pOper->getJob()->getBatch();
			int tmp_ft = pOper->getLFinishTime() - pBatch->getSlackRatio()*(pOper->getTransTime() + pOper->getNoise()->getStdValue());
			LAT = std::min(LAT,tmp_ft);
			pOper->setFinishTime(LAT);
			int npt = pOper->getNoise()->getStdValue();
			LAT -= npt;
			pOper->setStartTime(LAT);
			//pSelMA->getProcessList().push_front(pOper); //test

			jaOperation* pPrev = pOper->getPrevOper();
			if (pPrev != nullptr)
			{
				//jaBatch* pBatch = pOper->getJob()->getBatch();
				pPrev->setLFinishTime(LAT - pPrev->getTransTime());
			}
			else {
				int tc = std::max((m_RescList[N - j - 1]->getStoAT() - LAT), 0);
				if (tc > TC) TC = tc;
				if (LAT < s0)	s0 = LAT;				
			}
			ma_rlts[pSelMA] = LAT;
		}
	}
	
	//4. �Ҳ��ƶ�
	int nShift = std::max(std::abs(s0) , TC);
	for (auto op_pair : m_pProblem->getOperMap())
	{
		jaOperation* pOper = op_pair.second;
		m_pProblem->rightShift(pOper, nShift);
	}
	/*{
		jaStage* pFstage = m_StageList.front();
		vector<jaOperation*> oper_list(pFstage->getOperMap().size());
		int j = 0;
		for (auto op_pair : pFstage->getOperMap())
		{
			oper_list[j++] = op_pair.second;
		}
		std::sort(oper_list.begin(), oper_list.end(),
			[](jaOperation* a, jaOperation* b) {return a->getStartTime() < b->getStartTime(); });
		int xx = 0;
		for (int j = 0; j < oper_list.size(); j++)
		{
			xx += (std::min(oper_list[j]->getStartTime() - m_RescList[j]->getStoAT(), 0));
			xx = xx;
		}
	}*/

	for (auto pBah : batch_list)
	{
		tagSoftSoln* pSoft = new tagSoftSoln;
		//std::tuple<jaBatch*, double, int,double> sd = std::make_tuple(pBah, pBah->getSlackRatio(), pBah->getReleaseTime() + nShift,pBah->getSlackRatio());
		pSoft->pBatch = pBah;
		pSoft->priority = pBah->getPriority();
		pSoft->slack_ratio = pBah->getSlackRatio();
		pSoft->release_time = pBah->getReleaseTime()+nShift;
		pSoft->pDestMa = pBah->getAssignedMA();
		pSoln->soft_decisions.push_back(pSoft);
		//DbgPrint("%s release @ %d \n", pBah->getHandleID().c_str(), pSoft->release_time);
	}
	this->m_pSimuSoln = pSoln;
	return ;
}

/************************************************************************/
/* �����ͷŲ���
/************************************************************************/
void jaDispatcher::release_jobs(int batch_num)
{
	if (m_BatchList.size() < m_nBCursor + batch_num) //���������Ѿ��ͷ�
		return;
	//1.�����ͷ�ʱ��
	for (int i = m_nBCursor; i < m_nBCursor + batch_num;i++)
	{
		tagSoftSoln* pSoft = m_pSimuSoln->soft_decisions[i];
		jaBatch* pBatch = pSoft->pBatch;
		pBatch->setPriority(pSoft->priority);	
		pBatch->setSlackRatio(pSoft->slack_ratio);	
		pBatch->setAssignedMA(pSoft->pDestMa);

		{
			if (pSoft->pDestMa->getProcessList().size()==0)
			{
				pBatch->setReleaseTime(pSoft->release_time);
			}
			else {
				jaBatch* pOnBatch = pSoft->pDestMa->getProcessList().back()->getJob()->getBatch();
				pBatch->setReleaseTime(std::max(pSoft->release_time,pOnBatch->getFinishTime()+pBatch->getSetupTime()));
			}			
		}

		int tmp_rlt = pBatch->getReleaseTime();
		for (unsigned int j = 0; j < pBatch->getOperSequence().size(); j++)
		{
			jaOperation* pLOper = pBatch->getOperSequence()[j];
			int nStoPT = pLOper->getNoise()->getStoValue();			

			jaOperation* pFOper = pLOper->getPrevOper();
			int nPrevLoad = pFOper->getTransTime() + pFOper->getNoise()->getStdValue();
			while (pFOper->getPrevOper() != nullptr) {
				pFOper = pFOper->getPrevOper();
				nPrevLoad = nPrevLoad + pFOper->getTransTime() + pFOper->getNoise()->getStdValue();
			}
			pLOper->setPrevLoad(nPrevLoad);
			int nrlt = std::max(tmp_rlt - (int)((1.0+pBatch->getSlackRatio() )* pLOper->getPrevLoad()),0);
			pLOper->getJob()->setStatus(JOB_STATUS::JOB_WAITTING);
			pLOper->getJob()->setReleaseTime(nrlt);
						
			pFOper->setStatus(OPER_UNARRIVED);
			pFOper->setArriveTime(nrlt);
			this->sendSimuMsg(pFOper->getArriveTime(), nullptr, pFOper->getStage(), SIMULATION_MSG::MSG_OPER_ARRIVE, pFOper);
			
			tmp_rlt += nStoPT;
		}		
	}	
	this->m_nBCursor += batch_num;
}

void jaDispatcher::printMsgList()
{
	DbgPrint("-----------------------------------------------------\n");
	for (auto it=begin(m_MsgList);it!=end(m_MsgList);it++)
	{
		jaSimuMsg* pMsg=*it;
		//jaOperation* pOper=(jaOperation*)pMsg->m_pEntity;
		string str;
		if (pMsg->m_MsgType==SIMULATION_MSG::MSG_OPER_ARRIVE)
		{
			str = jaCommon::format("[%06d]  SEND MSG_OP_ARRIVE  @%s  ����",
				pMsg->m_TimeStamp, ((jaOperation*)pMsg->m_pSource)->getHandleID().c_str());
		}
		if (pMsg->m_MsgType == SIMULATION_MSG::MSG_MACH_RELEASE)
		{
			str = jaCommon::format("[%06d]  SEND MSG_MA_RELEASE  @%s  ����",
				pMsg->m_TimeStamp,((jaMachine*)pMsg->m_pSource)->getHandleID().c_str());
		}		 
		DbgPrint("msg=%s \n",str.c_str());
	}
}
/************************************************************************/
/* ������Ϣ����
/************************************************************************/
void jaDispatcher::handleSimuMsg( jaSimuMsg* pMsg )
{
	switch (pMsg->m_MsgType)
	{
	case SIMULATION_MSG::MSG_OPER_ARRIVE:
		this->handleOperArriveMsg((jaOperation*)pMsg->m_pSource);
		break;
	case SIMULATION_MSG::MSG_MACH_RELEASE:
		this->handleMachReleaseMsg((jaMachine*)pMsg->m_pSource);
		break;	
	default:
		break;
	}
}

void jaDispatcher::sendSimuMsg(int nSimuTime, jaStage* pSend, jaStage* pRecv, SIMULATION_MSG msg, void* pObj)
{
	jaSimuMsg* pMsg = new jaSimuMsg(nSimuTime, pSend, pRecv, msg, "", pObj, 0);
	this->insertMsg2List(pMsg);
	
}

/************************************************************************/
/* ˳����룬֮����Ըĳ��۰����
/************************************************************************/
void jaDispatcher::insertMsg2List( jaSimuMsg* pNewMsg,int flag/*=0*/ )
{
	for(auto it = begin(m_MsgList); it != end(m_MsgList); ++it) 
	{		
		jaSimuMsg* pOldMsg=*it;
		//1. �Ȱ�ʱ��
		if(pOldMsg->m_TimeStamp>pNewMsg->m_TimeStamp)
		{
			m_MsgList.insert(it,pNewMsg);
			return;
		}else if (pOldMsg->m_TimeStamp==pNewMsg->m_TimeStamp)
		{
			if (pOldMsg->m_pRecver->getSerialNo() < pOldMsg->m_pRecver->getSerialNo()) //����
			{
				m_MsgList.insert(it, pNewMsg);
				return;
			}
			else
			{
				if (pOldMsg->m_MsgType > pNewMsg->m_MsgType) //��Ϣ����
				{
					m_MsgList.insert(it, pNewMsg);
					return;
				}
			}
			
		}else
		{
			int error = 0;
		}			
	}	
	m_MsgList.push_back(pNewMsg);		
	return ;
}

bool jaDispatcher::handleOperArriveMsg(jaOperation* pOper)
{
	pOper->setStatus(OPERATION_STATUS::OPER_WAITTING);
	pOper->setArriveTime(m_nSimuTime);

	jaStage* pStage = pOper->getStage();
	pStage->insertOper(pOper);
	for (auto itma : pStage->getMachineMap())
	{
		jaMachine* pMach = itma.second;
		if (pMach->getStatus() == MACHINE_STATUS::MACH_LOCK)
		{
			pMach->setReleaseTime(m_nSimuTime);
			pMach->setStatus(MACHINE_STATUS::MACH_IDLE);
			sendSimuMsg(m_nSimuTime, pStage, pStage, SIMULATION_MSG::MSG_MACH_RELEASE, pMach);
		}
	}	
	return true;
}

bool jaDispatcher::handleMachReleaseMsg(jaMachine* pMach)
{
	//1.����������У���ѡ��������мӹ�
	if (pMach->getStatus() == MACHINE_STATUS::MACH_IDLE)
	{		
		jaOperation* pSelOper = this->select_operation(pMach);
		if (pSelOper == nullptr) //û��ѡ�����������ֿ��У����������ͷ���Ϣ
		{			
			if (pMach->getStage()->getWaittingList().size() == 0)
			{
				pMach->setStatus(MACHINE_STATUS::MACH_LOCK); //�����ر�
			}
			else
			{
				pMach->setStatus(MACHINE_STATUS::MACH_IDLE);
				this->sendSimuMsg(m_nSimuTime + 1, pMach->getStage(), pMach->getStage(), MSG_MACH_RELEASE, pMach);
			}
		}
		else //�ɹ�ѡ���򿪹������ͻ����ͷ���Ϣ
		{
			pMach->setStatus(MACHINE_STATUS::MACH_BUSY);
			this->start_operation(pSelOper, pMach);
			this->sendSimuMsg(pSelOper->getFinishTime(), pMach->getStage(), pMach->getStage(), MSG_MACH_RELEASE, pMach);
		}
	}
	else if (pMach->getStatus() == MACHINE_STATUS::MACH_BUSY)
	{
		jaOperation* pRelOper = this->release_operation(pMach);		
		if (pRelOper == nullptr) //���ܳɹ��ͷţ����������æµ�����������ͷ���Ϣ
		{
			pMach->setStatus(MACHINE_STATUS::MACH_BUSY);
			this->sendSimuMsg(m_nSimuTime + 1, pMach->getStage(), pMach->getStage(), MSG_MACH_RELEASE, pMach);
		}
		else //+1 or +0 ??
		{
			pMach->setStatus(MACHINE_STATUS::MACH_IDLE);
			this->finsih_operation(pRelOper, pMach); //��ѡ����			
			this->sendSimuMsg(pMach->getReleaseTime(), pMach->getStage(), pMach->getStage(), MSG_MACH_RELEASE, pMach);
		}
	}
	return true;
}

/************************************************************************/
/* Ҫ���ֹ���                                                                     */
/************************************************************************/
jaOperation* jaDispatcher::select_operation(jaMachine* pMach)
{
	jaBuffer* pBuff = (jaBuffer*)pMach->getStage();	
	if (pBuff->getWaittingList().size() == 0)
		return nullptr;
	jaOperation* pOper = nullptr;

	if (pMach->getStage() == m_pLStage)
	{		
		OP_BUFF::iterator iter = pBuff->getWaittingList().begin();
		for (; iter != pBuff->getWaittingList().end();iter++)
		{
			jaOperation* pTmpOper = *iter; 
			jaBatch* pBatch = pTmpOper->getJob()->getBatch();
			if (pBatch->getReleaseTime() > m_nSimuTime)
				continue;
			if (pBatch->getAssignedMA() == pMach)
			{
				pOper = pTmpOper;
				break;
			}
		}
		if (pOper!=nullptr)
		{
			pBuff->getWaittingList().erase(iter);
		}		
	}
	else { //FIFO RULE
		OP_BUFF::iterator iter = pBuff->getWaittingList().begin();
		pOper = *iter;
		pBuff->getWaittingList().erase(iter);
	}	
	return pOper;
}

/************************************************************************/
/* Ҫ���ֹ���                                                                     */
/************************************************************************/
jaOperation* jaDispatcher::release_operation(jaMachine* pMach)
{
	if (pMach->getStatus() == MACHINE_STATUS::MACH_IDLE)
		return nullptr;
	jaOperation* pOper = *pMach->getProcessList().rbegin();
	jaOperation* pNext = pOper->getNextOper();
	if (pNext == nullptr) //���һ������ֱ���ͷ�
		return pOper;
	//1.��黺�����ͷ�����
	/*jaStage* pNextStage = pNext->getStage();
	if (pNextStage->getWaittingList().size() >= pNextStage->getBufferSize())
	{
		return nullptr;
	}*/
	return pOper;
}



void jaDispatcher::start_operation(jaOperation* pOper, jaMachine* pMach)
{
	pOper->setMachine(pMach);	
	pOper->setStartTime(m_nSimuTime);
	pOper->setProcessTime(pOper->getNoise()->getStoValue()); //���û���Ŷ��� sto=std
	pOper->setFinishTime(m_nSimuTime+pOper->getNoise()->getStoValue());
	pOper->setStatus(OPERATION_STATUS::OPER_PROCESSING);

	pMach->setWorkingTime(m_nSimuTime);
	pMach->setStatus(MACH_BUSY);
	pMach->getProcessList().push_back(pOper);

	if (!pOper->getPrevOper()) //ǰ��������
	{
		jaJob* pJob = pOper->getJob();
		pJob->setStartTime(m_nSimuTime);
	}

	if (pOper->getStage()==m_pLStage ) //��������
	{
		jaBatch* pBatch = pOper->getJob()->getBatch();
		int ft = 0;
		for (unsigned i = 0; i < pBatch->getOperSequence().size();i++)
		{
			jaOperation* tmp_oper = pBatch->getOperSequence()[i];
			if (i == 0)
				pBatch->setStartTime(tmp_oper->getStartTime());
			if (tmp_oper->getStatus()>OPER_WAITTING)
			{
				ft = tmp_oper->getFinishTime();
			}
			else {
				ft += tmp_oper->getNoise()->getStoValue();
			}
		}
		pBatch->setFinishTime(ft);
	}
	
	return;
}

void jaDispatcher::finsih_operation(jaOperation* pOper, jaMachine* pMach)
{
	pMach->setReleaseTime(m_nSimuTime);
	pMach->setStatus(MACH_IDLE);

	pOper->setLeaveTime(m_nSimuTime);
	pOper->setStatus(OPERATION_STATUS::OPER_COMPLETED);

	jaOperation* pNext = pOper->getNextOper();
	if (pNext == nullptr) //����������
	{
		jaJob* pJob = pOper->getJob();
		pJob->setFinishTime(m_nSimuTime);
	}
	else
	{
		this->sendSimuMsg(m_nSimuTime + pOper->getTransTime(), pOper->getStage(), pNext->getStage(), SIMULATION_MSG::MSG_OPER_ARRIVE, pNext);
	}

	jaBatch* pBatch = pOper->getJob()->getBatch();
	if (pOper->getStage()==m_pFStage)
	{
		jaOperation* pLOper = pOper;
		while (pLOper->getNextOper()!=nullptr)
		{
			pLOper = pLOper->getNextOper();
		}
		if (pLOper == pBatch->getOperSequence().back())
		{
			this->release_jobs(1); //�ͷ���һ������
		}
	}
	return;
}

//���µ�ǰ���ε��깤ʱ��
void jaDispatcher::update_batch_CT(jaOperation* pOper)
{

}

/************************************************************************/
/* ѡ�񹤼���Դ
/************************************************************************/
bool jaDispatcher::select_resource(jaOperation* pOper)
{
	if (pOper->getPrevOper()!=nullptr) //���׵����򣬷���
	{
		return false;
	}
	jaResource* pResc = this->m_RescList[m_nJCursor];
	if (pOper->getJob()->getReleaseTime()<pResc->getStdAT())
	{
		return false;
	}
	return true;
}

std::tuple<double, double, double> jaDispatcher::calcSimuObj()
{
	tuple<double,double,double> objs;
	std::get<0>(objs)=0.0;
	std::get<1>(objs)=0.0;
	std::get<2>(objs)=0.0;
	map<string,jaBatch*>::iterator iter=m_pProblem->getBatchMap().begin();
	while(iter!=m_pProblem->getBatchMap().end())
	{
		jaBatch* pBatch=iter->second;
		int nWT=0;		
		for (unsigned int r=0;r<pBatch->getOperSequence().size();r++)
		{
			jaOperation* pOper1=pBatch->getOperSequence()[r];
			if(r<pBatch->getOperSequence().size()-1)
			{
				jaOperation* pOper2=pBatch->getOperSequence()[r+1];
				int nx=pOper2->getStartTime()-pOper1->getFinishTime();
				if(nx>0){
					std::get<1>(objs)+=nx*MOSS_COE_BK;					
				}
			}
			//DbgPrint("nCT=%d \n",nCT);
			jaOperation* pPrev=pOper1->getPrevOper();
			while(pPrev!=nullptr)
			{
				//int xxx=pOper1->getStartTime()-pPrev->getFinishTime()-pPrev->getTransTime();
				//DbgPrint("xxx=%d \n",xxx);
				int xWT = pOper1->getStartTime() - pPrev->getFinishTime() - pPrev->getTransTime();
				std::get<2>(objs)+= std::max(xWT - MAX_QT, 0.0);
				nWT += xWT;
				pOper1=pPrev;
				pPrev=pOper1->getPrevOper();
			}
			nWT += (pOper1->getStartTime() - pOper1->getArriveTime());
		}
		std::get<0>(objs)+=nWT*MOSS_COE_WT;
		iter++;
	}			
	int n=m_pProblem->getJobMap().size()-m_pProblem->getBatchMap().size();

	return objs;
}



