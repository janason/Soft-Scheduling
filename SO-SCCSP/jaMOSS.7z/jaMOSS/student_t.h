#pragma once

#include <boost/math/distributions/students_t.hpp>

using boost::math::students_t;

inline double get_quantile(unsigned Sn, double alpha)
{	
	students_t dist(Sn - 1);
	double T = quantile(complement(dist, alpha));
	return T;
}
