#include "jaMOSS.h"
#include "student_t.h"
#include "stat_func.h"
#include "kd_ucb.h"

jaMOSS::jaMOSS(string algo_name) :jaAlogrithm(algo_name)
{
	
	
}

jaMOSS::~jaMOSS()
{

}

bool jaMOSS::initialize()
{	
	//temp set noise
	for (auto pair: m_pProblem->getOperMap())
	{
		jaOperation* pOper = pair.second;
		if (pOper->getStage()->getSerialNo()==1)
		{
			pOper->getNoise()->setNoiseLevel(0.1);
		}
		if (pOper->getStage()->getSerialNo() == 1)
		{
			pOper->getNoise()->setNoiseLevel(0.2);
		}
		if (pOper->getStage()->getSerialNo() == 1)
		{
			pOper->getNoise()->setNoiseLevel(0.03);
		}
	}

	//0. ��ʼ��������¯�ε�˳��
	for (auto bah_pair:m_pProblem->getBatchMap())
	{
		jaBatch* pBatch = bah_pair.second;
		for (auto op_pair:pBatch->getOperMap())
		{
			pBatch->getOperSequence().push_back(op_pair.second);
		}
	}
	//1. ��ʼ���㷨����
	int NH = (int)this->m_pProblem->getBatchMap().size()*2 ;
	POP_SIZE =  NH * POP_UNIT;	
	this->T_BUDGET = AVG_REPC *POP_SIZE;

	this->ideal_point = make_tuple(1.0e6, 1.0e6, 1.0e6);
	this->ndir_point = make_tuple(-1.0e6, -1.0e6, -1.0e6);
	
	//2. ��ʼ����������һ��ƽ���������棬����ʽ����Ⱥ����������û������
	this->m_pScher = new jaDispatcher(m_pProblem);
	for (unsigned i = 0; i < POP_SIZE;i++)
	{
		jaMOSSoln* pSoln = new jaMOSSoln(INIT_KE);
		for (int r = 0; r < NH/2;r++)
		{			
			pSoln->m_code.push_back(CRORandDouble());
		}
		for (int r = 0; r < NH/2; r++)
		{
			pSoln->m_code.push_back(CRORandDouble()*0.5);
		}	
		pSoln->KE = INIT_KE;
		pSoln->cur_repc = AVG_REPC;
		this->round_simulation(pSoln);		
		this->update_ideal_point(pSoln);
		this->m_population.push_back(pSoln);

		DbgPrint("[%d] num=%d, PE=%.4f, mean1=%.2f, mean2=%.2f,mean3=%.2f \n", i
			, pSoln->num_repc, pSoln->PE, pSoln->means[0], pSoln->means[1], pSoln->means[2]);
	}

	//3. ����ο����Ȩ��������
	this->update_weights_point();
	//4. ��ʼ������ϵͳ
	double max_PE = INT_MIN;
	double min_PE = INT_MAX;
	for (unsigned i = 0; i <POP_SIZE; i++)
	{
		jaMOSSoln* pSoln = m_population[i];
		for (int k = 0; k < pSoln->num_repc;k++)
		{
			this->calc_asf_value(pSoln, k);
		}
		this->estimate_asf_value(pSoln);		
		DbgPrint("[%d] num=%d, PE=%.4f, mean1=%.2f, mean2=%.2f,mean3=%.2f \n", i
			, pSoln->num_repc, pSoln->PE, pSoln->means[0], pSoln->means[1], pSoln->means[2]);
		if (pSoln->PE > max_PE) max_PE = pSoln->PE;		
		if (pSoln->PE < min_PE) min_PE = pSoln->PE;
	}
	//5.��������������ʼ��CRO�㷨����
	INIT_KE = (max_PE - min_PE); //adptive
	this->total_energy = 0.0;
	for (unsigned i = 0; i < POP_SIZE; i++)
	{
		jaMOSSoln* pSoln = m_population[i];
		pSoln->KE = INIT_KE;
		this->total_energy = this->total_energy + pSoln->PE + INIT_KE;
	}
	LOSS_RATE = 0.2; //N(0,0.3)���������0~1֮��
	//this->DEC_THRES = 1000; //0.5
	//this->SYN_THRES = 10; //0.5	
	//this->COLL_RATE = 0.2;
	
	
	this->curFE = POP_SIZE;  //��¼��ײ����
	this->FE_LIMIT = POP_SIZE*100;
	return true;
}

bool jaMOSS::reset()
{
	return true;
}

/************************************************************************/
/* �ڱ�׼CRO�����Ͻ��иĽ�
/* 1. �ڸ�����Ⱥ P �Ͻ��в���������ͬ���������Ӵ���Ⱥ Q
/* 2. ��P+Q �Ͻ������� �²���ִ��n0�η��棬�������UCB�������з���
/* 3. �����۽�����أ����������غ��Ƿ����P+Q
/* 4. ��Ŀ�����򣬽���ѡ�� e-domination ������һ�� NDS
/* 5. ת1. 
/************************************************************************/
bool jaMOSS::run()
{	
	vector<jaMOSSoln*> Q_POP; //�Ӵ���Ⱥ
	vector<jaMOSSoln*> P_POP; //������Ⱥ	
	int IT = 0;
	const time_t start = time(NULL);
	while (1) //�����ײ�����
	{
		IT++;
		//1. copy m_population to  P_POP;generate Q_POP from P_POP,		
		this->CRO_Variation(P_POP, Q_POP);
		//2. evaluation,SAA		
		for (unsigned k=0; k<Q_POP.size(); k++)
		{
			jaMOSSoln* pSoln = Q_POP[k];
			pSoln->cur_repc = AVG_REPC; //ƽ�����䣬��ʱ
			this->round_simulation(pSoln);
			pSoln->statistics();
		/*	DbgPrint("[%d,%d] num=%d, PE=%.4f, mean1=%.2f, mean2=%.2f,mean3=%.2f \n", IT,k+1
				, pSoln->num_repc, pSoln->PE, pSoln->means[0], pSoln->means[1], pSoln->means[2]);*/
		}
		for (unsigned i = 0; i < Q_POP.size(); i++)
		{
			jaMOSSoln* pSoln = Q_POP[i];			
			this->estimate_asf_value(pSoln);			 
			/*DbgPrint("[%d] num=%d, PE=%.4f, mean1=%.2f, mean2=%.2f,mean3=%.2f \n",i
				, pSoln->num_repc,pSoln->PE, pSoln->means[0], pSoln->means[1], pSoln->means[2]);*/
		}				
		//3. Update population
   		this->CRO_Update(P_POP,Q_POP);				
		for (int i = 0; i < Q_POP.size();i++)
		{
			m_population.push_back(Q_POP[i]);
		}
		Q_POP.clear();		
		//4. Select N best solutions
		std::sort(begin(m_population), end(m_population), [](jaMOSSoln* a, jaMOSSoln* b)
		{
			return a->PE < b->PE;
		});
		if (m_population.size() > POP_SIZE)
		{			
			auto it = m_population.begin() + POP_SIZE;
			while (it != m_population.end())
			{
				it = m_population.erase(it);
			}
		}
		//local search
		for (int i = 0; i < LOSS_RATE*POP_SIZE; i++)
		{
			jaMOSSoln* pOldSoln = m_population[i];		
			jaMOSSoln* pNewSoln = this->local_search(pOldSoln);
			if (pOldSoln->PE>pNewSoln->PE)
			{
				delete pOldSoln;
				pOldSoln = nullptr;
				m_population[i] = pNewSoln;
			}else{
				delete pNewSoln;
				pNewSoln = nullptr;
			}
		}
		//5. Update total energy
		this->total_energy = 0.0;
		for (auto it:m_population)
		{
			total_energy = total_energy + it->PE + it->KE;
		}
		this->m_pOptSoln = m_population.front();
		DbgPrint("#[%d] best ASF=%.4f \n",IT,m_pOptSoln->PE);
		const time_t end = time(NULL);
		if (end-start>=90)
			break;		
	}	
	DbgPrint("---------------{ Clean UP}-----------------\n");
	for (unsigned i = 0; i < m_population.size(); i++)
	{
		jaMOSSoln* pSoln = m_population[i];
		for (int k = 0; k<pSoln->num_repc;k++)
		{
			calc_asf_value(pSoln, k);
		}
		pSoln->cur_repc = 0;
	}
	this->clean_up(m_population);
	for (unsigned i = 0; i < m_population.size(); i++)
	{
		jaMOSSoln* pSoln = m_population[i];
		this->round_simulation(pSoln);
		pSoln->statistics();
	}
	for (unsigned i = 0; i < m_population.size(); i++)
	{
		this->estimate_asf_value(m_population[i]);
	}
	std::sort(begin(m_population), end(m_population), [](jaMOSSoln* a, jaMOSSoln* b)
	{
		return a->PE < b->PE;
	});
	this->m_pOptSoln = m_population.front();	
	if (m_pOptSoln->num_repc<1000)
	{
		m_pOptSoln->cur_repc = 1000 - m_pOptSoln->num_repc;
		this->round_simulation(m_pOptSoln);
		this->estimate_asf_value(m_pOptSoln);
	}
	DbgPrint("#[%d] best ASF=%.4f recs=%d \n", IT, m_pOptSoln->PE, m_pOptSoln->num_repc);
	DbgPrint("#[%d] best output [%.2f %.2f %.2f %.2f %.2f %.2f] \n", 0,
		m_pOptSoln->means[0], sqrt(m_pOptSoln->vars[0]),
		m_pOptSoln->means[1], sqrt(m_pOptSoln->vars[1]),
		m_pOptSoln->means[2], sqrt(m_pOptSoln->vars[2]));
	DbgPrint("[%d] Algorithm is over............\n", curFE);
	return true;
}


void jaMOSS::CRO_Variation(vector<jaMOSSoln*>& P_POP, vector<jaMOSSoln*>& Q_POP)
{
	P_POP = m_population;	
	Q_POP.clear();
	double change_rate=0.5;	
	while (!P_POP.empty()) {
		double change_pop = Q_POP.size()*1.0 / m_population.size();
		double change_dec = (1.0 - change_pop) / 2;
		double change_syn = 1.0 - change_dec;
		double rand = CRORandDouble();
		if (( rand< COLL_RATE) || (P_POP.size() == 1))
		{			
			int pos1 = CRORandInt((int)P_POP.size());	
			auto itP = P_POP.begin() + pos1;
			jaMOSSoln* p =*itP;
			//if (p->isDecp(DEC_THRES))// old
			if (CRORandDouble()<change_dec) 
			{
				jaMOSSoln* q1 = new jaMOSSoln(INIT_KE);
				jaMOSSoln* q2 = new jaMOSSoln(INIT_KE);
				p->dec_reaction(p,q1,q2);	
				this->curFE += 2;
				Q_POP.push_back(q1);
				Q_POP.push_back(q2);
			} // On-wall.
			else 
			{
				jaMOSSoln* q = new jaMOSSoln(INIT_KE);
				p->wall_reaction(p, q);				
				this->curFE += 2;
				Q_POP.push_back(q);
			}
			P_POP.erase(itP);
		}
		else 
		{// Synthesis.			
			int pos1 = CRORandInt((int)P_POP.size());
			int pos2 = pos1;
			while (pos1 == pos2) 
			{
				pos2 = CRORandInt((int)P_POP.size());
			}
			jaMOSSoln* p1; 
			jaMOSSoln* p2;
			if (P_POP.size() == 2) 
			{
				p1 = P_POP[0];
				p2 = P_POP[1];
			}
			else {
				p1 = P_POP[pos1];
				p2 = P_POP[pos2];
			}
			//if (p1->isSync(SYN_THRES) && p2->isSync(SYN_THRES)) 
			if(CRORandDouble()<change_syn)
			{
				jaMOSSoln* q = new jaMOSSoln(INIT_KE);
				if (p1->syn_reaction(p1,p2,q)) {					
					Q_POP.push_back(q);
				}
				this->curFE += 2;				
			}
			else {
				jaMOSSoln* q1 = new jaMOSSoln(INIT_KE);
				jaMOSSoln* q2 = new jaMOSSoln(INIT_KE);
				p1->inter_reaction(p1, p2, q1, q2);
				Q_POP.push_back(q1);
				Q_POP.push_back(q2);				
				this->curFE++;
			}
			P_POP.erase(P_POP.begin() + pos1);
			if(pos2<pos1)
				P_POP.erase(P_POP.begin() + pos2);
			else
				P_POP.erase(P_POP.begin() + pos2-1);
		}	
	}	
}

/************************************************************************/
/* �����Ӵ���Ⱥ
/************************************************************************/
void jaMOSS::CRO_Update(vector<jaMOSSoln*>& P_POP, vector<jaMOSSoln*>& Q_POP)
{
	auto it = begin(Q_POP);
	while (it != end(Q_POP))
	{
		jaMOSSoln* pCurrSoln = *it;
		REACTION_TYPE rtype = pCurrSoln->getReactionType();
		switch (rtype)
		{
		case WALL:
		{
			if (this->wall_update(pCurrSoln))
			{
				this->remove_soln(pCurrSoln->getParent().first, P_POP);
				++it;
			}
			else {
				it = Q_POP.erase(it);
			}
			break;
		}
		case DEC:
		{
			jaMOSSoln* pNextSoln = *(it+1);
			if (this->dec_update(pCurrSoln, pNextSoln))
			{
				this->remove_soln(pCurrSoln->getParent().first, P_POP);
				it=it+2;
			}
			else {				
				it = Q_POP.erase(it);
				it = Q_POP.erase(it);
			}
			break;
		}
		case INTER:
		{
			jaMOSSoln* pNextSoln = *(it + 1);
			if (this->inter_update(pCurrSoln, pNextSoln))
			{
				this->remove_soln(pCurrSoln->getParent().first, P_POP);
				this->remove_soln(pCurrSoln->getParent().second, P_POP);
				it = it + 2;
			}
			else {
				it=Q_POP.erase(it);
				it = Q_POP.erase(it);
			}
			break;
		}
		case SYNC:
		{
			if (this->syn_update(pCurrSoln))
			{
				this->remove_soln(pCurrSoln->getParent().first, P_POP);
				++it;
			}
			else {				
				it = Q_POP.erase(it);
			}
			break;
		}
		default:
		{
			break;
		}
		}
	}
}   

/************************************************************************/
/* Knowledge-based Local Search
/************************************************************************/
jaMOSSoln*  jaMOSS::local_search(jaMOSSoln* pSoln)
{	

	jaMOSSoln* pCurSoln = new jaMOSSoln(INIT_KE);
	pCurSoln->clone(pSoln);

	double T = get_quantile(pCurSoln->num_repc, 1 - BETA);
	double v0 = (pCurSoln->means[0] - T*std::sqrt(pCurSoln->vars[0] / pCurSoln->num_repc)
		- std::get<0>(ref_point))*WEIGHTS[0];
	double v1 = (pCurSoln->means[1] - T*std::sqrt(pCurSoln->vars[1] / pCurSoln->num_repc)
		- std::get<1>(ref_point))*WEIGHTS[1];
	double v2 = (pCurSoln->means[2] - T*std::sqrt(pCurSoln->vars[2] / pCurSoln->num_repc)
		- std::get<2>(ref_point))*WEIGHTS[2];
	int NN = 0;
	if (v1 > max(v0, v2)) NN = 0; //wt���
	else if (v2 > max(v0, v1)) NN = 1; //wt��С
	else NN = 2; 
	
	int it_max = LOCAL_COUNT;
	int N = pCurSoln->m_code.size() / 2;	
	for (int it = 0; it < it_max;it++)
	{			
		double max_v = std::max(v0, std::max(v1, v2));
		jaMOSSoln* pTmpSoln = new jaMOSSoln(INIT_KE);
		pTmpSoln->m_code= pCurSoln->m_code;
		if (NN==0) //wr���
		{
			int n = N + CRORandInt(N);
			double tmp = pTmpSoln->m_code[n];
			tmp = (1.0-tmp)*CRORandDouble()+tmp;
			pTmpSoln->m_code[n] = tmp;			
		} else if (NN==1) //wr��С
		{
			int n = N + CRORandInt(N);
			double tmp = pTmpSoln->m_code[n];
			tmp = tmp*CRORandDouble();
			pTmpSoln->m_code[n] = tmp;
		}else { // swap
			int n1 = CRORandInt(N);
			int n2 = CRORandInt(N);
			while(n1==n2)
				n2 = CRORandInt(N);
			double tmp = pTmpSoln->m_code[n1];
			pTmpSoln->m_code[n1] = pTmpSoln->m_code[n2];
			pTmpSoln->m_code[n1] = tmp;
		}
		pTmpSoln->cur_repc = AVG_REPC; //ƽ�����䣬��ʱ
		this->round_simulation(pTmpSoln);  
		pTmpSoln->statistics();
		this->estimate_asf_value(pTmpSoln);
		if (pTmpSoln->PE<pCurSoln->PE)
		{
			delete pCurSoln;
			pCurSoln = pTmpSoln;
			//DbgPrint("local search... \n");
		}
		else {
			delete pTmpSoln;
		}
	}
	return pCurSoln;
}

int jaMOSS::select_arm_ucb1(vector<jaMOSSoln*>& POP, int trail_num)
{
	double rau_max=0.0;
	int sel_arm = 0;
	for (unsigned i = 0; i < POP.size();i++)
	{
		jaMOSSoln* pSoln = POP[i];
		double mean = jaCommon::avg(pSoln->asf_vals, pSoln->num_repc);
		double var = jaCommon::var(pSoln->asf_vals, pSoln->num_repc);
		double reward = std::sqrt(var) / mean;
		double rau = reward + 2 * std::sqrt(trail_num / pSoln->num_repc);
		if (rau>sel_arm)
		{
			rau_max = rau;
			sel_arm = i;
		}
	}
	return sel_arm;
}

int jaMOSS::select_arm_pucb(vector<jaMOSSoln*>& POP, int trail_num)
{
	double rewards(POP.size());
	vector<tuple<int, double, double, double>> CS; //candidate set
	int T =trail_num+ AVG_REPC;
	int D = OBJ_DIM;
	for (unsigned int i = 0; i < POP.size(); i++)
	{
		jaMOSSoln* pSoln = POP[i];
		tuple<double, double, double> reward;
		
		//double mu1 = jaCommon::avg(std::get<0>(pSoln->objs), pSoln->num_repc);
		pSoln->statistics();
		//����ʵ������
		double r0 = 2 * 1.65*sqrt(pSoln->vars[0] / pSoln->num_repc) /pSoln->means[0]  + pow(std::sqrt(2 * log(T*pow(D, 0.25)) / pSoln->num_repc), D);
		double r1 = 2 * 1.65*sqrt(pSoln->vars[1] / pSoln->num_repc) /pSoln->means[1]  + pow(std::sqrt(2 * log(T*pow(D, 0.25)) / pSoln->num_repc), D);
		double r2 = 2 * 1.65*sqrt(pSoln->vars[2] / pSoln->num_repc) /pSoln->means[2]  + pow(std::sqrt(2 * log(T*pow(D, 0.25)) / pSoln->num_repc), D);
		
		// ����Pareto����
		if (CS.size() == 0) {
			CS.push_back(make_tuple(i, r0, r1, r2));
			continue;
		}
		// ɾ����֧���
		for (auto it = begin(CS); it != end(CS); )
		{
			auto r = *it;
			if (std::get<1>(r) <= r0 && std::get<2>(r) <= r1 &&
				std::get<3>(r) <= r2) //  (r1,r2,r3) ���� r 
			{
				it = CS.erase(it);
			}else 
			{         
				 it++;
			}		
		}
		//�ж��Ƿ���Լ���	
		bool isAdd = true;
		for (auto it = begin(CS); it != end(CS); it++) 
		{
			auto r = *it;
			if (std::get<1>(r) >= r0 && std::get<2>(r) >= r1 &&
				std::get<3>(r) >= r2)  //֧�� new x 
			{
				isAdd = false;
				break;
			}
		}
		if (isAdd)	CS.push_back(make_tuple(i, r0, r1, r2));
		
	}
	//asf ��С�ķ���
	double min_asf = INT_MAX;
	int sel_idx = 0;
	for (unsigned n = 0; n < CS.size(); n++)
	{
		int id = std::get<0>(CS[0]);
		jaMOSSoln* pSoln = POP[id];
		double v0 = (pSoln->means[0]
			- std::get<0>(ref_point))*WEIGHTS[0];
		double v1 = (pSoln->means[1]
			- std::get<1>(ref_point))*WEIGHTS[1];
		double v2 = (pSoln->means[2]
			- std::get<1>(ref_point))*WEIGHTS[2];
		double asf = std::max(v0, std::max(v1, v2)) + SCALARIZING*(v0 + v1 + v2);
		
		if (asf<min_asf)
		{
			min_asf = asf;
			sel_idx = id;
		}
	}
	return sel_idx;
}



int jaMOSS::clean_up(vector<jaMOSSoln*>& POP)
{
	size_t k = POP.size();
	int* num = new int[k];
	double *x = new double[k];
	double *S2 = new double[k];
	double *t = new double[k];
	double *w = new double[k * k];
	for (size_t i = 0; i < k; i++)
	{
		jaMOSSoln* pSoln = POP[i];
		num[i] =pSoln->num_repc;
		// Note that NSGS is for maximization, so need to negate objective values here!!!
		x[i] = jaCommon::avg(pSoln->asf_vals,num[i]);
		S2[i] = jaCommon::var(pSoln->asf_vals, num[i]);
	}
	// Step 1
	double alpha = 0.1;
	int n = num[0];
	double plevel = pow(1 - alpha / 2, 1 / max(1.0, (double)(k - 1)));
	//cout << "Rinott computation, 1-alpha/2 = " << 1-alpha/2 << " pow " << 1/max(1, (double)(k-1)) << endl;
	//cout << "n= " << n << ", " << "p= " << plevel << " alpha= " << alpha << endl;
	//Rinott(systems under comparison, CI level, d.f.)
	double h = Rinott(2, plevel, n); //??
	//cout << "Rinott " << h << endl;
	for (size_t i = 0; i < k; i++)
	{
		// Note that there should be at least 2 observation, if there is only 1, then variance must be 0
		// and this t[i] value has no significance. But tinv() is not well defined for 0 as the 2nd arg.
		// So set it as below
		t[i] = tinv(plevel, (1 <= num[i] - 1) ? num[i] - 1 : 1);
	}
	for (size_t i = 0; i < k; i++)
	{
		for (size_t l = 0; l < k; l++)
		{
			if (i == l)
			{
				w[i*k + l] = 0;
			}
			else
			{
				w[i*k + l] = sqrt(t[i] * t[i] * S2[i] / num[i] + t[l] * t[l] * S2[l] / num[l]);
			}
		}
	}
	// Step 2: Get set I.
	// Note that I has indexes in M, not visited!!!
	vector<long> I;
	for (size_t i = 0; i < k; i++)
	{
		bool recordi = true;
		for (size_t l = 0; l < k; l++)
		{
			if (i != l && x[l] - w[i*k + l] > x[i])
			{
				recordi = false;
				break;
			}
		}
		if (recordi) I.push_back(long(i));
	}
	
	// Step 3: for all i in I, compute new number of samples and collect more observations
	double delta = 1.0/sqrt(n);
	size_t kI = I.size();
	double* xI = new double[kI];
	if (kI == 0)
	{
		cout << "Clean-up error: Empty I" << endl;
		return -1;
	}
	double addreps = 0;
	for (size_t i = 0; i < kI; i++)
	{
		int newni = (int)ceil(h*h*S2[I[i]] / delta / delta);
		// I[i] is the index in M.
		int ix = I[i];
		int N = (num[ix] < newni) ? newni : num[ix];
		double add = N - num[ix];
		
		if (add > 990) add = 990;

		jaMOSSoln* pSoln = POP[ix];
		pSoln->cur_repc = add;

		addreps += add;
		DbgPrint("[%d] add reps=%.2f \n",I[i],add);
	}
	DbgPrint("Cleanup used %.2f reps \n", addreps);
	// Step 4: Find the best. Note bestIndex is the index in vector I, not in M! not in visited!
//	int bestindex = maximum(xI, int(kI));
	delete[]num;
	delete[]x;
	delete[]S2;
	delete[]t;
	delete[]w;
	delete[]xI;

	return 0;
}

/************************************************************************/
/* ideal  ��λ��Ϊ  t(0.6,19), ndir ��λ��Ϊ t(0.99,19)
/************************************************************************/
void jaMOSS::update_ideal_point(jaMOSSoln* pSoln)
{		
	//confidence_limits_on_mean(pSoln->means[0], pSoln->vars[0],pSoln->num_repc);
	double T1 = get_quantile(pSoln->num_repc, 1-0.99);
	pSoln->statistics();
	double ideal_0 = pSoln->means[0] - T1*std::sqrt(pSoln->vars[0] / pSoln->num_repc);
	double ideal_1 = pSoln->means[1] - T1*std::sqrt(pSoln->vars[1] / pSoln->num_repc);
	double ideal_2 = pSoln->means[2] - T1*std::sqrt(pSoln->vars[2] / pSoln->num_repc);
	if (ideal_0 < std::get<0>(ideal_point))
	{
		std::get<0>(ideal_point) = ideal_0;
	}
	if (ideal_1 < std::get<1>(ideal_point))
	{
		std::get<1>(ideal_point) = ideal_1;
	}
	if (ideal_2 < std::get<2>(ideal_point))
	{
		std::get<2>(ideal_point) = ideal_2;
	}

	double T2 = get_quantile(pSoln->num_repc,1-0.9);
	double ndir_0 = pSoln->means[0] - T2*std::sqrt(pSoln->vars[0] / pSoln->num_repc);
	double ndir_1 = pSoln->means[1] - T2*std::sqrt(pSoln->vars[1] / pSoln->num_repc);
	double ndir_2 = pSoln->means[2] - T2*std::sqrt(pSoln->vars[2] / pSoln->num_repc);
	if (ndir_0 > std::get<0>(ndir_point))
	{
		std::get<0>(ndir_point) = ndir_0;
	}
	if (ndir_1 > std::get<1>(ndir_point))
	{
		std::get<1>(ndir_point) = ndir_1;
	}
	if (ndir_2> std::get<2>(ndir_point))
	{
		std::get<2>(ndir_point) = ndir_2;
	}
	
}

/************************************************************************/
/* Incorporating preference information in interactive reference point
/* methods for multi-objective optimization
/************************************************************************/
void jaMOSS::update_weights_point()
{
	//m_weights.resize(3,0.001);
	WEIGHTS[0] = 1.0 / (std::get<0>(ndir_point) - std::get<0>(ideal_point));
	WEIGHTS[1] = 1.0 / (std::get<1>(ndir_point) - std::get<1>(ideal_point));
	if(std::get<2>(ndir_point) - std::get<2>(ideal_point)!=0)
		WEIGHTS[2] = 1.0 / (std::get<2>(ndir_point) - std::get<2>(ideal_point));
	//�ο������ʹ��ѧϰ�ķ����õ���RBF������Ŀǰ���þ�ֵ
	ref_point = make_tuple(0.0, 0.0, 0.0);	
	for (int i = 0; i<(int)m_population.size();i++)
	{
		jaMOSSoln* pSoln = m_population[i];
		pSoln->statistics();
		std::get<0>(ref_point) += (pSoln->means[0] - 1.65*sqrt(pSoln->vars[0]));
		std::get<1>(ref_point) += (pSoln->means[1] - 1.65*sqrt(pSoln->vars[1]));
		std::get<2>(ref_point) += (pSoln->means[2] - 1.65*sqrt(pSoln->vars[2]));
	}
	std::get<0>(ref_point) = std::get<0>(ref_point) / m_population.size() ;
	std::get<1>(ref_point) = 0.0;
	std::get<2>(ref_point) = 0.0;
	return;
}

double jaMOSS::round_simulation(jaMOSSoln* pSoln)
{
	//if (pSoln->soft_decisions.empty()) //���û�о�ս�����
	this->m_pScher->construct_soft_solution(pSoln);	
	
	for (int i = 0; i < pSoln->cur_repc; i++)
	{
		m_pProblem->sampling(nullptr);
		m_pScher->initialize();
		m_pScher->runSimu();
		std::tuple<double, double, double> objx = m_pScher->calcSimuObj();
		pSoln->objs[0][pSoln->num_repc] = std::get<0>(objx);
		pSoln->objs[1][pSoln->num_repc] = std::get<1>(objx);
		pSoln->objs[2][pSoln->num_repc] = std::get<2>(objx);
		pSoln->num_repc++;		
	}		
	return 0.0;
}

/************************************************************************/
/* ���� achievement scalarizing function ����ֵ, ����Ŀ�꺯��,��ǰ�����ĵ�
/************************************************************************/
double jaMOSS::estimate_asf_value(jaMOSSoln* pSoln)
{	
	double T = get_quantile(pSoln->num_repc, 1 - BETA);
	double v0 = (pSoln->means[0] -T*std::sqrt(pSoln->vars[0] / pSoln->num_repc) 
		- std::get<0>(ref_point))*WEIGHTS[0];
	double v1 = (pSoln->means[1] - T*std::sqrt(pSoln->vars[1] / pSoln->num_repc)
		- std::get<1>(ref_point))*WEIGHTS[1];
	double v2 = (pSoln->means[2] - T*std::sqrt(pSoln->vars[2] / pSoln->num_repc)
		- std::get<2>(ref_point))*WEIGHTS[2];
	double max_v = std::max(v0, std::max(v1, v2));
	double sum_v = SCALARIZING*(v0 + v1 + v2);
	pSoln->ASF_value = max_v + sum_v;
	pSoln->PE = pSoln->ASF_value;
	return pSoln->ASF_value;
}
/************************************************************************/
/* 
/************************************************************************/
double jaMOSS::calc_asf_value(jaMOSSoln* pSoln, int no)
{
	double v0 = (pSoln->objs[0][no]
		- std::get<0>(ref_point))*WEIGHTS[0];
	double v1 = (pSoln->objs[1][no]
		- std::get<1>(ref_point))*WEIGHTS[1];
	double v2 = (pSoln->objs[2][no]
		- std::get<1>(ref_point))*WEIGHTS[2];
	double max_v = std::max(v0, std::max(v1, v2));
	double sum_v = SCALARIZING*(v0 + v1 + v2);
	pSoln->asf_vals[no] = max_v + sum_v;
	return pSoln->asf_vals[no];
}

void jaMOSS::remove_soln(jaMOSSoln* pSoln, vector<jaMOSSoln*>& POP)
{
	for (vector<jaMOSSoln*>::iterator it = POP.begin(); it != POP.end();it++)
	{
		if (*it=pSoln)
		{
			POP.erase(it);
			return;
		}				
	}
}

bool jaMOSS::wall_update(jaMOSSoln* q)
{	
	double tempPE = q->ASF_value;
	jaMOSSoln* p = q->getParent().first;
	double excessEnergy = p->PE + p->KE - tempPE;
	if (excessEnergy >= 0)
	{
		q->PE = tempPE;
		q->KE = excessEnergy * ((1.0 - LOSS_RATE) *
			CRORandDouble() + LOSS_RATE);
		q->update();
		eBuffer += excessEnergy - q->KE;
		return true;
	}
	return false;
}

bool jaMOSS::dec_update(jaMOSSoln* q1, jaMOSSoln* q2)
{	
	double tempPE1 = q1->ASF_value;
	double tempPE2 = q2->ASF_value;
	jaMOSSoln* p = q1->getParent().first;
	double excessEnergy = p->PE + p->KE - tempPE1 - tempPE2;
	if ((excessEnergy >= 0) || (excessEnergy + eBuffer >= 0))
	{
		if (excessEnergy >= 0)
		{
			q1->KE = excessEnergy * CRORandDouble();
			q2->KE = excessEnergy - q1->KE;
		}
		else
		{
			eBuffer += excessEnergy;
			q1->KE = eBuffer * CRORandDouble() * CRORandDouble();
			eBuffer -= q1->KE;
			q2->KE = eBuffer * CRORandDouble() * CRORandDouble();
			eBuffer -= q2->KE;
		}		
		q1->PE = tempPE1;	
		q1->update();
		q2->PE = tempPE2;	;
		q2->update();
		return true;
	}
	return false;	
}

bool jaMOSS::inter_update(jaMOSSoln* q1, jaMOSSoln* q2)
{	
	double tempPE1 = q1->ASF_value;
	double tempPE2 = q2->ASF_value;
	jaMOSSoln* p1 = q1->getParent().first;
	jaMOSSoln* p2 = q1->getParent().second;
	double excessEnergy = p1->PE + p1->KE + p2->PE + p2->KE -
		tempPE1 - tempPE2;
	if (excessEnergy >= 0)
	{
		q1->PE = tempPE1;
		q1->KE = excessEnergy * CRORandDouble();		
		q1->update();
		q2->PE = tempPE2;
		q2->KE = excessEnergy - q1->KE;		
		q2->update();
		return true;
	}
	return false;
}


bool jaMOSS::syn_update(jaMOSSoln* q)
{
	double tempPE = q->ASF_value;
	jaMOSSoln* p1 = q->getParent().first;
	jaMOSSoln* p2 = q->getParent().second;
	double excessEnergy = p1->PE + p2->KE + p1->PE + p2->KE - tempPE;
	if (excessEnergy >= 0)
	{		
		q->PE = tempPE;
		q->KE = excessEnergy;		
		q->update();
		return true;
	}
	return false;
}
