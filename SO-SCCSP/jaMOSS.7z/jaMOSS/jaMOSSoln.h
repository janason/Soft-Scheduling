#pragma once

#include "jaMOSSMacro.h"

struct tagSoftSoln
{
	jaBatch* pBatch;
	jaMachine* pDestMa;
	int release_time;
	double priority;	
	double slack_ratio;
};

class jaMOSSoln
{
public:
	jaMOSSoln(double init_ke);
	~jaMOSSoln();

	vector<double> m_code;
	vector<tagSoftSoln*> soft_decisions; //cast, slack, st, sr
	
	int num_repc;
	int cur_repc;
	double objs[3][1000]; //3��Ŀ��
	double means[3]; //��ֵ
	double vars[3]; //����

	//tuple<pair<double, double>, pair<double, double>, pair<double, double>> CI;

	double asf_vals[1000];

	double ASF_value;
	double PE, KE, optLocal;
	int MIN_HIT_NUM, HIT_NUM;		
	
	bool isDecp(int threshold)
	{
		return (HIT_NUM - MIN_HIT_NUM) > threshold;
	}

	bool isSync(int threshold)
	{
		return this->KE < threshold;
	}
	
	void clone(const jaMOSSoln* pSrc)
	{		
		this->m_code = pSrc->m_code; //ֻ���Ƶ��Ƚ⣬��������Ĭ�ϳ�ʼֵ
		this->soft_decisions = pSrc->soft_decisions;
		this->num_repc = pSrc->num_repc;
		this->cur_repc = pSrc->cur_repc;		
		memcpy((double*)this->objs[0], (double*)pSrc->objs[0], sizeof(pSrc->objs[0]));
		memcpy((double*)this->objs[1], (double*)pSrc->objs[1], sizeof(pSrc->objs[1]));
		memcpy((double*)this->objs[2], (double*)pSrc->objs[2], sizeof(pSrc->objs[2]));
		memcpy((double*)this->means, (double*)pSrc->means, sizeof(pSrc->asf_vals));
		memcpy((double*)this->vars, (double*)pSrc->vars, sizeof(pSrc->asf_vals));
		memcpy((double*)this->asf_vals, (double*)pSrc->asf_vals, sizeof(pSrc->asf_vals));
		this->ASF_value = pSrc->ASF_value;
		this->PE = pSrc->PE;
		this->KE = pSrc->KE;
	}

	void update()
	{
		if (PE < optLocal)
		{
			optLocal = PE;
			MIN_HIT_NUM = HIT_NUM;
		}
	}

	void statistics();
	void setReactionType(REACTION_TYPE type);
	REACTION_TYPE getReactionType();

	void setParent(jaMOSSoln* p1,jaMOSSoln* p2=nullptr);
	pair<jaMOSSoln*, jaMOSSoln*>& getParent();

	bool wall_reaction(jaMOSSoln* in, jaMOSSoln* out); //ǽ����ײ��1-1
	bool dec_reaction(jaMOSSoln* in, jaMOSSoln* out1, jaMOSSoln* out2); //�ֽ������1-2
	bool syn_reaction(jaMOSSoln* in1, jaMOSSoln* in2, jaMOSSoln* out); //�ϳɲ�����2-1
	bool inter_reaction(jaMOSSoln* in1, jaMOSSoln* in2, jaMOSSoln* out1, jaMOSSoln* out2); //������ײ��2-2

private:
	pair<jaMOSSoln*,jaMOSSoln*> m_parents;
	REACTION_TYPE m_rtype;
};

