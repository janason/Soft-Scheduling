#ifndef _JA_MOSS_H_
#define _JA_MOSS_H_


#include <jaSimulation/entity/jaAlogrithm.h>
#include "jaMOSSMacro.h"
#include "jaDispatcher.h"
#include "kl_ucb.h"


class JA_MOSS_DLL jaMOSS: public jaAlogrithm
{
public:
	jaMOSS(string algo_name);
	~jaMOSS();

	bool initialize();
	bool reset();
	bool run();
private:

	int FE_LIMIT;
	//double   COLL_RATE,  DEC_THRES, SYN_THRES;
	int T_BUDGET;

	int curFE;
	double eBuffer;
	double total_energy;

	void update_ideal_point(jaMOSSoln* pSoln);
	void update_weights_point();
	std::tuple<double, double, double> ideal_point;
	std::tuple<double, double, double> ndir_point;
	std::tuple<double, double, double> ref_point;
	
	vector<jaMOSSoln*> m_population;
	jaDispatcher* m_pScher;
	jaMOSSoln* m_pOptSoln;	
	
	void CRO_Variation(vector<jaMOSSoln*>& P_POP,vector<jaMOSSoln*>& Q_POP);
	void CRO_Update(vector<jaMOSSoln*>& P_POP, vector<jaMOSSoln*>& Q_POP);
	jaMOSSoln* local_search(jaMOSSoln* pCurSoln);
	
	int select_arm_ucb1(vector<jaMOSSoln*>& POP,int  trail_num);
	int select_arm_pucb(vector<jaMOSSoln*>& POP, int trail_num);
	int clean_up(vector<jaMOSSoln*>& POP);

	void remove_soln(jaMOSSoln* pSoln,vector<jaMOSSoln*>& POP);	
	double round_simulation(jaMOSSoln* pSoln);	
	double estimate_asf_value(jaMOSSoln* pSoln);
	double calc_asf_value(jaMOSSoln* pSoln, int no);
		
	bool wall_update(jaMOSSoln* q);
	bool dec_update(jaMOSSoln* q1, jaMOSSoln* q2);
	bool inter_update(jaMOSSoln* q1, jaMOSSoln* q2);
	bool syn_update(jaMOSSoln* q);
};

#endif // !
